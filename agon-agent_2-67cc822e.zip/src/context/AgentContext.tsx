import { createContext, useContext, useState, useEffect, ReactNode } from 'react';

interface Settings {
  apiKey: string;
  model: string;
  theme: 'dark' | 'light';
}

interface Session {
  id: number;
  title: string;
  model: string;
  status: string;
  created_at: string;
  updated_at: string;
}

interface Message {
  id: number;
  session_id: number;
  role: string;
  content: string;
  message_type: string;
  metadata: any;
  created_at: string;
}

interface AgentFile {
  id: number;
  session_id: number;
  filename: string;
  content: string;
  language: string;
  created_at: string;
  updated_at: string;
}

interface AgentContextType {
  settings: Settings;
  setSettings: (s: Settings) => void;
  sessions: Session[];
  currentSession: Session | null;
  setCurrentSession: (s: Session | null) => void;
  messages: Message[];
  files: AgentFile[];
  loading: boolean;
  agentStatus: string;
  recentActions: string[];
  fetchSessions: () => Promise<void>;
  createSession: () => Promise<void>;
  deleteSession: (id: number) => Promise<void>;
  sendMessage: (msg: string) => Promise<any>;
  fetchFiles: () => Promise<void>;
  saveFile: (id: number, content: string) => Promise<void>;
  createFile: (filename: string, content: string, language: string) => Promise<void>;
  deleteFile: (id: number) => Promise<void>;
  showSettings: boolean;
  setShowSettings: (v: boolean) => void;
}

const AgentContext = createContext<AgentContextType>(null as any);

export function useAgent() {
  return useContext(AgentContext);
}

export function AgentProvider({ children }: { children: ReactNode }) {
  const [settings, setSettingsState] = useState<Settings>(() => {
    const saved = localStorage.getItem('banana_settings');
    return saved ? JSON.parse(saved) : { apiKey: '', model: 'openrouter/auto', theme: 'dark' };
  });
  const [sessions, setSessions] = useState<Session[]>([]);
  const [currentSession, setCurrentSession] = useState<Session | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [files, setFiles] = useState<AgentFile[]>([]);
  const [loading, setLoading] = useState(false);
  const [agentStatus, setAgentStatus] = useState('idle');
  const [recentActions, setRecentActions] = useState<string[]>([]);
  const [showSettings, setShowSettings] = useState(false);

  const setSettings = (s: Settings) => {
    setSettingsState(s);
    localStorage.setItem('banana_settings', JSON.stringify(s));
  };

  const addAction = (action: string) => {
    setRecentActions(prev => [action, ...prev].slice(0, 30));
  };

  const fetchSessions = async () => {
    try {
      const res = await fetch('/api/sessions');
      const data = await res.json();
      setSessions(Array.isArray(data) ? data : []);
    } catch (err) { console.error(err); }
  };

  const createSession = async () => {
    try {
      const res = await fetch('/api/sessions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title: 'New Session', model: settings.model })
      });
      const data = await res.json();
      await fetchSessions();
      setCurrentSession(data);
      setMessages([]);
      setFiles([]);
      addAction('🆕 Created new session');
    } catch (err) { console.error(err); }
  };

  const deleteSession = async (id: number) => {
    try {
      await fetch('/api/sessions', {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id })
      });
      if (currentSession?.id === id) {
        setCurrentSession(null);
        setMessages([]);
        setFiles([]);
      }
      await fetchSessions();
      addAction('🗑️ Deleted session');
    } catch (err) { console.error(err); }
  };

  const fetchMessages = async (sessionId: number) => {
    try {
      const res = await fetch(`/api/chat?session_id=${sessionId}`);
      const data = await res.json();
      setMessages(Array.isArray(data) ? data : []);
    } catch (err) { console.error(err); }
  };

  const fetchFiles = async () => {
    if (!currentSession) return;
    try {
      const res = await fetch(`/api/files?session_id=${currentSession.id}`);
      const data = await res.json();
      setFiles(Array.isArray(data) ? data : []);
    } catch (err) { console.error(err); }
  };

  const sendMessage = async (msg: string) => {
    if (!currentSession || !settings.apiKey) return null;
    setLoading(true);
    setAgentStatus('thinking');
    addAction('🧠 Agent is thinking...');

    try {
      const history = messages.map(m => ({ role: m.role, content: m.content }));

      const statusCycle = ['reasoning', 'planning', 'analyzing', 'coding', 'researching', 'optimizing'];
      let cycleIdx = 0;
      const statusInterval = setInterval(() => {
        setAgentStatus(statusCycle[cycleIdx % statusCycle.length]);
        addAction(`⚡ ${statusCycle[cycleIdx % statusCycle.length].toUpperCase()}...`);
        cycleIdx++;
      }, 2500);

      const res = await fetch('/api/agent', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          session_id: currentSession.id,
          message: msg,
          api_key: settings.apiKey,
          model: settings.model,
          history
        })
      });

      clearInterval(statusInterval);

      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || 'Agent request failed');
      }

      const data = await res.json();
      setAgentStatus('complete');
      addAction('✅ Agent response complete');

      if (data.code_files?.length) {
        data.code_files.forEach((f: any) => addAction(`📄 File: ${f.filename}`));
        addAction(`💾 ${data.code_files.length} files saved to editor`);
      }

      await fetchMessages(currentSession.id);
      await fetchFiles();
      return data;
    } catch (err: any) {
      setAgentStatus('error');
      addAction(`❌ Error: ${err.message}`);
      if (currentSession) await fetchMessages(currentSession.id);
      throw err;
    } finally {
      setLoading(false);
      setTimeout(() => setAgentStatus('idle'), 3000);
    }
  };

  const saveFile = async (id: number, content: string) => {
    try {
      await fetch('/api/files', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id, content })
      });
      await fetchFiles();
      addAction('💾 File saved');
    } catch (err) { console.error(err); }
  };

  const createFile = async (filename: string, content: string, language: string) => {
    if (!currentSession) return;
    try {
      await fetch('/api/files', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ session_id: currentSession.id, filename, content, language })
      });
    } catch (err) { console.error(err); }
  };

  const deleteFile = async (id: number) => {
    try {
      await fetch('/api/files', {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id })
      });
      await fetchFiles();
      addAction('🗑️ File deleted');
    } catch (err) { console.error(err); }
  };

  useEffect(() => {
    fetchSessions();
  }, []);

  useEffect(() => {
    if (currentSession) {
      fetchMessages(currentSession.id);
      fetchFiles();
    }
  }, [currentSession?.id]);

  return (
    <AgentContext.Provider value={{
      settings, setSettings, sessions, currentSession, setCurrentSession,
      messages, files, loading, agentStatus, recentActions,
      fetchSessions, createSession, deleteSession, sendMessage,
      fetchFiles, saveFile, createFile, deleteFile, showSettings, setShowSettings
    }}>
      {children}
    </AgentContext.Provider>
  );
}
