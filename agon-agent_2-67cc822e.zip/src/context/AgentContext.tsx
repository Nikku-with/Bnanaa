import { createContext, useContext, useState, useEffect, useRef, ReactNode } from 'react';

interface Settings { apiKey: string; groqKey: string; provider: 'openrouter' | 'groq'; model: string; theme: 'dark' | 'light'; customModes: Array<{ name: string; prompt: string }>; }
interface Session { id: number; title: string; model: string; status: string; created_at: string; updated_at: string; }
interface Message { id: number; session_id: number; role: string; content: string; message_type: string; metadata: any; created_at: string; }
interface AgentFile { id: number; session_id: number; filename: string; content: string; language: string; }

interface Ctx {
  settings: Settings; setSettings: (s: Settings) => void;
  sessions: Session[]; currentSession: Session | null; setCurrentSession: (s: Session | null) => void;
  messages: Message[]; files: AgentFile[];
  loading: boolean; agentStatus: string; recentActions: string[];
  totalTokens: number; streamingText: string;
  fetchSessions: () => Promise<void>; createSession: () => Promise<void>; deleteSession: (id: number) => Promise<void>;
  sendMessage: (msg: string, mode?: string, webSearch?: boolean, customPrompt?: string) => Promise<any>;
  stopGeneration: () => void;
  fetchFiles: () => Promise<void>; saveFile: (id: number, c: string) => Promise<void>;
  createFile: (fn: string, c: string, l: string) => Promise<void>;
  deleteFile: (id: number) => Promise<void>;
  showSettings: boolean; setShowSettings: (v: boolean) => void;
  memory: any[]; activeTab: string; setActiveTab: (t: string) => void;
  clearActions: () => void;
}

const AgentContext = createContext<Ctx>(null as any);
export function useAgent() { return useContext(AgentContext); }

const DEF: Settings = { apiKey: '', groqKey: '', provider: 'openrouter', model: 'openrouter/auto', theme: 'dark', customModes: [] };

export function AgentProvider({ children }: { children: ReactNode }) {
  const [settings, setSettingsRaw] = useState<Settings>(() => { try { const s = localStorage.getItem('banana_s3'); return s ? { ...DEF, ...JSON.parse(s) } : DEF; } catch { return DEF; } });
  const [sessions, setSessions] = useState<Session[]>([]);
  const [cur, setCur] = useState<Session | null>(null);
  const [msgs, setMsgs] = useState<Message[]>([]);
  const [files, setFiles] = useState<AgentFile[]>([]);
  const [loading, setLoading] = useState(false);
  const [status, setStatus] = useState('idle');
  const [actions, setActions] = useState<string[]>([]);
  const [showSettings, setShowSettings] = useState(false);
  const [memory, setMemory] = useState<any[]>([]);
  const [tab, setTab] = useState('chat');
  const [totalTokens, setTotalTokens] = useState(0);
  const [streamingText, setStreamingText] = useState('');
  const abortRef = useRef<AbortController | null>(null);

  const setSettings = (s: Settings) => { setSettingsRaw(s); localStorage.setItem('banana_s3', JSON.stringify(s)); };
  const addA = (a: string) => setActions(p => [a, ...p].slice(0, 60));
  const clearActions = () => setActions([]);

  const fetchSessions = async () => { try { const r = await fetch('/api/sessions'); const d = await r.json(); setSessions(Array.isArray(d) ? d : []); } catch {} };
  const createSession = async () => { try { const r = await fetch('/api/sessions', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ title: 'New Session', model: settings.model }) }); const d = await r.json(); await fetchSessions(); setCur(d); setMsgs([]); setFiles([]); setTotalTokens(0); addA('\ud83c\udd95 New session'); } catch {} };
  const deleteSession = async (id: number) => { try { await fetch('/api/sessions', { method: 'DELETE', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id }) }); if (cur?.id === id) { setCur(null); setMsgs([]); setFiles([]); } await fetchSessions(); } catch {} };
  const fetchMsgs = async (sid: number) => { try { const r = await fetch(`/api/chat?session_id=${sid}`); const d = await r.json(); setMsgs(Array.isArray(d) ? d : []); } catch {} };
  const fetchFiles = async () => { if (!cur) return; try { const r = await fetch(`/api/files?session_id=${cur.id}`); const d = await r.json(); setFiles(Array.isArray(d) ? d : []); } catch {} };
  const fetchMem = async () => { if (!cur) return; try { const r = await fetch(`/api/memory?session_id=${cur.id}`); const d = await r.json(); setMemory(Array.isArray(d) ? d : []); } catch {} };

  const stopGeneration = () => { if (abortRef.current) { abortRef.current.abort(); abortRef.current = null; } };

  const sendMessage = async (msg: string, mode = 'normal', webSearch = false, customPrompt?: string) => {
    if (!cur) return null;
    const key = settings.provider === 'groq' ? settings.groqKey : settings.apiKey;
    if (!key) { setShowSettings(true); return null; }
    setLoading(true); setStatus('thinking'); setStreamingText(''); addA('\ud83e\udde0 Thinking...');

    const controller = new AbortController();
    abortRef.current = controller;

    try {
      const history = msgs.map(m => ({ role: m.role, content: m.content }));
      const memCtx = memory.slice(0, 10).map(m => `${m.key}: ${m.value}`).join('\n');
      let srText = '';
      if (webSearch) {
        addA('\ud83c\udf10 Searching...');
        try { const sr = await fetch('/api/search', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ query: msg, api_key: settings.apiKey, groq_key: settings.groqKey, provider: settings.provider }) }); const sd = await sr.json(); srText = sd.raw || ''; addA('\u2705 Search done'); } catch {}
      }

      const phases = ['reasoning', 'planning', 'coding', 'optimizing'];
      let ci = 0;
      const si = setInterval(() => { setStatus(phases[ci % phases.length]); ci++; }, 3000);

      // Stream the response
      const r = await fetch('/api/agent', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ session_id: cur.id, message: msg, api_key: settings.apiKey, groq_key: settings.groqKey, provider: settings.provider, model: settings.model, history, mode, custom_prompt: customPrompt, memory_context: memCtx, search_results: srText }),
        signal: controller.signal
      });

      clearInterval(si);

      if (!r.ok) { const e = await r.json().catch(() => ({ error: 'Failed' })); throw new Error(e.error || 'Failed'); }

      // Read SSE stream
      const reader = r.body!.getReader();
      const decoder = new TextDecoder();
      let accumulated = '';
      let tokenCount = 0;

      setStatus('coding');

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        const chunk = decoder.decode(value, { stream: true });
        const lines = chunk.split('\n').filter(l => l.startsWith('data: '));

        for (const line of lines) {
          try {
            const data = JSON.parse(line.slice(6));
            if (data.token) {
              accumulated += data.token;
              tokenCount++;
              setStreamingText(accumulated);
              // Update status based on content
              if (accumulated.includes('```') && status !== 'coding') setStatus('coding');
            }
            if (data.error) throw new Error(data.error);
            if (data.complete) {
              if (data.usage) {
                const t = (data.usage.prompt_tokens || 0) + (data.usage.completion_tokens || 0);
                setTotalTokens(p => p + t);
                addA(`\ud83d\udcca ${t} tokens`);
              }
              if (data.code_files?.length) {
                data.code_files.forEach((f: any) => addA(`\ud83d\udcc4 ${f.filename}`));
              }
            }
          } catch (e: any) {
            if (e.message && !e.message.includes('JSON')) throw e;
          }
        }
      }

      setStreamingText('');
      setStatus('complete'); addA('\u2705 Complete');
      await fetchMsgs(cur.id); await fetchFiles(); await fetchMem();
      return { content: accumulated };
    } catch (err: any) {
      if (err.name === 'AbortError') { addA('\u23f9 Stopped'); setStatus('idle'); setStreamingText(''); return null; }
      setStatus('error'); addA(`\u274c ${err.message}`); if (cur) await fetchMsgs(cur.id); throw err;
    } finally { setLoading(false); abortRef.current = null; setTimeout(() => setStatus('idle'), 3000); }
  };

  const saveFile = async (id: number, c: string) => { try { await fetch('/api/files', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id, content: c }) }); await fetchFiles(); } catch {} };
  const createFile = async (fn: string, c: string, l: string) => { if (!cur) return; try { await fetch('/api/files', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ session_id: cur.id, filename: fn, content: c, language: l }) }); } catch {} };
  const deleteFile = async (id: number) => { try { await fetch('/api/files', { method: 'DELETE', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id }) }); await fetchFiles(); } catch {} };

  useEffect(() => { fetchSessions(); }, []);
  useEffect(() => { if (cur) { fetchMsgs(cur.id); fetchFiles(); fetchMem(); } }, [cur?.id]);
  useEffect(() => { document.documentElement.setAttribute('data-theme', settings.theme); }, [settings.theme]);

  return <AgentContext.Provider value={{ settings, setSettings, sessions, currentSession: cur, setCurrentSession: setCur, messages: msgs, files, loading, agentStatus: status, recentActions: actions, totalTokens, streamingText, fetchSessions, createSession, deleteSession, sendMessage, stopGeneration, fetchFiles, saveFile, createFile, deleteFile, showSettings, setShowSettings, memory, activeTab: tab, setActiveTab: setTab, clearActions }}>{children}</AgentContext.Provider>;
}
