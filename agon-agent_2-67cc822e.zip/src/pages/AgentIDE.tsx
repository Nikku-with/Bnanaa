import { useState } from 'react';
import { useAgent } from '../context/AgentContext';
import Sidebar from '../components/Sidebar';
import ChatPanel from '../components/ChatPanel';
import CodeEditor from '../components/CodeEditor';
import ActionsFeed from '../components/ActionsFeed';
import StatusBar from '../components/StatusBar';
import SettingsModal from '../components/SettingsModal';
import WelcomeScreen from '../components/WelcomeScreen';
import MobileNav from '../components/MobileNav';
import { AnimatePresence, motion } from 'framer-motion';

export default function AgentIDE() {
  const { currentSession, showSettings, setShowSettings, settings } = useAgent();
  const [activeTab, setActiveTab] = useState<'chat' | 'code' | 'actions' | 'sessions'>('chat');
  const [sidebarOpen, setSidebarOpen] = useState(false);

  return (
    <div className="fixed inset-0 flex flex-col bg-[#0a0a0f] text-white overflow-hidden">
      {/* Top Status Bar — hidden on mobile */}
      <div className="hidden md:block shrink-0">
        <StatusBar />
      </div>

      {/* Main layout */}
      <div className="flex-1 flex overflow-hidden min-h-0">
        {/* Desktop Sidebar */}
        <div className="hidden md:flex shrink-0">
          <Sidebar />
        </div>

        {/* Mobile Sidebar Overlay */}
        <AnimatePresence>
          {sidebarOpen && (
            <>
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="md:hidden fixed inset-0 bg-black/60 backdrop-blur-sm z-40"
                onClick={() => setSidebarOpen(false)}
              />
              <motion.div
                initial={{ x: -280 }}
                animate={{ x: 0 }}
                exit={{ x: -280 }}
                transition={{ type: 'spring', damping: 25, stiffness: 300 }}
                className="md:hidden fixed left-0 top-0 bottom-0 z-50 w-[280px]"
              >
                <Sidebar onClose={() => setSidebarOpen(false)} />
              </motion.div>
            </>
          )}
        </AnimatePresence>

        {/* Content area */}
        <div className="flex-1 flex flex-col overflow-hidden min-h-0 min-w-0">
          {!currentSession ? (
            <WelcomeScreen onOpenSidebar={() => setSidebarOpen(true)} />
          ) : (
            <div className="flex-1 flex overflow-hidden min-h-0">
              {/* MOBILE: show only the active tab */}
              <div className="md:hidden flex-1 flex flex-col overflow-hidden min-h-0">
                {activeTab === 'chat' && <ChatPanel />}
                {activeTab === 'code' && <CodeEditor />}
                {activeTab === 'actions' && <ActionsFeed />}
                {activeTab === 'sessions' && (
                  <div className="flex-1 overflow-hidden">
                    <Sidebar onClose={() => setActiveTab('chat')} />
                  </div>
                )}
              </div>

              {/* DESKTOP: multi-panel */}
              <div className="hidden md:flex flex-1 overflow-hidden min-h-0">
                <div className="flex-1 flex flex-col overflow-hidden min-h-0 min-w-0">
                  <ChatPanel />
                </div>
                <div className="w-[42%] max-w-[550px] min-w-[280px] border-l border-white/5 flex flex-col overflow-hidden min-h-0">
                  <CodeEditor />
                </div>
                <div className="hidden lg:flex w-[240px] border-l border-white/5 flex-col overflow-hidden min-h-0 bg-[#08080d]">
                  <ActionsFeed />
                </div>
              </div>
            </div>
          )}

          {/* Mobile Bottom Nav — only when session active */}
          {currentSession && (
            <div className="md:hidden shrink-0">
              <MobileNav
                activeTab={activeTab}
                setActiveTab={setActiveTab}
                onOpenSidebar={() => setSidebarOpen(true)}
              />
            </div>
          )}
        </div>
      </div>

      {/* Settings Modal */}
      <AnimatePresence>
        {showSettings && <SettingsModal />}
      </AnimatePresence>

      {/* No API Key Warning */}
      <AnimatePresence>
        {!settings.apiKey && currentSession && (
          <motion.div
            initial={{ y: 100, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: 100, opacity: 0 }}
            className="fixed bottom-20 md:bottom-4 left-1/2 -translate-x-1/2 bg-red-500/90 backdrop-blur-xl text-white px-4 py-2.5 rounded-2xl shadow-2xl shadow-red-500/20 flex items-center gap-2.5 z-30 border border-red-400/30 max-w-[90vw]"
          >
            <span className="text-base">⚠️</span>
            <span className="text-xs font-medium">Add OpenRouter API key</span>
            <button
              onClick={() => setShowSettings(true)}
              className="bg-white/20 hover:bg-white/30 px-2.5 py-1 rounded-lg text-[10px] font-bold"
            >
              Settings
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
