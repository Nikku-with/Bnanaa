import { useState, useRef, useEffect } from 'react';
import { useAgent } from '../context/AgentContext';
import { motion, AnimatePresence } from 'framer-motion';
import { Send, Loader2, Copy, Check, ChevronDown, ChevronUp, FileCode, ExternalLink } from 'lucide-react';
import UICard from './UICard';
import ThinkingAnimation from './ThinkingAnimation';
import CodeBlock from './CodeBlock';

export default function ChatPanel() {
  const { messages, sendMessage, loading, agentStatus, currentSession, settings } = useAgent();
  const [input, setInput] = useState('');
  const [error, setError] = useState('');
  const scrollRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, loading]);

  const handleSend = async () => {
    if (!input.trim() || loading) return;
    if (!settings.apiKey) {
      setError('Please add your OpenRouter API key in Settings first!');
      return;
    }
    const msg = input;
    setInput('');
    setError('');
    if (inputRef.current) inputRef.current.style.height = '44px';
    try {
      await sendMessage(msg);
    } catch (err: any) {
      setError(err.message);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <div className="flex-1 flex flex-col overflow-hidden min-h-0">
      {/* Chat Header */}
      <div className="px-4 py-2.5 border-b border-white/5 flex items-center gap-2.5 bg-[#0b0b12] shrink-0">
        <div className="w-6 h-6 rounded-md bg-gradient-to-br from-yellow-400 to-orange-500 flex items-center justify-center text-[10px] shrink-0">{'🍌'}</div>
        <div className="flex-1 min-w-0">
          <h2 className="text-xs font-bold text-white truncate">{currentSession?.title || 'Chat'}</h2>
          <p className="text-[9px] text-white/25 font-mono truncate">#{currentSession?.id} • {settings.model}</p>
        </div>
        <AgentStatusBadge status={agentStatus} />
      </div>

      {/* Messages */}
      <div
        ref={scrollRef}
        className="flex-1 overflow-y-auto min-h-0 px-3 py-3 space-y-3 scrollbar-thin"
      >
        {messages.length === 0 && !loading && (
          <div className="flex flex-col items-center justify-center py-12 text-center px-4">
            <motion.div
              animate={{ rotate: [0, 10, -10, 0], scale: [1, 1.1, 1] }}
              transition={{ duration: 2, repeat: Infinity, repeatDelay: 3 }}
              className="text-5xl mb-3"
            >{'🍌'}</motion.div>
            <h3 className="text-base font-bold text-white/80 mb-1">Banana Agent Ready</h3>
            <p className="text-xs text-white/30 max-w-sm">50+ tools • LangChain • LangGraph • Auto code gen</p>
            <div className="mt-5 flex flex-wrap gap-1.5 justify-center max-w-sm">
              {[
                '🐍 Snake game with neon',
                '🌐 Portfolio website',
                '📊 Dashboard + charts',
                '🤖 Chatbot with memory',
                '🎮 Platformer game',
                '⚡ Real-time todo'
              ].map((suggestion, i) => (
                <motion.button
                  key={i}
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.08 }}
                  onClick={() => setInput(suggestion)}
                  className="px-2.5 py-1 rounded-full bg-white/5 border border-white/10 text-[10px] text-white/40 hover:text-yellow-400 hover:border-yellow-500/30 hover:bg-yellow-500/5 active:scale-95 transition-transform"
                >
                  {suggestion}
                </motion.button>
              ))}
            </div>
          </div>
        )}

        {messages.map((msg, idx) => (
          <MessageBubble key={msg.id || idx} message={msg} />
        ))}

        {loading && <ThinkingAnimation status={agentStatus} />}

        {error && (
          <motion.div
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-red-500/10 border border-red-500/20 rounded-xl p-2.5 text-red-400 text-xs"
          >❌ {error}</motion.div>
        )}
      </div>

      {/* Input */}
      <div className="shrink-0 p-2.5 border-t border-white/5 bg-[#0b0b12]">
        <div className="flex gap-2 items-end">
          <textarea
            ref={inputRef}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Describe what you want to build..."
            rows={1}
            className="flex-1 bg-white/5 border border-white/10 rounded-xl px-3 py-2.5 text-sm text-white placeholder-white/25 resize-none focus:outline-none focus:border-yellow-500/40 focus:ring-1 focus:ring-yellow-500/20"
            style={{ minHeight: '44px', maxHeight: '120px' }}
            onInput={(e) => {
              const t = e.currentTarget;
              t.style.height = 'auto';
              t.style.height = Math.min(t.scrollHeight, 120) + 'px';
            }}
          />
          <motion.button
            whileTap={{ scale: 0.9 }}
            onClick={handleSend}
            disabled={loading || !input.trim()}
            className="h-[44px] w-[44px] rounded-xl bg-gradient-to-r from-yellow-500 to-orange-500 flex items-center justify-center text-black disabled:opacity-30 disabled:cursor-not-allowed shadow-lg shadow-yellow-500/20 shrink-0"
          >
            {loading ? <Loader2 size={16} className="animate-spin" /> : <Send size={16} />}
          </motion.button>
        </div>
        <p className="text-[9px] text-white/10 mt-1 px-1 font-mono hidden md:block">
          Enter to send • Shift+Enter for new line
        </p>
      </div>
    </div>
  );
}

function AgentStatusBadge({ status }: { status: string }) {
  const config: Record<string, { color: string; label: string }> = {
    idle: { color: 'bg-white/10 text-white/40', label: 'Ready' },
    thinking: { color: 'bg-purple-500/20 text-purple-400', label: 'Thinking' },
    reasoning: { color: 'bg-blue-500/20 text-blue-400', label: 'Reasoning' },
    planning: { color: 'bg-cyan-500/20 text-cyan-400', label: 'Planning' },
    analyzing: { color: 'bg-indigo-500/20 text-indigo-400', label: 'Analyzing' },
    coding: { color: 'bg-green-500/20 text-green-400', label: 'Coding' },
    researching: { color: 'bg-amber-500/20 text-amber-400', label: 'Research' },
    optimizing: { color: 'bg-pink-500/20 text-pink-400', label: 'Optimizing' },
    complete: { color: 'bg-green-500/20 text-green-400', label: 'Done' },
    error: { color: 'bg-red-500/20 text-red-400', label: 'Error' },
  };
  const c = config[status] || config.idle;
  return (
    <motion.div
      key={status}
      initial={{ scale: 0.8, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      className={`flex items-center gap-1 px-2 py-0.5 rounded-full text-[9px] font-bold uppercase tracking-wider shrink-0 ${c.color}`}
    >
      {status !== 'idle' && status !== 'error' && status !== 'complete' && (
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 2, repeat: Infinity, ease: 'linear' }}
          className="w-1.5 h-1.5 rounded-full bg-current"
        />
      )}
      {c.label}
    </motion.div>
  );
}

// Parse message content into segments: text parts and code blocks
function parseContent(content: string): Array<{ type: 'text' | 'code'; value: string; lang?: string; filename?: string }> {
  const segments: Array<{ type: 'text' | 'code'; value: string; lang?: string; filename?: string }> = [];
  // Match ```lang:filename\ncode``` or ```lang\ncode``` or just ```\ncode```
  const regex = /```([\w+#.-]*):?([^\n]*)\n([\s\S]*?)```/g;
  let lastIndex = 0;
  let match;

  while ((match = regex.exec(content)) !== null) {
    // Text before this code block
    if (match.index > lastIndex) {
      const text = content.slice(lastIndex, match.index).trim();
      if (text) segments.push({ type: 'text', value: text });
    }
    const lang = match[1] || 'text';
    const filename = match[2]?.trim() || '';
    const code = match[3]?.trim() || '';
    if (code) {
      segments.push({ type: 'code', value: code, lang, filename });
    }
    lastIndex = match.index + match[0].length;
  }

  // Remaining text after last code block
  if (lastIndex < content.length) {
    const text = content.slice(lastIndex).trim();
    if (text) segments.push({ type: 'text', value: text });
  }

  // If nothing found, whole thing is text
  if (segments.length === 0 && content.trim()) {
    segments.push({ type: 'text', value: content.trim() });
  }

  return segments;
}

// Render markdown-lite text (bold, headers, lists)
function RichText({ text }: { text: string }) {
  const lines = text.split('\n');
  return (
    <div className="space-y-1">
      {lines.map((line, i) => {
        // Headers
        if (line.startsWith('### ')) {
          return <h4 key={i} className="text-[12px] font-bold text-white/80 mt-2">{line.slice(4)}</h4>;
        }
        if (line.startsWith('## ')) {
          return <h3 key={i} className="text-[13px] font-bold text-yellow-400/80 mt-2">{line.slice(3)}</h3>;
        }
        if (line.startsWith('# ')) {
          return <h2 key={i} className="text-sm font-black text-yellow-400 mt-2">{line.slice(2)}</h2>;
        }
        // Bullet list
        if (line.startsWith('- ') || line.startsWith('* ')) {
          return (
            <div key={i} className="flex items-start gap-1.5 text-[12px] text-white/70">
              <span className="text-yellow-400/60 mt-0.5 shrink-0">•</span>
              <span>{renderInline(line.slice(2))}</span>
            </div>
          );
        }
        // Numbered list
        const numMatch = line.match(/^(\d+)\.\s/);
        if (numMatch) {
          return (
            <div key={i} className="flex items-start gap-1.5 text-[12px] text-white/70">
              <span className="text-cyan-400/60 font-mono text-[10px] mt-0.5 shrink-0 w-4 text-right">{numMatch[1]}.</span>
              <span>{renderInline(line.slice(numMatch[0].length))}</span>
            </div>
          );
        }
        // Empty line
        if (!line.trim()) {
          return <div key={i} className="h-1" />;
        }
        // Regular text
        return <p key={i} className="text-[12px] text-white/70 leading-relaxed">{renderInline(line)}</p>;
      })}
    </div>
  );
}

// Render inline markdown: **bold**, `code`, *italic*
function renderInline(text: string) {
  const parts: Array<string | { type: string; value: string }> = [];
  const inlineRegex = /(\*\*(.+?)\*\*|`(.+?)`|\*(.+?)\*)/g;
  let lastIdx = 0;
  let m;

  while ((m = inlineRegex.exec(text)) !== null) {
    if (m.index > lastIdx) {
      parts.push(text.slice(lastIdx, m.index));
    }
    if (m[2]) parts.push({ type: 'bold', value: m[2] });
    else if (m[3]) parts.push({ type: 'code', value: m[3] });
    else if (m[4]) parts.push({ type: 'italic', value: m[4] });
    lastIdx = m.index + m[0].length;
  }
  if (lastIdx < text.length) {
    parts.push(text.slice(lastIdx));
  }

  return (
    <>
      {parts.map((p, i) => {
        if (typeof p === 'string') return <span key={i}>{p}</span>;
        if (p.type === 'bold') return <strong key={i} className="text-white/90 font-bold">{p.value}</strong>;
        if (p.type === 'code') return <code key={i} className="px-1 py-0.5 rounded bg-white/10 text-yellow-400/80 text-[11px] font-mono">{p.value}</code>;
        if (p.type === 'italic') return <em key={i} className="text-white/60 italic">{p.value}</em>;
        return null;
      })}
    </>
  );
}

function MessageBubble({ message }: { message: any }) {
  const [copied, setCopied] = useState(false);
  const isUser = message.role === 'user';
  const meta = message.metadata || {};

  const copyAll = () => {
    navigator.clipboard.writeText(message.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // Parse agent messages into text + code segments
  const segments = !isUser ? parseContent(message.content) : [];

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.2 }}
      className={`flex gap-2.5 ${isUser ? 'flex-row-reverse' : ''}`}
    >
      {/* Avatar */}
      <div className={`w-6 h-6 rounded-md flex items-center justify-center text-[10px] shrink-0 mt-0.5 ${
        isUser
          ? 'bg-gradient-to-br from-blue-500 to-indigo-600'
          : 'bg-gradient-to-br from-yellow-400 to-orange-500'
      }`}>
        {isUser ? '👤' : '🍌'}
      </div>

      {/* Content */}
      <div className={`flex-1 min-w-0 ${isUser ? 'flex flex-col items-end' : ''}`}>
        {isUser ? (
          // User message - simple bubble
          <div className="inline-block rounded-2xl px-3 py-2 text-[13px] leading-relaxed max-w-full bg-blue-600/20 border border-blue-500/20 text-blue-100">
            <div className="whitespace-pre-wrap break-words">{message.content}</div>
          </div>
        ) : (
          // Agent message - rich rendering with code blocks inline
          <div className="space-y-2 max-w-full">
            {segments.map((seg, i) => (
              seg.type === 'text' ? (
                <div key={i} className="bg-white/5 border border-white/10 rounded-2xl px-3 py-2.5">
                  <RichText text={seg.value} />
                </div>
              ) : (
                <CodeBlock
                  key={i}
                  code={seg.value}
                  language={seg.lang || 'text'}
                  filename={seg.filename}
                />
              )
            ))}

            {/* Files saved indicator */}
            {meta.code_files?.length > 0 && (
              <div className="flex items-center gap-1.5 px-2 py-1.5 rounded-lg bg-green-500/5 border border-green-500/10">
                <FileCode size={11} className="text-green-400 shrink-0" />
                <span className="text-[10px] text-green-400/70 font-mono">
                  {meta.code_files.length} file{meta.code_files.length > 1 ? 's' : ''} saved to Code Editor →
                </span>
              </div>
            )}

            {/* Copy all + model info row */}
            <div className="flex items-center gap-2">
              <button onClick={copyAll} className="text-white/15 hover:text-white/40 transition-colors">
                {copied ? <Check size={11} /> : <Copy size={11} />}
              </button>
              {meta.model_used && (
                <p className="text-[8px] text-white/15 font-mono">
                  {meta.model_used} {meta.usage ? `• ${meta.usage.total_tokens || 0}t` : ''}
                </p>
              )}
            </div>
          </div>
        )}
      </div>
    </motion.div>
  );
}
