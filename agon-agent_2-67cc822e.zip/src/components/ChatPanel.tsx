import { useState, useRef, useEffect } from 'react';
import { useAgent } from '../context/AgentContext';
import { motion, AnimatePresence } from 'framer-motion';
import { Copy, Check, FileCode, Plus, RefreshCw, Pencil, Square, Coins } from 'lucide-react';
import ThinkingAnimation from './ThinkingAnimation';
import CodeBlock from './CodeBlock';
import ChatInput from './ChatInput';
import AgentWidget, { parseWidgets } from './AgentWidget';

export default function ChatPanel() {
  const { messages, sendMessage, loading, agentStatus, currentSession, settings, createSession, setActiveTab, streamingText, stopGeneration, totalTokens } = useAgent();
  const [error, setError] = useState('');
  const [editingId, setEditingId] = useState<number | null>(null);
  const [editText, setEditText] = useState('');
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => { if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight; }, [messages, loading, streamingText]);

  const handleSend = async (msg: string, mode: string, webSearch: boolean, customPrompt?: string) => {
    if (!settings.apiKey && settings.provider !== 'groq') { setError('Add API key in Settings!'); return; }
    if (settings.provider === 'groq' && !settings.groqKey) { setError('Add Groq key in Settings!'); return; }
    setError('');
    try { await sendMessage(msg, mode, webSearch, customPrompt); } catch (err: any) { setError(err.message); }
  };

  return (
    <div className="flex-1 flex flex-col overflow-hidden min-h-0" style={{ background: 'var(--bg-primary)' }}>
      {/* Header */}
      <div className="px-4 py-2 flex items-center gap-3 shrink-0" style={{ borderBottom: '1px solid var(--border)', background: 'var(--bg-secondary)' }}>
        <button onClick={createSession} title="New Session" className="w-8 h-8 rounded-xl bg-gradient-to-br from-amber-400 via-orange-500 to-red-500 flex items-center justify-center text-sm shadow-lg shadow-amber-500/20 shrink-0 hover:scale-105 active:scale-95 transition-transform">{'🍌'}</button>
        <div className="flex-1 min-w-0">
          <h2 className="text-[13px] font-semibold truncate" style={{ color: 'var(--text-primary)' }}>{currentSession?.title || 'New Chat'}</h2>
          <p className="text-[9px] font-mono truncate" style={{ color: 'var(--text-muted)' }}>#{currentSession?.id}</p>
        </div>
        {/* Live token counter */}
        <div className="flex items-center gap-1 px-2 py-0.5 rounded-full text-[9px] font-mono" style={{ background: 'var(--accent-dim)', color: 'var(--accent)' }}>
          <Coins size={9} />{totalTokens.toLocaleString()}t
        </div>
        <StatusPill status={agentStatus} />
        <button onClick={createSession} className="p-1.5 rounded-lg transition-colors" style={{ color: 'var(--text-muted)' }} title="New"><Plus size={16} /></button>
      </div>

      {/* Messages */}
      <div ref={scrollRef} className="flex-1 overflow-y-auto min-h-0 px-3 md:px-5 py-4 space-y-4 scrollbar-thin">
        {messages.length === 0 && !loading && !streamingText && <EmptyState onSuggest={(s: string) => handleSend(s, 'normal', false)} />}
        {messages.map((msg, idx) => <MessageBubble key={msg.id || idx} message={msg} onRegenerate={(c: string) => handleSend(c, 'normal', false)} onEdit={(id: number, text: string) => { setEditingId(id); setEditText(text); }} editingId={editingId} editText={editText} setEditText={setEditText} onSaveEdit={(text: string) => { handleSend(text, 'normal', false); setEditingId(null); }} onCancelEdit={() => setEditingId(null)} />)}

        {/* LIVE STREAMING TEXT */}
        {streamingText && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex gap-3 max-w-3xl">
            <div className="w-7 h-7 rounded-xl bg-gradient-to-br from-amber-400 to-orange-500 flex items-center justify-center text-[11px] shrink-0 mt-0.5 shadow-md shadow-amber-500/15">{'🍌'}</div>
            <div className="flex-1 min-w-0 space-y-2">
              <StreamingContent text={streamingText} />
              <motion.div animate={{ opacity: [0.3, 1, 0.3] }} transition={{ duration: 1, repeat: Infinity }} className="flex items-center gap-2">
                <div className="flex gap-0.5">{[0,1,2].map(i => <motion.div key={i} animate={{ y: [0, -3, 0] }} transition={{ duration: 0.5, repeat: Infinity, delay: i * 0.1 }} className="w-1 h-1 rounded-full" style={{ background: 'var(--accent)' }} />)}</div>
                <span className="text-[9px] font-mono" style={{ color: 'var(--text-muted)' }}>streaming...</span>
                <button onClick={stopGeneration} className="ml-2 flex items-center gap-1 px-2 py-0.5 rounded-md text-[9px] font-semibold transition-colors" style={{ background: 'rgba(239,68,68,0.1)', color: '#ef4444' }}><Square size={8} />Stop</button>
              </motion.div>
            </div>
          </motion.div>
        )}

        {loading && !streamingText && <ThinkingAnimation status={agentStatus} />}
        {error && <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="rounded-2xl p-3 text-xs" style={{ background: 'rgba(239,68,68,0.08)', border: '1px solid rgba(239,68,68,0.15)', color: '#ef4444' }}>⚠ {error}</motion.div>}
      </div>

      <ChatInput onSend={handleSend} loading={loading} />
    </div>
  );
}

// Renders streaming text with live code block detection
function StreamingContent({ text }: { text: string }) {
  const segments = parseContentLive(text);
  return <div className="space-y-2">{segments.map((seg, i) => seg.type === 'text' ? <div key={i} className="rounded-2xl rounded-tl-md px-4 py-3" style={{ background: 'var(--bg-input)', border: '1px solid var(--border)' }}><RichLines text={seg.value} /></div> : <div key={i} className="rounded-xl overflow-hidden" style={{ border: '1px solid var(--border)', background: '#0a0a14' }}><div className="flex items-center gap-2 px-3 py-1.5" style={{ background: 'rgba(255,255,255,0.03)', borderBottom: '1px solid var(--border)' }}><FileCode size={10} style={{ color: 'var(--accent)' }} /><span className="text-[10px] font-mono" style={{ color: 'var(--text-muted)' }}>{seg.filename || seg.lang || 'code'}</span></div><pre className="p-3 overflow-x-auto"><code className="text-[11px] leading-[18px] font-mono" style={{ color: '#86efac' }}>{seg.value}</code></pre></div>)}</div>;
}

function parseContentLive(content: string) {
  const segs: Array<{ type: 'text' | 'code'; value: string; lang?: string; filename?: string }> = [];
  const rx = /```([\w+#.-]*):?([^\n]*)\n([\s\S]*?)(?:```|$)/g;
  let last = 0, m;
  while ((m = rx.exec(content)) !== null) {
    if (m.index > last) { const t = content.slice(last, m.index).trim(); if (t) segs.push({ type: 'text', value: t }); }
    segs.push({ type: 'code', value: m[3]?.trim() || '', lang: m[1] || 'text', filename: m[2]?.trim() || '' });
    last = m.index + m[0].length;
  }
  if (last < content.length) { const t = content.slice(last).trim(); if (t) segs.push({ type: 'text', value: t }); }
  if (segs.length === 0 && content.trim()) segs.push({ type: 'text', value: content.trim() });
  return segs;
}

function StatusPill({ status }: { status: string }) {
  const map: Record<string, { bg: string; color: string; label: string }> = {
    idle: { bg: 'var(--bg-input)', color: 'var(--text-muted)', label: 'Ready' },
    thinking: { bg: 'rgba(139,92,246,0.1)', color: '#a78bfa', label: 'Thinking' },
    reasoning: { bg: 'rgba(59,130,246,0.1)', color: '#60a5fa', label: 'Reasoning' },
    planning: { bg: 'rgba(6,182,212,0.1)', color: '#22d3ee', label: 'Planning' },
    coding: { bg: 'rgba(34,197,94,0.1)', color: '#4ade80', label: 'Coding' },
    researching: { bg: 'rgba(245,158,11,0.1)', color: '#fbbf24', label: 'Research' },
    optimizing: { bg: 'rgba(244,63,94,0.1)', color: '#fb7185', label: 'Optimizing' },
    complete: { bg: 'rgba(34,197,94,0.1)', color: '#4ade80', label: 'Done' },
    error: { bg: 'rgba(239,68,68,0.1)', color: '#f87171', label: 'Error' },
  };
  const c = map[status] || map.idle;
  const active = !['idle', 'error', 'complete'].includes(status);
  return <motion.div key={status} initial={{ scale: 0.85, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[9px] font-semibold uppercase tracking-wider shrink-0" style={{ background: c.bg, color: c.color }}>{active && <motion.div animate={{ opacity: [1, 0.3, 1] }} transition={{ duration: 1, repeat: Infinity }} className="w-1.5 h-1.5 rounded-full" style={{ background: 'currentColor' }} />}{c.label}</motion.div>;
}

function EmptyState({ onSuggest }: { onSuggest: (v: string) => void }) {
  const s = [{ e: '🐍', t: 'Snake game with neon' }, { e: '🌐', t: 'Portfolio website' }, { e: '📊', t: 'Dashboard' }, { e: '🎮', t: 'Platformer game' }, { e: '⚡', t: 'Todo app' }, { e: '🤖', t: 'AI chatbot' }];
  return <div className="flex flex-col items-center justify-center py-16 text-center px-4">
    <motion.div animate={{ y: [0, -10, 0] }} transition={{ duration: 3, repeat: Infinity, ease: 'easeInOut' }} className="relative mb-5"><span className="text-6xl">{'🍌'}</span></motion.div>
    <h3 className="text-lg font-semibold mb-1" style={{ color: 'var(--text-primary)' }}>What should we build?</h3>
    <p className="text-xs max-w-xs mb-6" style={{ color: 'var(--text-muted)' }}>100+ tools · Live streaming · Web search · 3 modes</p>
    <div className="flex flex-wrap gap-2 justify-center max-w-md">{s.map((x, i) => <motion.button key={i} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.06 + 0.2 }} onClick={() => onSuggest(`${x.e} ${x.t}`)} className="px-3 py-1.5 rounded-xl text-[11px] transition-all" style={{ background: 'var(--bg-input)', border: '1px solid var(--border)', color: 'var(--text-muted)' }}>{x.e} {x.t}</motion.button>)}</div>
  </div>;
}

function parseContent(content: string) {
  const segs: Array<{ type: 'text' | 'code'; value: string; lang?: string; filename?: string }> = [];
  const rx = /```([\w+#.-]*):?([^\n]*)\n([\s\S]*?)```/g;
  let last = 0, m;
  while ((m = rx.exec(content)) !== null) {
    if (m.index > last) { const t = content.slice(last, m.index).trim(); if (t) segs.push({ type: 'text', value: t }); }
    segs.push({ type: 'code', value: m[3]?.trim() || '', lang: m[1] || 'text', filename: m[2]?.trim() || '' });
    last = m.index + m[0].length;
  }
  if (last < content.length) { const t = content.slice(last).trim(); if (t) segs.push({ type: 'text', value: t }); }
  if (segs.length === 0 && content.trim()) segs.push({ type: 'text', value: content.trim() });
  return segs;
}

function RichTextWithWidgets({ text }: { text: string }) {
  const segs = parseWidgets(text);
  return <div className="space-y-1">{segs.map((seg, i) => seg.type === 'widget' ? <AgentWidget key={i} type={seg.widgetType!} config={seg.widgetConfig!} /> : <RichLines key={i} text={seg.value} />)}</div>;
}

function RichLines({ text }: { text: string }) {
  return <>{text.split('\n').map((line, i) => {
    if (line.startsWith('### ')) return <h4 key={i} className="text-[12px] font-semibold mt-2" style={{ color: 'var(--text-secondary)' }}>{line.slice(4)}</h4>;
    if (line.startsWith('## ')) return <h3 key={i} className="text-[13px] font-bold mt-2.5" style={{ color: 'var(--accent)' }}>{line.slice(3)}</h3>;
    if (line.startsWith('# ')) return <h2 key={i} className="text-sm font-bold mt-2.5" style={{ color: 'var(--accent)' }}>{line.slice(2)}</h2>;
    if (line.startsWith('- ') || line.startsWith('* ')) return <div key={i} className="flex items-start gap-2 text-[12px]" style={{ color: 'var(--text-body)' }}><span className="mt-1.5 shrink-0 w-1 h-1 rounded-full" style={{ background: 'var(--accent)' }} /><span>{inl(line.slice(2))}</span></div>;
    const nm = line.match(/^(\d+)\.\s/);
    if (nm) return <div key={i} className="flex items-start gap-2 text-[12px]" style={{ color: 'var(--text-body)' }}><span className="font-mono text-[10px] mt-0.5 shrink-0 w-4 text-right" style={{ color: 'var(--accent)' }}>{nm[1]}.</span><span>{inl(line.slice(nm[0].length))}</span></div>;
    if (!line.trim()) return <div key={i} className="h-1.5" />;
    return <p key={i} className="text-[12px] leading-relaxed" style={{ color: 'var(--text-body)' }}>{inl(line)}</p>;
  })}</>;
}

function inl(text: string) {
  const parts: Array<string | { t: string; v: string }> = [];
  const rx = /(\*\*(.+?)\*\*|`(.+?)`|\*(.+?)\*)/g;
  let li = 0, m;
  while ((m = rx.exec(text)) !== null) { if (m.index > li) parts.push(text.slice(li, m.index)); if (m[2]) parts.push({ t: 'b', v: m[2] }); else if (m[3]) parts.push({ t: 'c', v: m[3] }); else if (m[4]) parts.push({ t: 'i', v: m[4] }); li = m.index + m[0].length; }
  if (li < text.length) parts.push(text.slice(li));
  return <>{parts.map((p, i) => typeof p === 'string' ? <span key={i}>{p}</span> : p.t === 'b' ? <strong key={i} style={{ color: 'var(--text-secondary)', fontWeight: 600 }}>{p.v}</strong> : p.t === 'c' ? <code key={i} className="px-1.5 py-0.5 rounded-md text-[10px] font-mono" style={{ background: 'var(--bg-hover)', color: 'var(--accent)' }}>{p.v}</code> : <em key={i} style={{ color: 'var(--text-muted)' }}>{p.v}</em>)}</>;
}

function MessageBubble({ message, onRegenerate, onEdit, editingId, editText, setEditText, onSaveEdit, onCancelEdit }: any) {
  const [copied, setCopied] = useState(false);
  const { setActiveTab } = useAgent();
  const isUser = message.role === 'user';
  const meta = message.metadata || {};
  const segments = !isUser ? parseContent(message.content) : [];
  const isEditing = editingId === message.id;

  return (
    <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3 }} className={`flex gap-3 ${isUser ? 'flex-row-reverse' : ''} max-w-3xl ${isUser ? 'ml-auto' : ''}`}>
      <div className={`w-7 h-7 rounded-xl flex items-center justify-center text-[11px] shrink-0 mt-0.5 shadow-md ${isUser ? 'bg-gradient-to-br from-blue-500 to-indigo-600 shadow-blue-500/15' : 'bg-gradient-to-br from-amber-400 to-orange-500 shadow-amber-500/15'}`}>{isUser ? '👤' : '🍌'}</div>
      <div className={`flex-1 min-w-0 ${isUser ? 'flex flex-col items-end' : ''}`}>
        {isUser ? (
          <div className="group relative">
            {isEditing ? (
              <div className="rounded-2xl rounded-tr-md p-2" style={{ background: 'rgba(59,130,246,0.12)', border: '1px solid rgba(59,130,246,0.2)' }}>
                <textarea value={editText} onChange={(e) => setEditText(e.target.value)} className="w-full bg-transparent text-[13px] resize-none focus:outline-none min-h-[40px]" style={{ color: 'rgba(191,219,254,0.9)' }} autoFocus />
                <div className="flex gap-1.5 mt-1"><button onClick={() => onSaveEdit(editText)} className="px-2.5 py-1 rounded-lg text-[10px] font-semibold" style={{ background: 'rgba(59,130,246,0.2)', color: '#60a5fa' }}>Save & Send</button><button onClick={onCancelEdit} className="px-2.5 py-1 rounded-lg text-[10px]" style={{ background: 'var(--bg-input)', color: 'var(--text-muted)' }}>Cancel</button></div>
              </div>
            ) : (
              <><div className="inline-block rounded-2xl rounded-tr-md px-4 py-2.5 text-[13px] leading-relaxed max-w-full" style={{ background: 'rgba(59,130,246,0.12)', border: '1px solid rgba(59,130,246,0.15)', color: 'rgba(191,219,254,0.9)' }}><div className="whitespace-pre-wrap break-words">{message.content}</div></div>
              <button onClick={() => onEdit(message.id, message.content)} className="absolute -bottom-5 right-0 opacity-0 group-hover:opacity-100 text-[9px] flex items-center gap-1 transition-opacity" style={{ color: 'var(--text-muted)' }}><Pencil size={9} />Edit</button></>
            )}
          </div>
        ) : (
          <div className="space-y-2.5 max-w-full">
            {segments.map((seg, i) => seg.type === 'text' ? <div key={i} className="rounded-2xl rounded-tl-md px-4 py-3" style={{ background: 'var(--bg-input)', border: '1px solid var(--border)' }}><RichTextWithWidgets text={seg.value} /></div> : <CodeBlock key={i} code={seg.value} language={seg.lang || 'text'} filename={seg.filename} />)}
            {meta.code_files?.length > 0 && <button onClick={() => setActiveTab('code')} className="flex items-center gap-2 px-3 py-2 rounded-xl w-full transition-colors" style={{ background: 'rgba(34,197,94,0.05)', border: '1px solid rgba(34,197,94,0.1)' }}><FileCode size={12} style={{ color: '#4ade80' }} /><span className="text-[10px] font-medium" style={{ color: 'rgba(74,222,128,0.6)' }}>{meta.code_files.length} file{meta.code_files.length > 1 ? 's' : ''} → Open Editor</span></button>}
            <div className="flex items-center gap-2 pt-0.5">
              <button onClick={() => { navigator.clipboard.writeText(message.content); setCopied(true); setTimeout(() => setCopied(false), 2000); }} className="transition-colors" style={{ color: 'var(--text-muted)' }} title="Copy">{copied ? <Check size={11} /> : <Copy size={11} />}</button>
              <button onClick={() => { const prev = [...(window as any).__msgs || []].reverse().find((m: any) => m.role === 'user'); if (prev) onRegenerate(prev.content); }} className="flex items-center gap-1 text-[9px] transition-colors" style={{ color: 'var(--text-muted)' }} title="Regenerate"><RefreshCw size={10} /></button>
              {meta.model_used && <span className="text-[8px] font-mono" style={{ color: 'var(--text-muted)' }}>{meta.model_used}</span>}
            </div>
          </div>
        )}
      </div>
    </motion.div>
  );
}
