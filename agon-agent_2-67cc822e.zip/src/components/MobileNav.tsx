import { MessageSquare, Code, Activity, Menu } from 'lucide-react';
import { useAgent } from '../context/AgentContext';
import { motion } from 'framer-motion';

export default function MobileNav({ onOpenSidebar }: { onOpenSidebar: () => void }) {
  const { agentStatus, files, activeTab, setActiveTab } = useAgent();
  const tabs = [
    { id: 'sessions', icon: Menu, label: 'Menu' },
    { id: 'chat', icon: MessageSquare, label: 'Chat' },
    { id: 'code', icon: Code, label: 'Editor' },
    { id: 'actions', icon: Activity, label: 'Actions' },
  ];
  return (
    <div className="flex items-center safe-bottom" style={{ background: 'var(--bg-sidebar)', borderTop: '1px solid var(--border)' }}>
      {tabs.map(tab => {
        const isActive = activeTab === tab.id;
        const Icon = tab.icon;
        const dot = (tab.id === 'chat' && agentStatus !== 'idle') || (tab.id === 'code' && files.length > 0);
        return (
          <button key={tab.id} onClick={() => tab.id === 'sessions' ? onOpenSidebar() : setActiveTab(tab.id)}
            className="flex-1 flex flex-col items-center gap-0.5 py-2.5 relative transition-colors duration-200"
            style={{ color: isActive ? 'var(--accent)' : 'var(--text-muted)' }}>
            {isActive && <motion.div layoutId="mob-nav" className="absolute -top-px left-1/2 -translate-x-1/2 w-8 h-[2px] rounded-full" style={{ background: 'var(--accent)' }} transition={{ type: 'spring', damping: 30, stiffness: 400 }} />}
            <div className="relative">
              <Icon size={18} strokeWidth={isActive ? 2.2 : 1.5} />
              {dot && <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} className="absolute -top-0.5 -right-0.5 w-1.5 h-1.5 rounded-full" style={{ background: 'var(--accent)' }} />}
            </div>
            <span className="text-[8px] font-semibold uppercase tracking-wider">{tab.label}</span>
          </button>
        );
      })}
    </div>
  );
}
