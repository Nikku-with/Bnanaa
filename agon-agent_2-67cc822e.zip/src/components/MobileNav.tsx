import { MessageSquare, Code, Activity, Menu, Play } from 'lucide-react';
import { useAgent } from '../context/AgentContext';
import { motion } from 'framer-motion';

interface MobileNavProps {
  activeTab: 'chat' | 'code' | 'actions' | 'sessions';
  setActiveTab: (tab: 'chat' | 'code' | 'actions' | 'sessions') => void;
  onOpenSidebar: () => void;
}

export default function MobileNav({ activeTab, setActiveTab, onOpenSidebar }: MobileNavProps) {
  const { agentStatus, recentActions, files } = useAgent();

  const tabs = [
    { id: 'sessions' as const, icon: Menu, label: 'Menu', badge: null },
    { id: 'chat' as const, icon: MessageSquare, label: 'Chat', badge: agentStatus !== 'idle' ? '●' : null },
    { id: 'code' as const, icon: Code, label: 'Editor', badge: files.length > 0 ? String(files.length) : null },
    { id: 'actions' as const, icon: Activity, label: 'Actions', badge: recentActions.length > 0 ? String(Math.min(recentActions.length, 99)) : null },
  ];

  return (
    <div className="bg-[#06060a] border-t border-white/5 flex items-center safe-bottom">
      {tabs.map(tab => {
        const isActive = activeTab === tab.id;
        const Icon = tab.icon;
        return (
          <button
            key={tab.id}
            onClick={() => {
              if (tab.id === 'sessions') onOpenSidebar();
              else setActiveTab(tab.id);
            }}
            className={`flex-1 flex flex-col items-center gap-0.5 py-2 relative transition-colors ${
              isActive ? 'text-yellow-400' : 'text-white/25'
            }`}
          >
            {isActive && (
              <motion.div
                layoutId="mobile-tab-glow"
                className="absolute -top-px left-1/2 -translate-x-1/2 w-10 h-[2px] rounded-full bg-yellow-400 shadow-sm shadow-yellow-400/50"
                transition={{ type: 'spring', damping: 25, stiffness: 300 }}
              />
            )}
            <div className="relative">
              <Icon size={17} strokeWidth={isActive ? 2.5 : 1.5} />
              {tab.badge && (
                <motion.span
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  className="absolute -top-1.5 -right-2.5 min-w-[12px] h-[12px] flex items-center justify-center text-[7px] font-bold text-black bg-yellow-400 rounded-full px-0.5"
                >{tab.badge}</motion.span>
              )}
            </div>
            <span className="text-[8px] font-bold uppercase tracking-wider">{tab.label}</span>
          </button>
        );
      })}
    </div>
  );
}
