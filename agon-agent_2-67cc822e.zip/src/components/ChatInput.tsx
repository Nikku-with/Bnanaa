import { useState, useRef } from 'react';
import { useAgent } from '../context/AgentContext';
import { motion, AnimatePresence } from 'framer-motion';
import { ArrowUp, Loader2, Globe, ChevronUp, Sparkles, Zap, Box, Wand2 } from 'lucide-react';

interface ChatInputProps { onSend: (msg: string, mode: string, webSearch: boolean, customPrompt?: string) => void; loading: boolean; }

export default function ChatInput({ onSend, loading }: ChatInputProps) {
  const { settings } = useAgent();
  const [input, setInput] = useState('');
  const [showDrop, setShowDrop] = useState(false);
  const [webSearch, setWebSearch] = useState(false);
  const [mode, setMode] = useState('normal');
  const ref = useRef<HTMLTextAreaElement>(null);

  const builtins: Record<string, { label: string; icon: any; color: string }> = {
    normal: { label: 'Normal', icon: Sparkles, color: 'var(--text-muted)' },
    '3d_max': { label: '3D Max', icon: Box, color: '#8b5cf6' },
    advanced: { label: 'Advanced', icon: Zap, color: 'var(--accent)' },
  };
  const customs = (settings.customModes || []).map(cm => ({
    key: `custom_${cm.name}`, label: cm.name, icon: Wand2, color: '#ec4899', prompt: cm.prompt
  }));
  const allModes = [
    ...Object.entries(builtins).map(([k, v]) => ({ key: k, ...v, prompt: undefined as string | undefined })),
    ...customs
  ];
  const cur = allModes.find(m => m.key === mode) || allModes[0];
  const CurIcon = cur.icon;

  const send = () => {
    if (!input.trim() || loading) return;
    const isCustom = mode.startsWith('custom_');
    const cp = isCustom ? customs.find(c => c.key === mode)?.prompt : undefined;
    onSend(input, isCustom ? 'custom' : mode, webSearch, cp);
    setInput('');
    if (ref.current) ref.current.style.height = '46px';
  };

  return (
    <div className="shrink-0" style={{ borderTop: '1px solid var(--border)', background: 'var(--bg-secondary)' }}>
      <div className="px-3 pt-2 pb-1 flex items-center gap-1.5 flex-wrap">
        <div className="relative">
          <button onClick={() => setShowDrop(!showDrop)}
            className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-[10px] font-semibold transition-colors"
            style={{ background: 'var(--bg-input)', border: '1px solid var(--border)', color: cur.color }}>
            <CurIcon size={10} />{cur.label}<ChevronUp size={8} className={`transition-transform ${showDrop ? '' : 'rotate-180'}`} />
          </button>
          <AnimatePresence>
            {showDrop && (
              <motion.div initial={{ opacity: 0, y: 5 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 5 }}
                className="absolute bottom-full left-0 mb-1 rounded-xl shadow-2xl overflow-hidden z-20 min-w-[160px] max-h-[220px] overflow-y-auto scrollbar-thin"
                style={{ background: 'var(--bg-secondary)', border: '1px solid var(--border-strong)' }}>
                {allModes.map(m => {
                  const I = m.icon;
                  return (
                    <button key={m.key} onClick={() => { setMode(m.key); setShowDrop(false); }}
                      className="w-full flex items-center gap-2 px-3 py-2 text-[11px] font-medium transition-colors"
                      style={{ color: mode === m.key ? m.color : 'var(--text-muted)', background: mode === m.key ? 'var(--bg-hover)' : 'transparent' }}>
                      <I size={12} />{m.label}{mode === m.key && <span className="ml-auto text-[8px]">●</span>}
                    </button>
                  );
                })}
              </motion.div>
            )}
          </AnimatePresence>
        </div>
        <button onClick={() => setWebSearch(!webSearch)}
          className="flex items-center gap-1 px-2 py-1 rounded-lg text-[10px] font-semibold transition-colors"
          style={{ background: webSearch ? 'rgba(59,130,246,0.1)' : 'var(--bg-input)', border: `1px solid ${webSearch ? 'rgba(59,130,246,0.2)' : 'var(--border)'}`, color: webSearch ? 'var(--blue)' : 'var(--text-muted)' }}>
          <Globe size={10} />{webSearch ? 'Search ON' : 'Search'}
        </button>
      </div>
      <div className="px-3 pb-3 pt-1">
        <div className="flex gap-2 items-end max-w-3xl mx-auto">
          <textarea ref={ref} value={input} onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(); } }}
            placeholder="What do you want to build?" rows={1}
            className="flex-1 rounded-2xl px-4 py-3 text-[13px] resize-none focus:outline-none transition-all"
            style={{ background: 'var(--bg-input)', border: '1px solid var(--border)', color: 'var(--text-primary)', minHeight: '46px', maxHeight: '130px' }}
            onInput={(e) => { const t = e.currentTarget; t.style.height = 'auto'; t.style.height = Math.min(t.scrollHeight, 130) + 'px'; }} />
          <motion.button whileTap={{ scale: 0.9 }} onClick={send} disabled={loading || !input.trim()}
            className="h-[46px] w-[46px] rounded-2xl bg-gradient-to-br from-amber-500 to-orange-500 flex items-center justify-center text-black disabled:opacity-20 shadow-lg shadow-amber-500/15 shrink-0">
            {loading ? <Loader2 size={16} className="animate-spin" /> : <ArrowUp size={17} strokeWidth={2.5} />}
          </motion.button>
        </div>
      </div>
    </div>
  );
}
