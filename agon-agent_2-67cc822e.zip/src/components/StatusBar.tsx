import { useAgent } from '../context/AgentContext';
import { motion } from 'framer-motion';
import { Wifi, WifiOff, Cpu, Zap, Clock } from 'lucide-react';
import { useState, useEffect } from 'react';

export default function StatusBar() {
  const { agentStatus, settings } = useAgent();
  const [time, setTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const isConnected = !!settings.apiKey;

  return (
    <div className="h-6 bg-[#06060a] border-b border-white/5 flex items-center px-3 gap-3 text-[9px] font-mono text-white/30">
      <div className="flex items-center gap-1.5">
        <span className="text-yellow-400">🍌</span>
        <span className="font-bold text-white/50">BANANA</span>
        <span className="text-white/15">v2.0</span>
      </div>

      <div className="h-3 w-px bg-white/10" />

      <div className="flex items-center gap-1">
        {isConnected ? (
          <><Wifi size={8} className="text-green-400" /><span className="text-green-400/70">OK</span></>
        ) : (
          <><WifiOff size={8} className="text-red-400" /><span className="text-red-400/70">No Key</span></>
        )}
      </div>

      <div className="h-3 w-px bg-white/10" />

      <div className="flex items-center gap-1 truncate">
        <Cpu size={8} />
        <span className="truncate max-w-[120px]">{settings.model}</span>
      </div>

      {agentStatus !== 'idle' && (
        <>
          <div className="h-3 w-px bg-white/10" />
          <motion.div
            animate={{ opacity: [1, 0.4, 1] }}
            transition={{ duration: 1.5, repeat: Infinity }}
            className="flex items-center gap-1 text-yellow-400/70"
          >
            <Zap size={8} />
            <span className="uppercase">{agentStatus}</span>
          </motion.div>
        </>
      )}

      <div className="flex-1" />

      <span className="text-white/15 hidden lg:inline">LangChain + LangGraph</span>
      <div className="h-3 w-px bg-white/10 hidden lg:block" />

      <div className="flex items-center gap-1">
        <Clock size={8} />
        <span>{time.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
      </div>
    </div>
  );
}
