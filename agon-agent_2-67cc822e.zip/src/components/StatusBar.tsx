import { useAgent } from '../context/AgentContext';
import { useDevice } from '../hooks/useDevice';
import { motion } from 'framer-motion';
import { Cpu, Zap, Clock, Circle, Monitor, Tablet, Smartphone, BarChart3 } from 'lucide-react';
import { useState, useEffect } from 'react';

export default function StatusBar() {
  const { agentStatus, settings, totalTokens } = useAgent();
  const { device } = useDevice();
  const [time, setTime] = useState(new Date());
  useEffect(() => { const t = setInterval(() => setTime(new Date()), 1000); return () => clearInterval(t); }, []);
  const hasKey = settings.provider === 'groq' ? !!settings.groqKey : !!settings.apiKey;
  const DevIcon = device === 'mobile' ? Smartphone : device === 'tablet' ? Tablet : Monitor;

  return (
    <div className="h-7 border-b border-[var(--border)] flex items-center px-3.5 gap-3 text-[9px] font-mono" style={{ background: 'var(--bg-sidebar)', color: 'var(--text-muted)' }}>
      <div className="flex items-center gap-1.5"><span className="text-amber-400 text-[10px]">{'\ud83c\udf4c'}</span><span className="font-bold" style={{ color: 'var(--text-secondary)' }}>BANANA</span><span style={{ opacity: 0.4 }}>v3.1</span></div>
      <div className="h-3 w-px" style={{ background: 'var(--border)' }} />
      <div className="flex items-center gap-1.5">{hasKey ? <><Circle size={5} className="text-emerald-400 fill-emerald-400" /><span className="text-emerald-400/60">{settings.provider === 'groq' ? 'Groq' : 'OR'}</span></> : <><Circle size={5} className="text-red-400 fill-red-400" /><span className="text-red-400/60">No Key</span></>}</div>
      <div className="h-3 w-px" style={{ background: 'var(--border)' }} />
      <div className="flex items-center gap-1 truncate"><Cpu size={8} /><span className="truncate max-w-[100px]">{settings.model.split('/').pop()}</span></div>
      {agentStatus !== 'idle' && <><div className="h-3 w-px" style={{ background: 'var(--border)' }} /><motion.div animate={{ opacity: [1, 0.3, 1] }} transition={{ duration: 1.2, repeat: Infinity }} className="flex items-center gap-1 text-amber-400/60"><Zap size={8} /><span className="uppercase font-semibold">{agentStatus}</span></motion.div></>}
      {totalTokens > 0 && <><div className="h-3 w-px" style={{ background: 'var(--border)' }} /><div className="flex items-center gap-1 text-violet-400/50"><BarChart3 size={8} /><span>{totalTokens.toLocaleString()}t</span></div></>}
      <div className="flex-1" />
      <div className="flex items-center gap-1" style={{ opacity: 0.4 }}><DevIcon size={9} /><span className="capitalize">{device}</span></div>
      <div className="h-3 w-px" style={{ background: 'var(--border)' }} />
      <div className="flex items-center gap-1"><Clock size={8} /><span>{time.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span></div>
    </div>
  );
}
