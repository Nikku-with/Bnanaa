import { motion } from 'framer-motion';
import { Brain, Code, Search, Zap, Sparkles, Cpu, Layers, GitBranch } from 'lucide-react';

const statusConfig: Record<string, { icon: any; label: string; gradient: string; msg: string; particles: string }> = {
  thinking: { icon: Brain, label: 'Deep Thinking', gradient: 'from-purple-500 to-violet-600', msg: 'Analyzing your request with maximum cognitive power...', particles: 'bg-purple-400' },
  reasoning: { icon: GitBranch, label: 'LangChain Reasoning', gradient: 'from-blue-500 to-indigo-600', msg: 'Running multi-step reasoning chains...', particles: 'bg-blue-400' },
  planning: { icon: Layers, label: 'Architecture Planning', gradient: 'from-cyan-500 to-teal-600', msg: 'Designing optimal architecture & file structure...', particles: 'bg-cyan-400' },
  analyzing: { icon: Search, label: 'Code Analysis', gradient: 'from-indigo-500 to-blue-600', msg: 'Deep scanning codebase for patterns & bugs...', particles: 'bg-indigo-400' },
  coding: { icon: Code, label: 'Generating Code', gradient: 'from-green-500 to-emerald-600', msg: 'Writing production-ready code with 20+ bonus features...', particles: 'bg-green-400' },
  researching: { icon: Search, label: 'Web Research', gradient: 'from-amber-500 to-orange-600', msg: 'Searching docs, APIs, and best practices...', particles: 'bg-amber-400' },
  optimizing: { icon: Zap, label: 'Optimizing Output', gradient: 'from-pink-500 to-rose-600', msg: 'Refining, optimizing, and polishing everything...', particles: 'bg-pink-400' },
};

export default function ThinkingAnimation({ status }: { status: string }) {
  const config = statusConfig[status] || statusConfig.thinking;
  const Icon = config.icon;

  return (
    <motion.div
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ type: 'spring', damping: 20 }}
      className="flex gap-2.5"
    >
      {/* Animated Avatar */}
      <div className="relative shrink-0">
        <motion.div
          animate={{ rotate: [0, 360] }}
          transition={{ duration: 4, repeat: Infinity, ease: 'linear' }}
          className="w-8 h-8 rounded-xl bg-gradient-to-br from-yellow-400 to-orange-500 flex items-center justify-center text-sm shadow-lg shadow-yellow-500/30"
        >
          {'🍌'}
        </motion.div>
        {/* Orbiting particles */}
        {[0, 1, 2].map(i => (
          <motion.div
            key={i}
            animate={{
              rotate: [i * 120, i * 120 + 360],
            }}
            transition={{ duration: 2 + i * 0.3, repeat: Infinity, ease: 'linear' }}
            className="absolute inset-0"
            style={{ transformOrigin: 'center center' }}
          >
            <motion.div
              animate={{ scale: [0.5, 1, 0.5], opacity: [0.3, 1, 0.3] }}
              transition={{ duration: 1.5, repeat: Infinity, delay: i * 0.3 }}
              className={`absolute -top-1 left-1/2 w-1.5 h-1.5 rounded-full ${config.particles}`}
            />
          </motion.div>
        ))}
      </div>

      <div className="flex-1 min-w-0">
        <motion.div
          className={`bg-gradient-to-r ${config.gradient} p-[1px] rounded-2xl`}
          animate={{ opacity: [0.6, 1, 0.6] }}
          transition={{ duration: 2, repeat: Infinity }}
        >
          <div className="bg-[#0b0b14] rounded-2xl px-3.5 py-3">
            {/* Status Header with animated icon */}
            <div className="flex items-center gap-2 mb-2.5">
              <motion.div
                animate={{ rotate: [0, 15, -15, 0], scale: [1, 1.2, 1] }}
                transition={{ duration: 1.5, repeat: Infinity }}
                className={`w-6 h-6 rounded-lg bg-gradient-to-br ${config.gradient} flex items-center justify-center shadow-lg`}
              >
                <Icon size={12} className="text-white" />
              </motion.div>
              <div>
                <motion.span
                  animate={{ opacity: [0.7, 1, 0.7] }}
                  transition={{ duration: 1.5, repeat: Infinity }}
                  className="text-[10px] font-black uppercase tracking-wider text-white/80 block"
                >{config.label}</motion.span>
              </div>
            </div>

            {/* Animated message */}
            <motion.p
              key={config.msg}
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: [0.5, 0.8, 0.5], x: 0 }}
              transition={{ duration: 3, repeat: Infinity }}
              className="text-[11px] text-white/40 mb-3"
            >{config.msg}</motion.p>

            {/* Workflow pipeline */}
            <div className="flex items-center gap-1 mb-3">
              {['Parse', 'Reason', 'Plan', 'Code', 'Test', 'Ship'].map((step, i) => (
                <motion.div
                  key={step}
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ delay: i * 0.15, type: 'spring' }}
                  className="flex items-center gap-1"
                >
                  <motion.div
                    animate={{
                      backgroundColor: i <= (['thinking','reasoning','planning','analyzing','coding','optimizing'].indexOf(status) + 1)
                        ? ['rgba(234,179,8,0.3)', 'rgba(234,179,8,0.7)', 'rgba(234,179,8,0.3)']
                        : 'rgba(255,255,255,0.05)'
                    }}
                    transition={{ duration: 1.5, repeat: Infinity, delay: i * 0.2 }}
                    className="px-1.5 py-0.5 rounded text-[7px] font-bold uppercase tracking-wider text-white/40"
                  >{step}</motion.div>
                  {i < 5 && <span className="text-white/10 text-[8px]">→</span>}
                </motion.div>
              ))}
            </div>

            {/* Progress bars with glow */}
            <div className="space-y-1.5">
              {[
                { label: 'LangChain', color: 'from-purple-500 to-violet-500', shadow: 'shadow-purple-500/30' },
                { label: 'LangGraph', color: 'from-cyan-500 to-blue-500', shadow: 'shadow-cyan-500/30' },
                { label: 'Tools', color: 'from-green-500 to-emerald-500', shadow: 'shadow-green-500/30' },
              ].map((bar, i) => (
                <div key={i} className="flex items-center gap-2">
                  <span className="text-[8px] text-white/25 w-14 shrink-0 font-mono">{bar.label}</span>
                  <div className="flex-1 h-1 bg-white/5 rounded-full overflow-hidden">
                    <motion.div
                      animate={{ width: ['0%', '85%', '40%', '100%', '60%'] }}
                      transition={{ duration: 3 + i * 0.5, repeat: Infinity, ease: 'easeInOut', delay: i * 0.3 }}
                      className={`h-full rounded-full bg-gradient-to-r ${bar.color} shadow-sm ${bar.shadow}`}
                    />
                  </div>
                </div>
              ))}
            </div>

            {/* Bouncing dots with trail */}
            <div className="flex items-center gap-1.5 mt-3">
              {[0, 1, 2, 3, 4].map(i => (
                <motion.div
                  key={i}
                  animate={{
                    y: [0, -6, 0],
                    opacity: [0.2, 1, 0.2],
                    scale: [0.8, 1.2, 0.8],
                  }}
                  transition={{ duration: 0.8, repeat: Infinity, delay: i * 0.1 }}
                  className={`w-1.5 h-1.5 rounded-full bg-gradient-to-br ${config.gradient}`}
                />
              ))}
              <motion.span
                animate={{ opacity: [0, 1, 0] }}
                transition={{ duration: 2, repeat: Infinity }}
                className="text-[8px] text-white/20 font-mono ml-1"
              >processing...</motion.span>
            </div>
          </div>
        </motion.div>
      </div>
    </motion.div>
  );
}
