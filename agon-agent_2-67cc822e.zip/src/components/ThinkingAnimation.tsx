import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Brain, Code, Search, Zap, Sparkles, Layers, GitBranch } from 'lucide-react';

const P = [
  { icon: Brain, label: 'Analyzing', msg: 'Breaking down your request...', code: 'analyze(request, context)' },
  { icon: GitBranch, label: 'Reasoning', msg: 'Multi-step reasoning chains...', code: 'chain.invoke({ input, memory })' },
  { icon: Layers, label: 'Architecting', msg: 'Planning file structure...', code: 'plan(requirements)' },
  { icon: Search, label: 'Researching', msg: 'Checking docs & best practices...', code: 'search("latest 2025")' },
  { icon: Code, label: 'Coding', msg: 'Writing production code...', code: 'generate({ quality: max })' },
  { icon: Zap, label: 'Optimizing', msg: 'Polishing everything...', code: 'optimize(output)' },
  { icon: Sparkles, label: 'Finalizing', msg: 'Preparing delivery...', code: 'deliver(solution)' },
];

export default function ThinkingAnimation({ status }: { status: string }) {
  const [ph, setPh] = useState(0);
  const [typed, setTyped] = useState('');
  useEffect(() => { const t = setInterval(() => setPh(p => (p + 1) % P.length), 3000); return () => clearInterval(t); }, []);
  useEffect(() => { const c = P[ph].code; setTyped(''); let i = 0; const t = setInterval(() => { if (i <= c.length) { setTyped(c.slice(0, i)); i++; } else clearInterval(t); }, 35); return () => clearInterval(t); }, [ph]);
  const p = P[ph]; const I = p.icon;

  return (
    <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} className="flex gap-3 max-w-3xl">
      <div className="relative shrink-0">
        <motion.div animate={{ rotate: [0, 360] }} transition={{ duration: 4, repeat: Infinity, ease: 'linear' }} className="w-7 h-7 rounded-xl bg-[var(--accent)] flex items-center justify-center text-sm text-black shadow-md">{'🍌'}</motion.div>
      </div>
      <div className="flex-1 min-w-0">
        <motion.div key={ph} initial={{ opacity: 0, y: 4 }} animate={{ opacity: 1, y: 0 }} className="border border-[var(--border-strong)] rounded-2xl bg-[var(--bg-secondary)] px-4 py-3">
          <div className="flex items-center gap-2 mb-2">
            <motion.div animate={{ rotate: [0, 10, -10, 0] }} transition={{ duration: 1.5, repeat: Infinity }} className="w-5 h-5 rounded-lg bg-[var(--accent-dim)] flex items-center justify-center"><I size={11} className="text-[var(--accent)]" /></motion.div>
            <span className="text-[10px] font-bold text-[var(--text-secondary)] uppercase tracking-wider">{p.label}</span>
            <span className="text-[8px] text-[var(--text-muted)] font-mono ml-auto">{ph + 1}/{P.length}</span>
          </div>
          <motion.p animate={{ opacity: [0.4, 0.7, 0.4] }} transition={{ duration: 2, repeat: Infinity }} className="text-[11px] text-[var(--text-body)] mb-2">{p.msg}</motion.p>
          <div className="bg-black/20 rounded-lg px-3 py-1.5 mb-2 font-mono"><span className="text-[10px] text-[var(--green)]/70">{typed}</span><motion.span animate={{ opacity: [1, 0, 1] }} transition={{ duration: 0.7, repeat: Infinity }} className="text-[var(--accent)]">|</motion.span></div>
          <div className="flex gap-0.5 mb-2">{P.map((_, i) => <div key={i} className={`h-0.5 flex-1 rounded-full ${i <= ph ? 'bg-[var(--accent)]' : 'bg-white/[0.04]'}`} />)}</div>
          <div className="flex gap-1">{[0,1,2,3].map(i => <motion.div key={i} animate={{ y: [0, -4, 0], opacity: [0.2, 0.8, 0.2] }} transition={{ duration: 0.6, repeat: Infinity, delay: i * 0.08 }} className="w-1 h-1 rounded-full bg-[var(--accent)]" />)}</div>
        </motion.div>
      </div>
    </motion.div>
  );
}
