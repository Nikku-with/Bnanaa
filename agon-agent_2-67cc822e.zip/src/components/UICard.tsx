import { useState } from 'react';
import { motion } from 'framer-motion';
import { useAgent } from '../context/AgentContext';
import { MessageSquare, CheckCircle, HelpCircle, ListTodo, X } from 'lucide-react';

interface UICardProps {
  card: {
    type: 'question' | 'choice' | 'info' | 'todo';
    title: string;
    content: string;
    options?: string[];
    input_needed?: boolean;
  };
}

export default function UICard({ card }: UICardProps) {
  const { sendMessage } = useAgent();
  const [inputVal, setInputVal] = useState('');
  const [dismissed, setDismissed] = useState(false);
  const [selectedOption, setSelectedOption] = useState<string | null>(null);

  if (dismissed) return null;

  const typeConfig = {
    question: { icon: HelpCircle, color: 'from-purple-500/20 to-indigo-500/20', border: 'border-purple-500/20', accent: 'text-purple-400' },
    choice: { icon: ListTodo, color: 'from-cyan-500/20 to-blue-500/20', border: 'border-cyan-500/20', accent: 'text-cyan-400' },
    info: { icon: MessageSquare, color: 'from-green-500/20 to-emerald-500/20', border: 'border-green-500/20', accent: 'text-green-400' },
    todo: { icon: CheckCircle, color: 'from-amber-500/20 to-yellow-500/20', border: 'border-amber-500/20', accent: 'text-amber-400' },
  };

  const config = typeConfig[card.type] || typeConfig.info;
  const Icon = config.icon;

  const handleSubmit = async (value: string) => {
    await sendMessage(`[UI Card Response] ${card.title}: ${value}`);
    setDismissed(true);
  };

  const handleSkip = () => {
    sendMessage(`[UI Card Skipped] ${card.title} - AI should auto-fill`);
    setDismissed(true);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 10, scale: 0.95 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      className={`bg-gradient-to-br ${config.color} border ${config.border} rounded-xl p-4 relative`}
    >
      {/* Close / Skip */}
      <div className="absolute top-2 right-2 flex gap-1">
        <button
          onClick={handleSkip}
          className="text-[9px] text-white/30 hover:text-white/60 px-2 py-0.5 rounded-full bg-white/5 transition-all"
        >
          Skip (AI fills)
        </button>
        <button onClick={() => setDismissed(true)} className="text-white/20 hover:text-white/50 transition-all">
          <X size={12} />
        </button>
      </div>

      {/* Header */}
      <div className="flex items-center gap-2 mb-2">
        <Icon size={14} className={config.accent} />
        <span className={`text-xs font-bold ${config.accent}`}>{card.title}</span>
      </div>

      {/* Content */}
      <p className="text-xs text-white/60 mb-3 leading-relaxed">{card.content}</p>

      {/* Options */}
      {card.options && card.options.length > 0 && (
        <div className="flex flex-wrap gap-1.5 mb-3">
          {card.options.map((opt, i) => (
            <button
              key={i}
              onClick={() => { setSelectedOption(opt); handleSubmit(opt); }}
              className={`px-3 py-1 rounded-lg text-xs font-medium transition-all ${
                selectedOption === opt
                  ? 'bg-yellow-500/30 text-yellow-400 border border-yellow-500/30'
                  : 'bg-white/5 text-white/50 border border-white/10 hover:bg-white/10 hover:text-white/80'
              }`}
            >
              {opt}
            </button>
          ))}
        </div>
      )}

      {/* Input */}
      {card.input_needed && (
        <div className="flex gap-2">
          <input
            value={inputVal}
            onChange={(e) => setInputVal(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && inputVal.trim() && handleSubmit(inputVal)}
            placeholder="Type your answer..."
            className="flex-1 bg-white/5 border border-white/10 rounded-lg px-3 py-1.5 text-xs text-white placeholder-white/20 focus:outline-none focus:border-yellow-500/30"
          />
          <button
            onClick={() => inputVal.trim() && handleSubmit(inputVal)}
            className="px-3 py-1.5 bg-yellow-500/20 text-yellow-400 rounded-lg text-xs font-bold hover:bg-yellow-500/30 transition-all"
          >
            Send
          </button>
        </div>
      )}
    </motion.div>
  );
}
