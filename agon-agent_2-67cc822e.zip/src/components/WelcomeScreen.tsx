import { useAgent } from '../context/AgentContext';
import { motion } from 'framer-motion';
import { Zap, Brain, Code, Search, FileCode, Wrench, Sparkles, Rocket, Menu, ArrowRight, ExternalLink, Globe, Cpu, Shield, Database, Terminal, GitBranch, Layers } from 'lucide-react';

export default function WelcomeScreen({ onOpenSidebar }: { onOpenSidebar?: () => void }) {
  const { createSession, setShowSettings, settings } = useAgent();
  const features = [
    { icon: Brain, label: 'Deep Reasoning' }, { icon: Zap, label: 'LangGraph Engine' },
    { icon: Code, label: '100+ Tools' }, { icon: Search, label: 'Web Search' },
    { icon: FileCode, label: 'Monaco IDE' }, { icon: Wrench, label: 'Auto-Fix' },
    { icon: Sparkles, label: 'Live Preview' }, { icon: Rocket, label: 'Max Output' },
    { icon: Globe, label: 'Pollinations' }, { icon: Cpu, label: '3 AI Modes' },
    { icon: Shield, label: 'Memory' }, { icon: Database, label: 'File Manager' },
    { icon: Terminal, label: 'Code Runner' }, { icon: GitBranch, label: 'Git Ops' },
    { icon: Layers, label: 'Widgets' }, { icon: Wrench, label: 'Custom Modes' },
  ];
  return (
    <div className="flex-1 flex flex-col items-center overflow-y-auto min-h-0 px-5 py-8 md:py-14 md:justify-center">
      {onOpenSidebar && <button onClick={onOpenSidebar} className="md:hidden self-start mb-4 flex items-center gap-2 px-3 py-1.5 rounded-lg bg-[var(--bg-input)] border border-[var(--border)] text-xs text-[var(--text-body)]"><Menu size={14} />Sessions</button>}
      <div className="max-w-lg w-full">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center mb-8">
          <motion.div animate={{ y: [0, -6, 0] }} transition={{ duration: 3, repeat: Infinity }} className="text-5xl mb-4 inline-block">{'🍌'}</motion.div>
          <h1 className="text-2xl md:text-3xl font-extrabold tracking-tight mb-2"><span className="text-[var(--accent)]">BANANA AGENT</span></h1>
          <p className="text-[var(--text-body)] text-sm max-w-sm mx-auto">Elite AI coding engine. 100+ tools. OpenRouter + Pollinations. Web search. Memory. 3 modes.</p>
        </motion.div>
        <div className="grid grid-cols-4 md:grid-cols-8 gap-1.5 mb-8">
          {features.map((f, i) => <motion.div key={i} initial={{ opacity: 0, scale: 0.8 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: i * 0.03 }} className="flex flex-col items-center gap-1 py-2 px-1 rounded-xl bg-[var(--bg-input)] border border-[var(--border)] hover:bg-[var(--bg-hover)] transition-colors">
            <f.icon size={14} className="text-[var(--text-body)]" />
            <span className="text-[7px] text-[var(--text-muted)] font-medium text-center leading-tight">{f.label}</span>
          </motion.div>)}
        </div>
        <motion.div initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }} className="flex flex-col items-center gap-3">
          <button onClick={createSession} className="group px-8 py-3 rounded-2xl bg-[var(--text-primary)] text-[var(--bg-primary)] font-bold text-sm flex items-center gap-2 hover:opacity-90 active:scale-95 transition-all"><Rocket size={15} />Start Building<ArrowRight size={14} className="group-hover:translate-x-0.5 transition-transform" /></button>
          {!settings.apiKey && settings.provider === 'openrouter' && <button onClick={() => setShowSettings(true)} className="text-[11px] text-[var(--text-muted)] hover:text-[var(--accent)] flex items-center gap-1"><ExternalLink size={10} />Setup API key</button>}
          
        </motion.div>
      </div>
    </div>
  );
}
