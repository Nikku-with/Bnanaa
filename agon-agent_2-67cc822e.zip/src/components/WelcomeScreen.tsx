import { useAgent } from '../context/AgentContext';
import { motion } from 'framer-motion';
import { Zap, Brain, Code, Search, FileCode, Wrench, Sparkles, Rocket, Menu } from 'lucide-react';

interface WelcomeScreenProps {
  onOpenSidebar?: () => void;
}

export default function WelcomeScreen({ onOpenSidebar }: WelcomeScreenProps) {
  const { createSession, setShowSettings, settings } = useAgent();

  const features = [
    { icon: Brain, label: 'Deep Reasoning', desc: 'LangChain multi-step', color: 'from-purple-500 to-indigo-500' },
    { icon: Zap, label: 'LangGraph', desc: 'Autonomous loops', color: 'from-yellow-500 to-orange-500' },
    { icon: Code, label: '50+ Tools', desc: 'Create, edit, analyze', color: 'from-green-500 to-emerald-500' },
    { icon: Search, label: 'Web Research', desc: 'Real-time search', color: 'from-blue-500 to-cyan-500' },
    { icon: FileCode, label: 'File Manager', desc: 'Full IDE editor', color: 'from-pink-500 to-rose-500' },
    { icon: Wrench, label: 'Auto-Fix', desc: 'Bug detection', color: 'from-amber-500 to-yellow-500' },
    { icon: Sparkles, label: 'AI Cards', desc: 'Dynamic interactions', color: 'from-violet-500 to-purple-500' },
    { icon: Rocket, label: 'Max Output', desc: '20+ auto-features', color: 'from-red-500 to-orange-500' },
  ];

  return (
    <div className="flex-1 flex flex-col items-center overflow-y-auto min-h-0 bg-[#0a0a0f] px-4 py-6 md:py-10 md:justify-center">
      {/* Mobile menu button */}
      {onOpenSidebar && (
        <button
          onClick={onOpenSidebar}
          className="md:hidden self-start mb-4 flex items-center gap-2 px-3 py-1.5 rounded-lg bg-white/5 border border-white/10 text-xs text-white/50"
        >
          <Menu size={14} />
          Sessions
        </button>
      )}

      <div className="max-w-lg w-full">
        {/* Hero */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="text-center mb-8"
        >
          <motion.div
            animate={{ rotate: [0, 15, -15, 0], scale: [1, 1.15, 1] }}
            transition={{ duration: 3, repeat: Infinity, repeatDelay: 2 }}
            className="text-5xl md:text-6xl mb-4 inline-block"
          >
            🍌
          </motion.div>
          <h1 className="text-2xl md:text-3xl font-black text-white mb-2 tracking-tight">
            <span className="bg-gradient-to-r from-yellow-400 via-orange-400 to-red-400 bg-clip-text text-transparent">
              BANANA AGENT
            </span>
          </h1>
          <p className="text-white/40 text-xs md:text-sm max-w-sm mx-auto leading-relaxed">
            Elite AI coding engine. LangChain + LangGraph + OpenRouter.
            50+ tools. Max output. Kills Claude.
          </p>
        </motion.div>

        {/* Features Grid */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="grid grid-cols-2 md:grid-cols-4 gap-2 mb-6"
        >
          {features.map((feat, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.05 * i }}
              className="bg-white/3 border border-white/5 rounded-xl p-2.5 hover:bg-white/5 hover:border-white/10 group"
            >
              <div className={`w-7 h-7 rounded-lg bg-gradient-to-br ${feat.color} flex items-center justify-center mb-1.5 shadow-lg group-hover:scale-110 transition-transform`}>
                <feat.icon size={12} className="text-white" />
              </div>
              <h3 className="text-[10px] font-bold text-white/80 mb-0.5">{feat.label}</h3>
              <p className="text-[9px] text-white/30 leading-snug">{feat.desc}</p>
            </motion.div>
          ))}
        </motion.div>

        {/* CTA */}
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="flex flex-col items-center gap-2.5"
        >
          <motion.button
            whileTap={{ scale: 0.95 }}
            onClick={createSession}
            className="px-7 py-2.5 rounded-2xl bg-gradient-to-r from-yellow-500 to-orange-500 text-black font-bold text-sm shadow-2xl shadow-yellow-500/20 active:scale-95 transition-transform"
          >
            🚀 Start New Session
          </motion.button>

          {!settings.apiKey && (
            <button
              onClick={() => setShowSettings(true)}
              className="text-[11px] text-yellow-400/50 hover:text-yellow-400"
            >
              ⚙️ Set up OpenRouter API key first
            </button>
          )}

          <p className="text-[9px] text-white/15 font-mono mt-1 text-center">
            openrouter.ai/keys → Get free key → Settings → Go 🍌
          </p>
        </motion.div>

        {/* Setup Guide */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.6 }}
          className="mt-8 bg-white/3 border border-white/5 rounded-2xl p-4"
        >
          <h3 className="text-[10px] font-bold text-white/50 uppercase tracking-wider mb-2.5">⚡ Quick Setup (Free)</h3>
          <div className="space-y-1.5">
            {[
              { step: '1', text: 'Go to openrouter.ai — create free account' },
              { step: '2', text: 'Generate an API key from dashboard' },
              { step: '3', text: 'Click Settings (⚙️) and paste your key' },
              { step: '4', text: 'Select a free model (Auto recommended)' },
              { step: '5', text: 'Start a session and build anything!' },
            ].map((s, i) => (
              <div key={i} className="flex items-center gap-2.5">
                <div className="w-4.5 h-4.5 rounded-full bg-yellow-500/20 flex items-center justify-center text-[9px] text-yellow-400 font-bold shrink-0">
                  {s.step}
                </div>
                <span className="text-[11px] text-white/40">{s.text}</span>
              </div>
            ))}
          </div>
        </motion.div>
      </div>
    </div>
  );
}
