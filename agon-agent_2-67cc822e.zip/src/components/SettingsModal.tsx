import { useState } from 'react';
import { useAgent } from '../context/AgentContext';
import { motion } from 'framer-motion';
import { X, Key, Cpu, ExternalLink, Shield, Zap } from 'lucide-react';

const MODELS = [
  { id: 'openrouter/auto', label: '🤖 Auto (Best Free)', desc: 'Auto-selects best available free model' },
  { id: 'meta-llama/llama-4-maverick:free', label: '🦙 Llama 4 Maverick', desc: 'Meta\'s latest free model' },
  { id: 'google/gemini-2.5-flash-preview:free', label: '💎 Gemini 2.5 Flash', desc: 'Google\'s fast free model' },
  { id: 'deepseek/deepseek-chat-v3-0324:free', label: '🧠 DeepSeek V3', desc: 'DeepSeek\'s powerful free model' },
  { id: 'qwen/qwen3-235b-a22b:free', label: '⚡ Qwen3 235B', desc: 'Alibaba\'s large free model' },
  { id: 'microsoft/mai-ds-r1:free', label: '🔬 Microsoft MAI-DS-R1', desc: 'Microsoft reasoning model' },
  { id: 'google/gemma-3-27b-it:free', label: '💠 Gemma 3 27B', desc: 'Google\'s open model' },
  { id: 'mistralai/mistral-small-3.2-24b-instruct:free', label: '🌪️ Mistral Small 3.2', desc: 'Mistral\'s free model' },
  { id: 'nousresearch/hermes-3-llama-3.1-405b:free', label: '🔮 Hermes 3 405B', desc: 'NousResearch free model' },
];

export default function SettingsModal() {
  const { settings, setSettings, setShowSettings } = useAgent();
  const [apiKey, setApiKey] = useState(settings.apiKey);
  const [model, setModel] = useState(settings.model);

  const handleSave = () => {
    setSettings({ ...settings, apiKey, model });
    setShowSettings(false);
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 flex items-end md:items-center justify-center bg-black/60 backdrop-blur-sm"
      onClick={() => setShowSettings(false)}
    >
      <motion.div
        initial={{ y: 100, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        exit={{ y: 100, opacity: 0 }}
        transition={{ type: 'spring', damping: 25, stiffness: 300 }}
        className="w-full max-w-lg bg-[#0d0d16] border border-white/10 rounded-t-2xl md:rounded-2xl shadow-2xl max-h-[90vh] flex flex-col overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Drag handle (mobile) */}
        <div className="md:hidden flex justify-center pt-2 pb-1 shrink-0">
          <div className="w-10 h-1 rounded-full bg-white/15" />
        </div>

        {/* Header */}
        <div className="flex items-center justify-between px-4 py-3 border-b border-white/5 shrink-0">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-yellow-400 to-orange-500 flex items-center justify-center text-xs">⚙️</div>
            <div>
              <h2 className="text-sm font-bold text-white">Settings</h2>
              <p className="text-[9px] text-white/30">Configure AI engine</p>
            </div>
          </div>
          <button onClick={() => setShowSettings(false)} className="p-1.5 text-white/30 hover:text-white/60">
            <X size={18} />
          </button>
        </div>

        {/* Scrollable content */}
        <div className="flex-1 overflow-y-auto min-h-0 p-4 space-y-4 scrollbar-thin">
          {/* API Key */}
          <div>
            <label className="flex items-center gap-1.5 text-xs font-bold text-white/60 mb-1.5">
              <Key size={11} className="text-yellow-400" />
              OpenRouter API Key
            </label>
            <input
              type="password"
              value={apiKey}
              onChange={(e) => setApiKey(e.target.value)}
              placeholder="sk-or-v1-..."
              className="w-full bg-white/5 border border-white/10 rounded-xl px-3 py-2.5 text-sm text-white placeholder-white/20 focus:outline-none focus:border-yellow-500/40 font-mono"
            />
            <div className="flex items-center gap-1.5 mt-1.5">
              <Shield size={9} className="text-green-400/50 shrink-0" />
              <p className="text-[9px] text-white/25">Stored locally. Never sent to our servers.</p>
            </div>
            <a
              href="https://openrouter.ai/keys"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1 mt-1.5 text-[10px] text-yellow-400/60 hover:text-yellow-400"
            >
              <ExternalLink size={9} />
              Get free API key at openrouter.ai
            </a>
          </div>

          {/* Model Selection */}
          <div>
            <label className="flex items-center gap-1.5 text-xs font-bold text-white/60 mb-1.5">
              <Cpu size={11} className="text-blue-400" />
              AI Model
            </label>
            <div className="space-y-1 max-h-[200px] overflow-y-auto scrollbar-thin">
              {MODELS.map(m => (
                <button
                  key={m.id}
                  onClick={() => setModel(m.id)}
                  className={`w-full text-left px-3 py-2 rounded-xl border transition-colors ${
                    model === m.id
                      ? 'bg-yellow-500/10 border-yellow-500/30 text-yellow-400'
                      : 'bg-white/3 border-white/5 text-white/50 hover:bg-white/5'
                  }`}
                >
                  <div className="text-[11px] font-semibold">{m.label}</div>
                  <div className="text-[9px] text-white/30 mt-0.5">{m.desc}</div>
                </button>
              ))}
            </div>
          </div>

          {/* Custom Model */}
          <div>
            <label className="text-[9px] text-white/30 mb-1 block">Or custom model ID:</label>
            <input
              value={model}
              onChange={(e) => setModel(e.target.value)}
              className="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-1.5 text-xs text-white/60 font-mono focus:outline-none focus:border-yellow-500/30"
            />
          </div>

          {/* Info */}
          <div className="bg-yellow-500/5 border border-yellow-500/10 rounded-xl p-2.5">
            <div className="flex items-start gap-2">
              <Zap size={12} className="text-yellow-400 mt-0.5 shrink-0" />
              <div className="text-[10px] text-yellow-400/60 leading-relaxed">
                <strong className="text-yellow-400">Free Tier:</strong> 50 req/day (free) or 1000 req/day ($10+ credits).
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-4 py-3 border-t border-white/5 flex gap-2 shrink-0 safe-bottom">
          <button
            onClick={() => setShowSettings(false)}
            className="flex-1 py-2.5 rounded-xl bg-white/5 text-white/40 text-sm font-medium hover:bg-white/10"
          >
            Cancel
          </button>
          <button
            onClick={handleSave}
            className="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-yellow-500 to-orange-500 text-black text-sm font-bold shadow-lg shadow-yellow-500/20 active:scale-95 transition-transform"
          >
            Save Settings
          </button>
        </div>
      </motion.div>
    </motion.div>
  );
}
