import { useState } from 'react';
import { useAgent } from '../context/AgentContext';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, Trash2, MessageSquare, Settings, Zap, X, AlertTriangle } from 'lucide-react';

interface SidebarProps {
  onClose?: () => void;
}

export default function Sidebar({ onClose }: SidebarProps) {
  const { sessions, currentSession, setCurrentSession, createSession, deleteSession, setShowSettings } = useAgent();
  const [confirmDeleteId, setConfirmDeleteId] = useState<number | null>(null);

  const handleSelectSession = (session: any) => {
    setCurrentSession(session);
    onClose?.();
  };

  const handleDelete = async (id: number) => {
    await deleteSession(id);
    setConfirmDeleteId(null);
  };

  return (
    <div className="w-full md:w-[260px] h-full flex flex-col bg-[#08080d] border-r border-white/5">
      {/* Logo + Close */}
      <div className="p-4 border-b border-white/5 shrink-0">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-yellow-400 to-orange-500 flex items-center justify-center shadow-lg shadow-yellow-500/20 shrink-0">
            <span className="text-lg">{'🍌'}</span>
          </div>
          <div className="flex-1 min-w-0">
            <h1 className="text-sm font-black tracking-tight text-white">BANANA AGENT</h1>
            <p className="text-[10px] text-yellow-400/70 font-mono">LangChain + LangGraph</p>
          </div>
          {onClose && (
            <button onClick={onClose} className="md:hidden p-1.5 text-white/30 hover:text-white/60"><X size={18} /></button>
          )}
        </div>
      </div>

      {/* New Session */}
      <div className="p-3 shrink-0">
        <motion.button
          whileTap={{ scale: 0.97 }}
          onClick={() => { createSession(); onClose?.(); }}
          className="w-full flex items-center gap-2 px-3 py-2.5 rounded-xl bg-gradient-to-r from-yellow-500/10 to-orange-500/10 border border-yellow-500/20 text-yellow-400 hover:from-yellow-500/20 hover:to-orange-500/20 text-sm font-semibold active:scale-95 transition-transform"
        ><Plus size={16} /> New Session</motion.button>
      </div>

      {/* Sessions List */}
      <div className="flex-1 overflow-y-auto min-h-0 px-2 space-y-0.5 scrollbar-thin">
        <AnimatePresence>
          {sessions.map((session) => (
            <motion.div
              key={session.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, height: 0, marginBottom: 0 }}
              layout
            >
              {/* Delete Confirmation */}
              <AnimatePresence>
                {confirmDeleteId === session.id && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    className="overflow-hidden mb-0.5"
                  >
                    <div className="bg-red-500/10 border border-red-500/20 rounded-lg p-2.5">
                      <div className="flex items-center gap-1.5 mb-2">
                        <AlertTriangle size={12} className="text-red-400" />
                        <span className="text-[10px] text-red-400 font-bold">Delete this session?</span>
                      </div>
                      <p className="text-[9px] text-red-300/50 mb-2">All messages & files will be permanently deleted.</p>
                      <div className="flex gap-1.5">
                        <button
                          onClick={() => handleDelete(session.id)}
                          className="flex-1 py-1 rounded-md bg-red-500/20 text-red-400 text-[10px] font-bold hover:bg-red-500/30"
                        >Delete</button>
                        <button
                          onClick={() => setConfirmDeleteId(null)}
                          className="flex-1 py-1 rounded-md bg-white/5 text-white/40 text-[10px] font-bold hover:bg-white/10"
                        >Cancel</button>
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>

              <div
                className={`group flex items-center gap-2 px-3 py-2.5 rounded-lg cursor-pointer text-sm ${
                  currentSession?.id === session.id
                    ? 'bg-yellow-500/10 text-yellow-400 border border-yellow-500/20'
                    : 'text-white/50 hover:bg-white/5 hover:text-white/80 border border-transparent'
                }`}
                onClick={() => handleSelectSession(session)}
              >
                <MessageSquare size={14} className="shrink-0" />
                <span className="truncate flex-1 font-medium">{session.title}</span>
                <button
                  onClick={(e) => { e.stopPropagation(); setConfirmDeleteId(session.id); }}
                  className="opacity-0 group-hover:opacity-100 text-red-400/50 hover:text-red-400 p-1 transition-opacity"
                ><Trash2 size={12} /></button>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
        {sessions.length === 0 && (
          <div className="text-center py-10 text-white/15 text-xs">No sessions yet</div>
        )}
      </div>

      {/* Bottom */}
      <div className="p-3 border-t border-white/5 space-y-1 shrink-0">
        <button onClick={() => { setShowSettings(true); onClose?.(); }} className="w-full flex items-center gap-2 px-3 py-2 rounded-lg text-white/40 hover:text-white/80 hover:bg-white/5 text-sm">
          <Settings size={14} /><span>Settings</span>
        </button>
        <div className="flex items-center gap-2 px-3 py-1.5 text-[10px] text-white/20 font-mono">
          <Zap size={10} className="text-yellow-500/40" /><span>Powered by OpenRouter</span>
        </div>
      </div>
    </div>
  );
}
