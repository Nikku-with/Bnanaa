import { useState, useRef, useEffect, useCallback } from 'react';
import { useAgent } from '../context/AgentContext';
import { motion, AnimatePresence } from 'framer-motion';
import { FileCode, Save, Plus, Copy, Check, Send, X, Play, Download } from 'lucide-react';
import Editor from '@monaco-editor/react';

const LANG_MAP: Record<string, string> = { javascript:'javascript',js:'javascript',typescript:'typescript',ts:'typescript',python:'python',py:'python',html:'html',css:'css',json:'json',markdown:'markdown',md:'markdown',xml:'xml',sql:'sql',yaml:'yaml',java:'java',cpp:'cpp',c:'c',go:'go',rust:'rust',ruby:'ruby',php:'php',swift:'swift',kotlin:'kotlin',dart:'dart',bash:'shell',sh:'shell',text:'plaintext' };
const EXT_ICON: Record<string, string> = { javascript:'🟨',typescript:'🔷',python:'🐍',html:'🌐',css:'🎨',json:'📋',java:'☕',go:'🐹',rust:'🦀',php:'🐘' };

export default function CodeEditor() {
  const { files, saveFile, createFile, deleteFile, currentSession, fetchFiles, sendMessage, loading } = useAgent();
  const [activeFileId, setActiveFileId] = useState<number | null>(null);
  const [editContent, setEditContent] = useState('');
  const [showNewFile, setShowNewFile] = useState(false);
  const [newFileName, setNewFileName] = useState('');
  const [saved, setSaved] = useState(false);
  const [editorMsg, setEditorMsg] = useState('');
  const [showPreview, setShowPreview] = useState(false);
  const [previewKey, setPreviewKey] = useState(0);

  const activeFile = files.find(f => f.id === activeFileId);

  useEffect(() => { if (files.length > 0 && (!activeFileId || !files.find(f => f.id === activeFileId))) { setActiveFileId(files[0].id); setEditContent(files[0].content); } }, [files]);
  useEffect(() => { if (activeFile) setEditContent(activeFile.content); }, [activeFileId]);

  const handleSave = async () => { if (!activeFile) return; await saveFile(activeFile.id, editContent); setSaved(true); setTimeout(() => setSaved(false), 2000); };
  const handleCreateFile = async () => { if (!newFileName.trim()) return; const ext = newFileName.split('.').pop()?.toLowerCase() || 'txt'; await createFile(newFileName, '', LANG_MAP[ext] || 'plaintext'); await fetchFiles(); setShowNewFile(false); setNewFileName(''); };
  const handleDeleteFile = async (id: number) => { await deleteFile(id); if (activeFileId === id) { const rem = files.filter(f => f.id !== id); if (rem.length) { setActiveFileId(rem[0].id); setEditContent(rem[0].content); } else { setActiveFileId(null); setEditContent(''); } } await fetchFiles(); };

  const buildPreview = useCallback(() => {
    const htmlFile = files.find(f => f.filename.endsWith('.html'));
    const cssFiles = files.filter(f => f.filename.endsWith('.css'));
    const jsFiles = files.filter(f => f.filename.endsWith('.js') || f.filename.endsWith('.ts'));
    let htmlContent = activeFile?.filename.endsWith('.html') ? editContent : htmlFile?.content || '';
    let allCss = cssFiles.map(f => activeFile?.id === f.id ? editContent : f.content).join('\n');
    let allJs = jsFiles.map(f => activeFile?.id === f.id ? editContent : f.content).join('\n');
    if (htmlContent) { let doc = htmlContent; if (allCss && !doc.includes('<style')) doc = doc.replace('</head>', `<style>${allCss}</style></head>`); if (allJs && !doc.includes('<script')) doc = doc.replace('</body>', `<script>${allJs}<\/script></body>`); return doc; }
    if (activeFile?.filename.endsWith('.css')) return `<!DOCTYPE html><html><head><style>${editContent}</style><style>body{background:#0a0a0f;color:#fff;font-family:system-ui;padding:20px;}</style></head><body><h1>CSS Preview</h1><div class="container"><div class="box">Box 1</div><div class="box">Box 2</div></div><button>Button</button><p>Text</p></body></html>`;
    if (activeFile?.filename.endsWith('.js') || activeFile?.filename.endsWith('.ts')) return `<!DOCTYPE html><html><head><style>body{background:#0a0a0f;color:#e2e8f0;font-family:monospace;padding:20px;}#o{white-space:pre-wrap;}.l{color:#22c55e;margin:2px 0;}.e{color:#ef4444;}</style></head><body><div id="o"></div><script>const _o=document.getElementById('o'),_l=console.log,_e=console.error;console.log=(...a)=>{_l(...a);const d=document.createElement('div');d.className='l';d.textContent=a.map(x=>typeof x==='object'?JSON.stringify(x,null,2):String(x)).join(' ');_o.appendChild(d);};console.error=(...a)=>{_e(...a);const d=document.createElement('div');d.className='e';d.textContent=a.join(' ');_o.appendChild(d);};try{${editContent}}catch(e){console.error(e.message)}<\/script></body></html>`;
    return `<!DOCTYPE html><html><head><style>body{background:#0a0a0f;color:#555;font-family:monospace;padding:20px;display:flex;align-items:center;justify-content:center;min-height:100vh;}</style></head><body><p>Select an HTML/JS/CSS file to preview</p></body></html>`;
  }, [files, activeFile, editContent]);

  const monacoLang = activeFile ? (LANG_MAP[activeFile.language] || LANG_MAP[activeFile.filename.split('.').pop() || ''] || 'plaintext') : 'plaintext';

  return (
    <div className="flex-1 flex flex-col overflow-hidden min-h-0 bg-themed">
      {/* TOP BAR: File tabs (scrollable) + Action buttons (fixed right) */}
      <div className="flex items-stretch border-b border-themed bg-themed-sidebar shrink-0 min-h-[36px]">
        {/* Scrollable file tabs */}
        <div className="flex-1 flex items-stretch overflow-x-auto scrollbar-none min-w-0">
          {files.map(file => (
            <div key={file.id} className={`group flex items-center gap-1.5 px-3 text-[11px] font-mono whitespace-nowrap cursor-pointer border-r border-white/[0.03] shrink-0 transition-colors ${activeFileId === file.id ? 'bg-white/[0.04] text-white/80 border-b-2 border-b-amber-500' : 'text-white/25 hover:text-white/50 hover:bg-white/[0.02]'}`} onClick={() => setActiveFileId(file.id)}>
              <span className="text-[9px]">{EXT_ICON[file.language] || '📄'}</span>
              <span className="max-w-[80px] truncate">{file.filename}</span>
              <button onClick={(e) => { e.stopPropagation(); handleDeleteFile(file.id); }} className="opacity-0 group-hover:opacity-100 text-white/20 hover:text-red-400 transition-opacity ml-0.5"><X size={9} /></button>
            </div>
          ))}
        </div>
        {/* Fixed action buttons - never overlap */}
        <div className="flex items-center gap-px px-2 bg-themed-sidebar border-l border-themed shrink-0">
          <button onClick={() => setShowNewFile(true)} className="p-1.5 text-white/20 hover:text-amber-400 rounded transition-colors" title="New"><Plus size={13} /></button>
          {activeFile && <>
            <button onClick={() => navigator.clipboard.writeText(editContent)} className="p-1.5 text-white/20 hover:text-white/50 rounded transition-colors" title="Copy"><Copy size={12} /></button>
            <button onClick={handleSave} className="p-1.5 text-white/20 hover:text-emerald-400 rounded transition-colors" title="Save">{saved ? <Check size={12} className="text-emerald-400" /> : <Save size={12} />}</button>
            <button onClick={() => { setShowPreview(true); setPreviewKey(k => k + 1); }} className="flex items-center gap-1 px-2 py-1 rounded text-[9px] font-bold text-emerald-400/60 hover:text-emerald-400 hover:bg-emerald-400/8 transition-colors" title="Run"><Play size={10} />Run</button>
          </>}
        </div>
      </div>

      {/* New File */}
      <AnimatePresence>{showNewFile && <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }} className="border-b border-white/[0.04] bg-amber-500/[0.03] overflow-hidden shrink-0"><div className="p-2 flex gap-1.5 items-center"><input value={newFileName} onChange={(e) => setNewFileName(e.target.value)} placeholder="filename.html" className="flex-1 bg-white/[0.04] border border-white/[0.06] rounded-lg px-2.5 py-1.5 text-xs text-white placeholder-white/20 focus:outline-none focus:border-amber-500/30 min-w-0" autoFocus onKeyDown={(e) => e.key === 'Enter' && handleCreateFile()} /><button onClick={handleCreateFile} className="px-3 py-1.5 bg-amber-500/15 text-amber-400 rounded-lg text-[10px] font-bold hover:bg-amber-500/25 shrink-0">Create</button><button onClick={() => setShowNewFile(false)} className="p-1 text-white/20 hover:text-white/50"><X size={13} /></button></div></motion.div>}</AnimatePresence>

      {/* Editor + Preview */}
      <div className="flex-1 flex overflow-hidden min-h-0">
        <div className={`flex-1 overflow-hidden min-h-0 ${showPreview ? 'hidden md:flex md:flex-col' : 'flex flex-col'}`}>
          {activeFile ? <Editor height="100%" language={monacoLang} value={editContent} onChange={(v) => setEditContent(v || '')} theme="vs-dark" options={{ fontSize: 13, fontFamily: "'JetBrains Mono', monospace", minimap: { enabled: false }, scrollBeyondLastLine: false, padding: { top: 10 }, lineNumbers: 'on', renderLineHighlight: 'gutter', bracketPairColorization: { enabled: true }, automaticLayout: true, tabSize: 2, wordWrap: 'on', smoothScrolling: true, cursorBlinking: 'smooth', cursorSmoothCaretAnimation: 'on' }} onMount={(ed) => { ed.addCommand(2097, () => handleSave()); }} /> : <div className="h-full flex items-center justify-center text-white/15 text-xs"><div className="text-center px-4"><FileCode size={28} className="mx-auto mb-2 opacity-50" /><p>No files yet</p></div></div>}
        </div>
        <AnimatePresence>{showPreview && <motion.div initial={{ width: 0, opacity: 0 }} animate={{ width: '100%', opacity: 1 }} exit={{ width: 0, opacity: 0 }} className="flex flex-col border-l border-white/[0.04] overflow-hidden min-h-0 md:max-w-[50%]">
          <div className="flex items-center justify-between px-2.5 py-1.5 bg-themed-sidebar border-b border-themed shrink-0"><div className="flex items-center gap-1.5"><div className="flex gap-1"><div className="w-2 h-2 rounded-full bg-red-500/60" /><div className="w-2 h-2 rounded-full bg-amber-500/60" /><div className="w-2 h-2 rounded-full bg-emerald-500/60" /></div><span className="text-[9px] text-white/25 font-mono">Preview</span></div><div className="flex items-center gap-1"><button onClick={() => setPreviewKey(k => k + 1)} className="p-1 text-emerald-400/40 hover:text-emerald-400"><Play size={10} /></button><button onClick={() => setShowPreview(false)} className="p-1 text-white/20 hover:text-white/50"><X size={10} /></button></div></div>
          <iframe key={previewKey} srcDoc={buildPreview()} className="flex-1 w-full bg-white min-h-0" sandbox="allow-scripts allow-modals" title="Preview" />
        </motion.div>}</AnimatePresence>
      </div>

      {/* Editor Chat */}
      <div className="shrink-0 border-t border-themed bg-themed-sidebar p-2"><div className="flex gap-1.5 items-center"><input value={editorMsg} onChange={(e) => setEditorMsg(e.target.value)} onKeyDown={(e) => { if (e.key === 'Enter' && editorMsg.trim() && !loading) { const msg = `[Editor] ${activeFile?.filename || ''}\n${editorMsg}\n\`\`\`\n${editContent.slice(0, 2000)}\n\`\`\``; setEditorMsg(''); sendMessage(msg); } }} placeholder="Ask about this code..." className="flex-1 bg-white/[0.03] border border-white/[0.05] rounded-lg px-2.5 py-1.5 text-[11px] text-white placeholder-white/15 focus:outline-none focus:border-amber-500/20 min-w-0" /><button disabled={loading || !editorMsg.trim()} className="p-1.5 text-amber-400/40 hover:text-amber-400 disabled:opacity-20 shrink-0"><Send size={12} /></button></div></div>
    </div>
  );
}
