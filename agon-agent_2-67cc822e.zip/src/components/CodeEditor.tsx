import { useState, useRef, useEffect, useCallback } from 'react';
import { useAgent } from '../context/AgentContext';
import { motion, AnimatePresence } from 'framer-motion';
import { FileCode, Save, Plus, Copy, Check, Send, X, Trash2, Play, Download } from 'lucide-react';
import Editor from '@monaco-editor/react';

const LANG_MAP: Record<string, string> = {
  javascript: 'javascript', js: 'javascript', typescript: 'typescript', ts: 'typescript',
  python: 'python', py: 'python', html: 'html', css: 'css', json: 'json',
  markdown: 'markdown', md: 'markdown', xml: 'xml', sql: 'sql', yaml: 'yaml',
  java: 'java', cpp: 'cpp', c: 'c', go: 'go', rust: 'rust', ruby: 'ruby',
  php: 'php', swift: 'swift', kotlin: 'kotlin', dart: 'dart', bash: 'shell', sh: 'shell',
  text: 'plaintext',
};

const EXT_ICON: Record<string, string> = {
  javascript: '🟨', typescript: '🔷', python: '🐍', html: '🌐', css: '🎨',
  json: '📋', markdown: '📝', java: '☕', cpp: '⚙️', ruby: '💎', go: '🐹',
  rust: '🦀', php: '🐘', swift: '🍎', kotlin: '🟣', dart: '🎯',
};

export default function CodeEditor() {
  const { files, saveFile, createFile, deleteFile, currentSession, fetchFiles, sendMessage, loading } = useAgent();
  const [activeFileId, setActiveFileId] = useState<number | null>(null);
  const [editContent, setEditContent] = useState('');
  const [showNewFile, setShowNewFile] = useState(false);
  const [newFileName, setNewFileName] = useState('');
  const [saved, setSaved] = useState(false);
  const [editorMsg, setEditorMsg] = useState('');
  const [showPreview, setShowPreview] = useState(false);
  const [previewKey, setPreviewKey] = useState(0);
  const iframeRef = useRef<HTMLIFrameElement>(null);

  const activeFile = files.find(f => f.id === activeFileId);

  useEffect(() => {
    if (files.length > 0 && (!activeFileId || !files.find(f => f.id === activeFileId))) {
      setActiveFileId(files[0].id);
      setEditContent(files[0].content);
    }
  }, [files]);

  useEffect(() => {
    if (activeFile) setEditContent(activeFile.content);
  }, [activeFileId]);

  const handleSave = async () => {
    if (!activeFile) return;
    await saveFile(activeFile.id, editContent);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  const handleCreateFile = async () => {
    if (!newFileName.trim()) return;
    const ext = newFileName.split('.').pop()?.toLowerCase() || 'txt';
    const langGuess = LANG_MAP[ext] || 'plaintext';
    await createFile(newFileName, '', langGuess);
    await fetchFiles();
    setShowNewFile(false);
    setNewFileName('');
  };

  const handleDeleteFile = async (id: number) => {
    await deleteFile(id);
    if (activeFileId === id) {
      const remaining = files.filter(f => f.id !== id);
      if (remaining.length) {
        setActiveFileId(remaining[0].id);
        setEditContent(remaining[0].content);
      } else {
        setActiveFileId(null);
        setEditContent('');
      }
    }
    await fetchFiles();
  };

  const handleEditorChat = async () => {
    if (!editorMsg.trim() || loading) return;
    const msg = `[Code Editor] File: ${activeFile?.filename || 'none'}\n\nRequest: ${editorMsg}\n\nCode:\n\`\`\`\n${editContent.slice(0, 3000)}\n\`\`\``;
    setEditorMsg('');
    await sendMessage(msg);
  };

  const handleDownload = () => {
    if (!activeFile) return;
    const blob = new Blob([editContent], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = activeFile.filename; a.click();
    URL.revokeObjectURL(url);
  };

  // Build live preview HTML from all project files
  const buildPreview = useCallback(() => {
    const htmlFile = files.find(f => f.filename.endsWith('.html'));
    const cssFiles = files.filter(f => f.filename.endsWith('.css'));
    const jsFiles = files.filter(f => f.filename.endsWith('.js') || f.filename.endsWith('.ts'));

    // If active file is HTML, use its content (possibly edited)
    let htmlContent = '';
    if (activeFile?.filename.endsWith('.html')) {
      htmlContent = editContent;
    } else if (htmlFile) {
      htmlContent = htmlFile.content;
    }

    // Gather CSS
    let allCss = '';
    for (const f of cssFiles) {
      allCss += (activeFile?.id === f.id ? editContent : f.content) + '\n';
    }

    // Gather JS
    let allJs = '';
    for (const f of jsFiles) {
      allJs += (activeFile?.id === f.id ? editContent : f.content) + '\n';
    }

    // If we have an HTML file, inject CSS/JS into it
    if (htmlContent) {
      // Remove existing style/script tags to avoid duplication
      let doc = htmlContent;
      if (allCss && !doc.includes('<style')) {
        doc = doc.replace('</head>', `<style>${allCss}</style></head>`);
      }
      if (allJs && !doc.includes('<script')) {
        doc = doc.replace('</body>', `<script>${allJs}<\/script></body>`);
      }
      return doc;
    }

    // No HTML file — build one
    if (activeFile?.language === 'python' || activeFile?.filename.endsWith('.py')) {
      return `<!DOCTYPE html><html><head><meta charset="utf-8"><style>body{background:#0a0a0f;color:#e2e8f0;font-family:monospace;padding:20px;white-space:pre-wrap;}h3{color:#eab308;}</style></head><body><h3>🐍 Python Preview</h3><pre>${editContent.replace(/</g,'&lt;')}</pre><p style="color:#666;margin-top:20px;">Python runs server-side. This is a code preview.</p></body></html>`;
    }

    // Pure CSS preview
    if (activeFile?.filename.endsWith('.css')) {
      return `<!DOCTYPE html><html><head><meta charset="utf-8"><style>${editContent}</style><style>body{background:#0a0a0f;color:#fff;font-family:system-ui;padding:20px;}</style></head><body><h1>CSS Preview</h1><div class="container"><div class="box">Box 1</div><div class="box">Box 2</div><div class="box">Box 3</div></div><button>Button</button><a href="#">Link</a><p>Paragraph text for testing styles.</p></body></html>`;
    }

    // Pure JS preview
    if (activeFile?.filename.endsWith('.js') || activeFile?.filename.endsWith('.ts')) {
      return `<!DOCTYPE html><html><head><meta charset="utf-8"><style>body{background:#0a0a0f;color:#e2e8f0;font-family:monospace;padding:20px;}#output{white-space:pre-wrap;}.log{color:#22c55e;margin:2px 0;}.error{color:#ef4444;}</style></head><body><div id="output"></div><script>const _out=document.getElementById('output');const _log=console.log;const _err=console.error;console.log=(...a)=>{_log(...a);const d=document.createElement('div');d.className='log';d.textContent=a.map(x=>typeof x==='object'?JSON.stringify(x,null,2):String(x)).join(' ');_out.appendChild(d);};console.error=(...a)=>{_err(...a);const d=document.createElement('div');d.className='error';d.textContent='❌ '+a.join(' ');_out.appendChild(d);};try{${editContent}}catch(e){console.error(e.message);}<\/script></body></html>`;
    }

    // JSON preview
    if (activeFile?.filename.endsWith('.json')) {
      try {
        const parsed = JSON.parse(editContent);
        return `<!DOCTYPE html><html><head><meta charset="utf-8"><style>body{background:#0a0a0f;color:#e2e8f0;font-family:monospace;padding:20px;white-space:pre-wrap;}</style></head><body>${JSON.stringify(parsed, null, 2).replace(/</g,'&lt;')}</body></html>`;
      } catch {
        return `<!DOCTYPE html><html><head><style>body{background:#0a0a0f;color:#ef4444;font-family:monospace;padding:20px;}</style></head><body>Invalid JSON</body></html>`;
      }
    }

    // Fallback
    return `<!DOCTYPE html><html><head><style>body{background:#0a0a0f;color:#888;font-family:monospace;padding:20px;}</style></head><body><p>Select an HTML, JS, or CSS file to preview.</p></body></html>`;
  }, [files, activeFile, editContent]);

  const runPreview = () => {
    setShowPreview(true);
    setPreviewKey(k => k + 1);
  };

  const monacoLang = activeFile ? (LANG_MAP[activeFile.language] || LANG_MAP[activeFile.filename.split('.').pop() || ''] || 'plaintext') : 'plaintext';

  return (
    <div className="flex-1 flex flex-col overflow-hidden min-h-0 bg-[#0a0a10]">
      {/* File Tabs */}
      <div className="flex items-center border-b border-white/5 bg-[#08080d] shrink-0 overflow-x-auto scrollbar-none">
        <div className="flex items-center min-w-0">
          {files.map(file => (
            <div
              key={file.id}
              className={`group flex items-center gap-1 px-2.5 py-2 text-[11px] font-mono border-r border-white/5 whitespace-nowrap cursor-pointer ${
                activeFileId === file.id
                  ? 'bg-white/5 text-white border-b-2 border-b-yellow-500'
                  : 'text-white/30 hover:text-white/60 hover:bg-white/[0.02]'
              }`}
              onClick={() => setActiveFileId(file.id)}
            >
              <span className="text-[9px]">{EXT_ICON[file.language] || '📄'}</span>
              <span className="max-w-[80px] truncate">{file.filename}</span>
              <button
                onClick={(e) => { e.stopPropagation(); handleDeleteFile(file.id); }}
                className="opacity-0 group-hover:opacity-100 ml-1 text-red-400/50 hover:text-red-400 transition-opacity"
              >
                <X size={10} />
              </button>
            </div>
          ))}
        </div>
        <div className="flex items-center gap-0.5 px-1.5 ml-auto shrink-0">
          <button onClick={() => setShowNewFile(true)} className="p-1 text-white/30 hover:text-yellow-400" title="New File"><Plus size={13} /></button>
          {activeFile && (
            <>
              <button onClick={() => navigator.clipboard.writeText(editContent)} className="p-1 text-white/30 hover:text-white/60" title="Copy"><Copy size={13} /></button>
              <button onClick={handleDownload} className="p-1 text-white/30 hover:text-white/60" title="Download"><Download size={13} /></button>
              <button onClick={handleSave} className="p-1 text-white/30 hover:text-green-400" title="Save">
                {saved ? <Check size={13} className="text-green-400" /> : <Save size={13} />}
              </button>
              <button onClick={runPreview} className="flex items-center gap-1 px-1.5 py-0.5 rounded text-[9px] font-bold text-green-400/70 hover:text-green-400 hover:bg-green-400/10 transition-colors" title="Run Preview">
                <Play size={11} /> Run
              </button>
            </>
          )}
        </div>
      </div>

      {/* New File Dialog */}
      <AnimatePresence>
        {showNewFile && (
          <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }} className="border-b border-white/5 bg-yellow-500/5 overflow-hidden shrink-0">
            <div className="p-2 flex gap-1.5 items-center">
              <input value={newFileName} onChange={(e) => setNewFileName(e.target.value)} placeholder="filename.html" className="flex-1 bg-white/5 border border-white/10 rounded-lg px-2.5 py-1.5 text-xs text-white placeholder-white/25 focus:outline-none focus:border-yellow-500/40 min-w-0" autoFocus onKeyDown={(e) => e.key === 'Enter' && handleCreateFile()} />
              <button onClick={handleCreateFile} className="px-2.5 py-1.5 bg-yellow-500/20 text-yellow-400 rounded-lg text-[10px] font-bold hover:bg-yellow-500/30 shrink-0">Create</button>
              <button onClick={() => setShowNewFile(false)} className="p-1 text-white/30 hover:text-white/60"><X size={13} /></button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Main Area: Editor + Preview split */}
      <div className="flex-1 flex overflow-hidden min-h-0">
        {/* Monaco Editor */}
        <div className={`flex-1 overflow-hidden min-h-0 ${showPreview ? 'hidden md:flex md:flex-col' : 'flex flex-col'}`}>
          {activeFile ? (
            <Editor
              height="100%"
              language={monacoLang}
              value={editContent}
              onChange={(v) => setEditContent(v || '')}
              theme="vs-dark"
              options={{
                fontSize: 13,
                fontFamily: "'JetBrains Mono', 'Fira Code', 'Cascadia Code', monospace",
                minimap: { enabled: false },
                scrollBeyondLastLine: false,
                padding: { top: 10 },
                lineNumbers: 'on',
                renderLineHighlight: 'gutter',
                bracketPairColorization: { enabled: true },
                automaticLayout: true,
                tabSize: 2,
                wordWrap: 'on',
                smoothScrolling: true,
                cursorBlinking: 'smooth',
                cursorSmoothCaretAnimation: 'on',
              }}
              onMount={(editor) => {
                editor.addCommand(2097 /* Ctrl+S */, () => handleSave());
              }}
            />
          ) : (
            <div className="h-full flex items-center justify-center text-white/20 text-xs">
              <div className="text-center px-4">
                <FileCode size={28} className="mx-auto mb-2 text-white/10" />
                <p>No files yet. Ask the agent!</p>
              </div>
            </div>
          )}
        </div>

        {/* Live Preview */}
        <AnimatePresence>
          {showPreview && (
            <motion.div
              initial={{ width: 0, opacity: 0 }}
              animate={{ width: '100%', opacity: 1 }}
              exit={{ width: 0, opacity: 0 }}
              className="flex flex-col border-l border-white/5 overflow-hidden min-h-0 md:max-w-[50%]"
            >
              <div className="flex items-center justify-between px-2.5 py-1.5 bg-[#08080d] border-b border-white/5 shrink-0">
                <div className="flex items-center gap-1.5">
                  <div className="flex gap-1">
                    <div className="w-2.5 h-2.5 rounded-full bg-red-500/70" />
                    <div className="w-2.5 h-2.5 rounded-full bg-yellow-500/70" />
                    <div className="w-2.5 h-2.5 rounded-full bg-green-500/70" />
                  </div>
                  <span className="text-[9px] text-white/30 font-mono">Live Preview</span>
                </div>
                <div className="flex items-center gap-1">
                  <button onClick={runPreview} className="p-1 text-green-400/50 hover:text-green-400"><Play size={11} /></button>
                  <button onClick={() => setShowPreview(false)} className="p-1 text-white/30 hover:text-white/60"><X size={11} /></button>
                </div>
              </div>
              <iframe
                ref={iframeRef}
                key={previewKey}
                srcDoc={buildPreview()}
                className="flex-1 w-full bg-white min-h-0"
                sandbox="allow-scripts allow-modals"
                title="Preview"
              />
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Editor Chat */}
      <div className="shrink-0 border-t border-white/5 bg-[#08080d] p-2">
        <div className="flex gap-1.5 items-center">
          <input value={editorMsg} onChange={(e) => setEditorMsg(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && handleEditorChat()} placeholder="Ask about this code..." className="flex-1 bg-white/5 border border-white/10 rounded-lg px-2.5 py-1.5 text-[11px] text-white placeholder-white/20 focus:outline-none focus:border-yellow-500/30 min-w-0" />
          <button onClick={handleEditorChat} disabled={loading || !editorMsg.trim()} className="p-1.5 text-yellow-400/60 hover:text-yellow-400 disabled:opacity-30 shrink-0"><Send size={13} /></button>
        </div>
      </div>
    </div>
  );
}
