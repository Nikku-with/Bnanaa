import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Copy, Check, FileCode, ChevronDown, ChevronUp } from 'lucide-react';
import { useAgent } from '../context/AgentContext';

export default function CodeBlock({ code, language, filename }: { code: string; language: string; filename?: string }) {
  const [copied, setCopied] = useState(false);
  const [collapsed, setCollapsed] = useState(false);
  const { createFile, currentSession, fetchFiles, setActiveTab } = useAgent();
  const lines = code.split('\n'); const isLong = lines.length > 30;
  const display = collapsed ? lines.slice(0, 8) : lines;

  const openInEditor = async () => {
    if (!currentSession) return;
    const fn = filename || `code.${language === 'javascript' ? 'js' : language === 'typescript' ? 'ts' : language === 'python' ? 'py' : language}`;
    await createFile(fn, code, language);
    await fetchFiles();
    setActiveTab('code');
  };

  return (
    <motion.div initial={{ opacity: 0, y: 4 }} animate={{ opacity: 1, y: 0 }} className="rounded-xl border border-[var(--border-strong)] overflow-hidden bg-[#141416]">
      <div className="flex items-center justify-between px-3 py-1.5 bg-white/[0.02] border-b border-[var(--border)]">
        <div className="flex items-center gap-2 min-w-0"><FileCode size={11} className="text-[var(--accent)] shrink-0" /><span className="text-[10px] font-mono text-[var(--text-muted)] truncate">{filename || language}</span><span className="text-[8px] text-[var(--text-muted)]/50">{lines.length}L</span></div>
        <div className="flex items-center gap-1 shrink-0">
          {isLong && <button onClick={() => setCollapsed(!collapsed)} className="p-1 text-[var(--text-muted)]/50 hover:text-[var(--text-secondary)]">{collapsed ? <ChevronDown size={11} /> : <ChevronUp size={11} />}</button>}
          <button onClick={() => { navigator.clipboard.writeText(code); setCopied(true); setTimeout(() => setCopied(false), 2000); }} className="p-1 text-[var(--text-muted)]/50 hover:text-[var(--text-secondary)]">{copied ? <Check size={11} className="text-[var(--green)]" /> : <Copy size={11} />}</button>
          <button onClick={openInEditor} className="flex items-center gap-1 px-2 py-0.5 rounded-md text-[9px] font-bold text-[var(--accent)]/60 hover:text-[var(--accent)] hover:bg-[var(--accent-dim)] transition-colors"><FileCode size={10} />Open</button>
        </div>
      </div>
      <div className="overflow-x-auto overflow-y-auto max-h-[350px] scrollbar-thin"><div className="flex"><div className="shrink-0 py-2 select-none bg-white/[0.01] border-r border-[var(--border)]">{display.map((_, i) => <div key={i} className="text-[9px] text-[var(--text-muted)]/30 text-right pr-2 pl-2 leading-[18px] font-mono">{i + 1}</div>)}</div><pre className="flex-1 py-2 px-3"><code className="text-[11px] leading-[18px] font-mono text-[var(--green)]/80">{display.map((l, i) => <div key={i} className="whitespace-pre">{l || ' '}</div>)}</code></pre></div></div>
      {collapsed && isLong && <button onClick={() => setCollapsed(false)} className="w-full py-1.5 text-[9px] text-[var(--text-muted)]/40 hover:text-[var(--text-secondary)] bg-white/[0.01] border-t border-[var(--border)] font-mono">+{lines.length - 8} lines</button>}
    </motion.div>
  );
}
