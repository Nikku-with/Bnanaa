import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Copy, Check, FileCode, ChevronDown, ChevronUp } from 'lucide-react';
import { useAgent } from '../context/AgentContext';

interface CodeBlockProps {
  code: string;
  language: string;
  filename?: string;
}

// Simple syntax-ish coloring by token type
function highlightLine(line: string, lang: string): React.ReactElement[] {
  const elements: React.ReactElement[] = [];
  
  // Keywords per language
  const keywords: Record<string, string[]> = {
    javascript: ['const','let','var','function','return','if','else','for','while','class','import','export','from','default','async','await','new','this','try','catch','throw','switch','case','break','continue','typeof','instanceof','in','of','true','false','null','undefined','console','document','window'],
    typescript: ['const','let','var','function','return','if','else','for','while','class','import','export','from','default','async','await','new','this','try','catch','throw','switch','case','break','continue','typeof','instanceof','in','of','true','false','null','undefined','console','document','window','interface','type','enum','implements','extends','public','private','protected','readonly'],
    python: ['def','class','return','if','elif','else','for','while','import','from','as','try','except','finally','raise','with','in','not','and','or','is','True','False','None','self','print','lambda','yield','pass','break','continue','global'],
    html: ['div','span','p','a','img','h1','h2','h3','h4','h5','h6','ul','ol','li','table','tr','td','th','form','input','button','select','option','textarea','head','body','html','link','script','style','meta','title','section','header','footer','nav','main','article'],
    css: ['color','background','margin','padding','border','display','flex','grid','position','width','height','font','text','align','justify','content','items','gap','overflow','opacity','transition','transform','animation','hover','focus','active','none','auto','solid','center','relative','absolute','fixed','sticky'],
  };
  
  const kwSet = new Set(keywords[lang] || keywords.javascript || []);
  
  // Tokenize roughly
  const tokenRegex = /(\/\/.*$|\/\*[\s\S]*?\*\/|#.*$|"[^"]*"|'[^']*'|`[^`]*`|\b\d+\.?\d*\b|[a-zA-Z_$][a-zA-Z0-9_$]*|[{}()\[\];,.<>!=+\-*/%&|^~?:]|\s+)/gm;
  let match;
  let idx = 0;
  
  while ((match = tokenRegex.exec(line)) !== null) {
    const token = match[0];
    let className = '';
    
    if (/^\/\/|^\/\*|^#/.test(token)) {
      className = 'text-white/25 italic'; // comments
    } else if (/^["'`]/.test(token)) {
      className = 'text-green-400/90'; // strings
    } else if (/^\d/.test(token)) {
      className = 'text-orange-400/90'; // numbers
    } else if (kwSet.has(token)) {
      className = 'text-purple-400/90 font-semibold'; // keywords
    } else if (/^[{}()\[\];,.<>!=+\-*/%&|^~?:]$/.test(token)) {
      className = 'text-yellow-400/60'; // operators
    } else if (/^[A-Z]/.test(token)) {
      className = 'text-cyan-400/80'; // PascalCase (classes/components)
    } else if (/^[a-zA-Z_$]/.test(token)) {
      className = 'text-blue-300/80'; // identifiers
    }
    
    elements.push(
      <span key={idx} className={className}>{token}</span>
    );
    idx++;
  }
  
  if (elements.length === 0) {
    elements.push(<span key="raw">{line}</span>);
  }
  
  return elements;
}

export default function CodeBlock({ code, language, filename }: CodeBlockProps) {
  const [copied, setCopied] = useState(false);
  const [collapsed, setCollapsed] = useState(false);
  const { createFile, currentSession, fetchFiles } = useAgent();
  const lines = code.split('\n');
  const isLong = lines.length > 30;
  
  const handleCopy = () => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleOpenInEditor = async () => {
    if (!currentSession) return;
    const fname = filename || `code.${language === 'javascript' ? 'js' : language === 'typescript' ? 'ts' : language === 'python' ? 'py' : language}`;
    await createFile(fname, code, language);
    await fetchFiles();
  };

  const displayLines = collapsed ? lines.slice(0, 8) : lines;

  return (
    <motion.div
      initial={{ opacity: 0, y: 5 }}
      animate={{ opacity: 1, y: 0 }}
      className="rounded-xl border border-white/10 overflow-hidden bg-[#0d0d18]"
    >
      {/* Header bar */}
      <div className="flex items-center justify-between px-3 py-1.5 bg-white/5 border-b border-white/5">
        <div className="flex items-center gap-2 min-w-0">
          <FileCode size={11} className="text-yellow-400 shrink-0" />
          <span className="text-[10px] font-mono text-white/50 truncate">
            {filename || language}
          </span>
          <span className="text-[9px] text-white/20">{lines.length} lines</span>
        </div>
        <div className="flex items-center gap-1 shrink-0">
          {isLong && (
            <button
              onClick={() => setCollapsed(!collapsed)}
              className="p-1 text-white/25 hover:text-white/50 transition-colors"
              title={collapsed ? 'Expand' : 'Collapse'}
            >
              {collapsed ? <ChevronDown size={12} /> : <ChevronUp size={12} />}
            </button>
          )}
          <button
            onClick={handleCopy}
            className="p-1 text-white/25 hover:text-white/50 transition-colors"
            title="Copy code"
          >
            {copied ? <Check size={12} className="text-green-400" /> : <Copy size={12} />}
          </button>
          <button
            onClick={handleOpenInEditor}
            className="flex items-center gap-1 px-1.5 py-0.5 rounded text-[9px] font-bold text-yellow-400/60 hover:text-yellow-400 hover:bg-yellow-400/10 transition-colors"
            title="Open in Code Editor"
          >
            <FileCode size={10} />
            Open
          </button>
        </div>
      </div>

      {/* Code content */}
      <div className="overflow-x-auto overflow-y-auto max-h-[400px] scrollbar-thin">
        <div className="flex min-w-0">
          {/* Line numbers */}
          <div className="shrink-0 py-2 select-none bg-white/[0.02] border-r border-white/5">
            {displayLines.map((_, i) => (
              <div key={i} className="text-[9px] text-white/15 text-right pr-2 pl-2 leading-[18px] font-mono">
                {i + 1}
              </div>
            ))}
          </div>
          {/* Code */}
          <pre className="flex-1 py-2 px-3 overflow-x-auto">
            <code className="text-[11px] leading-[18px] font-mono">
              {displayLines.map((line, i) => (
                <div key={i} className="whitespace-pre">
                  {highlightLine(line, language)}
                </div>
              ))}
            </code>
          </pre>
        </div>
      </div>

      {/* Collapsed indicator */}
      {collapsed && isLong && (
        <button
          onClick={() => setCollapsed(false)}
          className="w-full py-1.5 text-[9px] text-white/25 hover:text-white/50 bg-white/[0.02] border-t border-white/5 font-mono transition-colors"
        >
          ... {lines.length - 8} more lines (click to expand)
        </button>
      )}
    </motion.div>
  );
}
