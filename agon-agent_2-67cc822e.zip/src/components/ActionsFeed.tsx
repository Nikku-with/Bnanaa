import { useAgent } from '../context/AgentContext';
import { motion, AnimatePresence } from 'framer-motion';
import { Activity, Zap, Trash2 } from 'lucide-react';

export default function ActionsFeed() {
  const { recentActions, agentStatus } = useAgent();

  const getActionIcon = (action: string) => {
    if (action.includes('thinking') || action.includes('REASONING')) return '🧠';
    if (action.includes('PLANNING')) return '📋';
    if (action.includes('CODING')) return '💻';
    if (action.includes('ANALYZING')) return '🔍';
    if (action.includes('RESEARCHING')) return '🌐';
    if (action.includes('OPTIMIZING')) return '⚡';
    if (action.includes('File:') || action.includes('saved')) return '📄';
    if (action.includes('complete')) return '✅';
    if (action.includes('Error')) return '❌';
    if (action.includes('Created')) return '🆕';
    if (action.includes('Deleted')) return '🗑️';
    return '⚡';
  };

  return (
    <div className="flex-1 flex flex-col overflow-hidden min-h-0">
      {/* Header */}
      <div className="px-3 py-2.5 border-b border-white/5 flex items-center gap-2 shrink-0">
        <Activity size={13} className="text-yellow-400" />
        <span className="text-xs font-bold text-white/60 uppercase tracking-wider">Live Actions</span>
        {agentStatus !== 'idle' && (
          <motion.div
            animate={{ scale: [1, 1.5, 1], opacity: [1, 0.3, 1] }}
            transition={{ duration: 1, repeat: Infinity }}
            className="w-2 h-2 rounded-full bg-green-400 ml-auto shadow-sm shadow-green-400/50"
          />
        )}
      </div>

      {/* Actions List */}
      <div className="flex-1 overflow-y-auto min-h-0 px-2 py-2 space-y-1 scrollbar-thin">
        <AnimatePresence initial={false}>
          {recentActions.map((action, idx) => (
            <motion.div
              key={`${action}-${idx}`}
              initial={{ opacity: 0, x: 30, height: 0 }}
              animate={{ opacity: 1, x: 0, height: 'auto' }}
              exit={{ opacity: 0, x: -30, height: 0 }}
              transition={{ type: 'spring', damping: 20, stiffness: 300 }}
              className="flex items-start gap-1.5 px-2 py-1.5 rounded-lg bg-white/[0.02] border border-white/5 overflow-hidden"
            >
              <span className="text-[10px] shrink-0 mt-px">{getActionIcon(action)}</span>
              <span className="text-[10px] text-white/35 font-mono break-words min-w-0">{action}</span>
            </motion.div>
          ))}
        </AnimatePresence>

        {recentActions.length === 0 && (
          <div className="flex flex-col items-center justify-center py-16 text-white/15 text-xs">
            <Zap size={16} className="mb-1" />
            <span>No actions yet</span>
          </div>
        )}
      </div>

      {/* Footer */}
      <div className="px-3 py-2 border-t border-white/5 shrink-0">
        <div className="flex items-center justify-between text-[9px] text-white/20 font-mono">
          <span>50+ tools</span>
          <span>{recentActions.length} actions</span>
        </div>
      </div>
    </div>
  );
}
