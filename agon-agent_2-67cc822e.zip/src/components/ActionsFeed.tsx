import { useAgent } from '../context/AgentContext';
import { motion, AnimatePresence } from 'framer-motion';
import { Activity, Zap, Trash2, BarChart3 } from 'lucide-react';

const ICONS: Record<string, string> = { thinking:'\ud83e\udde0', REASONING:'\ud83d\udd17', PLANNING:'\ud83d\udcd0', CODING:'\ud83d\udcbb', ANALYZING:'\ud83d\udd0d', RESEARCHING:'\ud83c\udf10', OPTIMIZING:'\u26a1', 'File:':'\ud83d\udcc4', saved:'\ud83d\udcbe', Complete:'\u2705', Error:'\u274c', New:'\ud83c\udd95', Deleted:'\ud83d\uddd1\ufe0f', tokens:'\ud83d\udcca', Search:'\ud83c\udf10' };
function getIcon(a: string) { for (const [k, v] of Object.entries(ICONS)) if (a.includes(k)) return v; return '\u26a1'; }

export default function ActionsFeed() {
  const { recentActions, agentStatus, clearActions, totalTokens } = useAgent();
  return (
    <div className="flex-1 flex flex-col overflow-hidden min-h-0" style={{ background: 'var(--bg-sidebar)' }}>
      <div className="px-3.5 py-2.5 border-b border-[var(--border)] flex items-center gap-2 shrink-0">
        <Activity size={12} className="text-amber-400/70" />
        <span className="text-[11px] font-semibold text-[var(--text-muted)] uppercase tracking-wider flex-1">Activity</span>
        {recentActions.length > 0 && <button onClick={clearActions} className="p-1 text-[var(--text-muted)] hover:text-red-400 transition-colors" title="Clear"><Trash2 size={10} /></button>}
        {agentStatus !== 'idle' && <motion.div animate={{ scale: [1, 1.4, 1], opacity: [0.8, 0.2, 0.8] }} transition={{ duration: 1.2, repeat: Infinity }} className="w-1.5 h-1.5 rounded-full bg-emerald-400" />}
      </div>

      {/* Token counter */}
      {totalTokens > 0 && <div className="px-3.5 py-2 border-b border-[var(--border)] flex items-center gap-2">
        <BarChart3 size={10} className="text-violet-400" />
        <span className="text-[10px] font-mono text-violet-400/70">{totalTokens.toLocaleString()} tokens used</span>
      </div>}

      <div className="flex-1 overflow-y-auto min-h-0 px-2 py-2 space-y-0.5 scrollbar-thin">
        <AnimatePresence initial={false}>
          {recentActions.map((a, i) => <motion.div key={`${a}-${i}`} initial={{ opacity: 0, x: 20, height: 0 }} animate={{ opacity: 1, x: 0, height: 'auto' }} exit={{ opacity: 0, x: -20, height: 0 }} transition={{ type: 'spring', damping: 25, stiffness: 350 }} className="flex items-start gap-2 px-2.5 py-1.5 rounded-xl bg-[var(--bg-input)] border border-[var(--border)] overflow-hidden">
            <span className="text-[10px] shrink-0 mt-px">{getIcon(a)}</span>
            <span className="text-[10px] text-[var(--text-muted)] font-mono break-words min-w-0 leading-relaxed">{a}</span>
          </motion.div>)}
        </AnimatePresence>
        {recentActions.length === 0 && <div className="flex flex-col items-center justify-center py-20 text-[var(--text-muted)] text-[11px] opacity-50"><Zap size={14} className="mb-1.5" /><span>Waiting...</span></div>}
      </div>
      <div className="px-3.5 py-2 border-t border-[var(--border)] shrink-0 flex items-center justify-between text-[8px] text-[var(--text-muted)] font-mono opacity-50"><span>100 tools</span><span>{recentActions.length} events</span></div>
    </div>
  );
}
