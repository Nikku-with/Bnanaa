import { useState } from 'react';
import { motion } from 'framer-motion';
import { Check, Copy, Download, ExternalLink, Star, ChevronDown, ChevronRight, AlertCircle, CheckCircle, AlertTriangle, Info, ToggleLeft, ToggleRight, Send } from 'lucide-react';
import { useAgent } from '../context/AgentContext';

export default function AgentWidget({ type, config }: { type: string; config: string }) {
  const [state, setState] = useState<any>({});
  const { sendMessage } = useAgent();

  // Universal submit handler — sends all collected state to agent
  const submitToAgent = (summary: string) => {
    sendMessage(`[User Selection] ${summary}`);
  };

  if (type === 'buttons') {
    const btns = config.split(',').map(s => s.trim());
    return <div className="flex flex-wrap gap-1.5 my-1.5">{btns.map((b, i) => <motion.button key={i} whileTap={{ scale: 0.95 }} onClick={() => submitToAgent(b)} className="px-3 py-1.5 rounded-xl text-[11px] font-semibold border bg-white/[0.03] border-white/[0.06] text-[var(--text-body)] hover:bg-amber-500/10 hover:border-amber-500/20 hover:text-amber-400 transition-all">{b}</motion.button>)}</div>;
  }

  if (type === 'checklist') {
    const items = config.split(',').map(s => s.trim());
    const checked = state.checked || {};
    const submitted = state.submitted;
    return <div className="my-2 bg-white/[0.02] border border-white/[0.05] rounded-xl p-3">
      <div className="space-y-1 mb-2">{items.map((item, i) => <label key={i} className="flex items-center gap-2.5 px-2 py-1.5 rounded-lg hover:bg-white/[0.03] cursor-pointer transition-colors"><input type="checkbox" checked={!!checked[i]} onChange={() => !submitted && setState({ ...state, checked: { ...checked, [i]: !checked[i] } })} className="accent-amber-500 w-3.5 h-3.5" /><span className={`text-[11px] ${checked[i] ? 'text-amber-400 font-medium' : 'text-[var(--text-body)]'}`}>{item}</span></label>)}</div>
      {!submitted ? <button onClick={() => { setState({ ...state, submitted: true }); const sel = items.filter((_, i) => checked[i]); submitToAgent(`Selected: ${sel.join(', ') || 'none'}`); }} className="w-full py-1.5 rounded-lg bg-amber-500/10 border border-amber-500/15 text-amber-400 text-[10px] font-bold hover:bg-amber-500/15 transition-colors"><Send size={10} className="inline mr-1" />Submit Selections</button> : <div className="text-[10px] text-emerald-400/60 text-center">✓ Submitted</div>}
    </div>;
  }

  if (type === 'choice') {
    const opts = config.split(',').map(s => s.trim());
    const submitted = state.submitted;
    return <div className="my-2 bg-white/[0.02] border border-white/[0.05] rounded-xl p-3">
      <div className="flex flex-wrap gap-1.5 mb-2">{opts.map((o, i) => <button key={i} onClick={() => !submitted && setState({ ...state, selected: o })} className={`px-3 py-1.5 rounded-xl text-[11px] font-medium border transition-all ${state.selected === o ? 'bg-amber-500/15 border-amber-500/25 text-amber-400' : 'bg-white/[0.02] border-white/[0.05] text-[var(--text-muted)] hover:bg-white/[0.05]'}`}>{state.selected === o && <Check size={10} className="inline mr-1" />}{o}</button>)}</div>
      {!submitted && state.selected ? <button onClick={() => { setState({ ...state, submitted: true }); submitToAgent(`Chose: ${state.selected}`); }} className="w-full py-1.5 rounded-lg bg-amber-500/10 border border-amber-500/15 text-amber-400 text-[10px] font-bold hover:bg-amber-500/15 transition-colors"><Send size={10} className="inline mr-1" />Confirm Choice</button> : submitted && <div className="text-[10px] text-emerald-400/60 text-center">✓ {state.selected}</div>}
    </div>;
  }

  if (type === 'progress') { const [pct, label] = config.split(':'); const p = parseInt(pct) || 0; return <div className="my-2 bg-white/[0.02] border border-white/[0.05] rounded-xl p-3"><div className="flex justify-between text-[10px] mb-1.5"><span className="text-[var(--text-body)] font-medium">{label || 'Progress'}</span><span className="text-amber-400 font-mono">{p}%</span></div><div className="h-2 bg-white/[0.04] rounded-full overflow-hidden"><motion.div initial={{ width: 0 }} animate={{ width: `${p}%` }} transition={{ duration: 1 }} className="h-full rounded-full bg-gradient-to-r from-amber-500 to-orange-500" /></div></div>; }

  if (type === 'color_palette') { const colors = config.split(',').map(s => s.trim()); return <div className="flex gap-2 my-2 flex-wrap">{colors.map((c, i) => <button key={i} onClick={() => navigator.clipboard.writeText(c)} className="group relative"><div className="w-8 h-8 rounded-lg border border-white/10 shadow-md hover:scale-110 transition-transform" style={{ background: c }} /><span className="absolute -bottom-4 left-1/2 -translate-x-1/2 text-[7px] font-mono text-[var(--text-muted)] opacity-0 group-hover:opacity-100">{c}</span></button>)}</div>; }

  if (type === 'link') { const parts = config.split(':'); const text = parts[0]; const url = parts.slice(1).join(':') || '#'; return <a href={url} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-blue-500/8 border border-blue-500/12 text-blue-400 text-[11px] font-medium hover:bg-blue-500/12 transition-colors my-1"><ExternalLink size={11} />{text}</a>; }
  if (type === 'download') { return <button className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-500/8 border border-emerald-500/12 text-emerald-400 text-[11px] font-medium hover:bg-emerald-500/12 transition-colors my-1"><Download size={11} />{config.split(':')[0]}</button>; }
  if (type === 'note') { const [title, ...rest] = config.split(':'); return <div className="my-2 bg-amber-500/[0.04] border border-amber-500/10 rounded-xl p-3"><div className="text-[10px] font-bold text-amber-400/70 uppercase tracking-wider mb-1">📌 {title}</div><div className="text-[11px] text-[var(--text-body)] leading-relaxed">{rest.join(':')}</div></div>; }
  if (type === 'rating') { const max = parseInt(config) || 5; const r = state.rating || 0; return <div className="flex gap-0.5 my-1.5">{Array.from({ length: max }, (_, i) => <button key={i} onClick={() => { setState({ ...state, rating: i + 1 }); submitToAgent(`Rating: ${i + 1}/${max}`); }}><Star size={16} className={i < r ? 'text-amber-400 fill-amber-400' : 'text-white/12'} /></button>)}</div>; }
  if (type === 'toggle') { const [label, def] = config.split(':'); const on = state.on ?? (def === 'on'); return <button onClick={() => { const v = !on; setState({ ...state, on: v }); submitToAgent(`${label}: ${v ? 'ON' : 'OFF'}`); }} className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-white/[0.02] border border-white/[0.05] my-1 hover:bg-white/[0.04] transition-colors">{on ? <ToggleRight size={16} className="text-emerald-400" /> : <ToggleLeft size={16} className="text-white/20" />}<span className={`text-[11px] font-medium ${on ? 'text-emerald-400' : 'text-[var(--text-muted)]'}`}>{label}</span></button>; }
  if (type === 'alert') { const [level, ...msg] = config.split(':'); const s: Record<string, { bg: string; border: string; text: string; Icon: any }> = { info: { bg: 'bg-blue-500/[0.05]', border: 'border-blue-500/10', text: 'text-blue-400', Icon: Info }, success: { bg: 'bg-emerald-500/[0.05]', border: 'border-emerald-500/10', text: 'text-emerald-400', Icon: CheckCircle }, warning: { bg: 'bg-amber-500/[0.05]', border: 'border-amber-500/10', text: 'text-amber-400', Icon: AlertTriangle }, error: { bg: 'bg-red-500/[0.05]', border: 'border-red-500/10', text: 'text-red-400', Icon: AlertCircle } }; const c = s[level] || s.info; return <div className={`flex items-start gap-2 px-3 py-2.5 rounded-xl ${c.bg} border ${c.border} my-1.5`}><c.Icon size={13} className={`${c.text} mt-0.5 shrink-0`} /><span className={`text-[11px] ${c.text} leading-relaxed`}>{msg.join(':')}</span></div>; }
  if (type === 'badge') { const [text, color] = config.split(':'); return <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[9px] font-bold uppercase tracking-wider" style={{ background: `${color || '#f59e0b'}15`, color: color || '#f59e0b', border: `1px solid ${color || '#f59e0b'}25` }}>{text}</span>; }
  if (type === 'chart') { const [, ...d] = config.split(':'); const pairs = d.join(':').split(',').map(s => { const [l, v] = s.split('='); return { l: l?.trim(), v: parseInt(v) || 0 }; }); const max = Math.max(...pairs.map(p => p.v), 1); return <div className="my-2 bg-white/[0.02] border border-white/[0.04] rounded-xl p-3 space-y-1.5">{pairs.map((p, i) => <div key={i} className="flex items-center gap-2"><span className="text-[9px] text-[var(--text-muted)] font-mono w-14 truncate text-right">{p.l}</span><div className="flex-1 h-5 bg-white/[0.03] rounded-lg overflow-hidden"><motion.div initial={{ width: 0 }} animate={{ width: `${(p.v / max) * 100}%` }} transition={{ duration: 0.8, delay: i * 0.1 }} className="h-full rounded-lg bg-gradient-to-r from-violet-500 to-blue-500 flex items-center justify-end pr-1.5"><span className="text-[8px] text-white font-bold">{p.v}</span></motion.div></div></div>)}</div>; }
  if (type === 'timeline') { const steps = config.split(',').map(s => s.trim()); return <div className="my-2 flex items-center gap-0">{steps.map((s, i) => <div key={i} className="flex items-center"><div className="flex flex-col items-center"><div className="w-6 h-6 rounded-full bg-gradient-to-br from-amber-400 to-orange-500 flex items-center justify-center text-[8px] text-black font-bold shadow-sm">{i + 1}</div><span className="text-[8px] text-[var(--text-muted)] mt-1 max-w-[60px] text-center leading-tight">{s}</span></div>{i < steps.length - 1 && <div className="w-6 h-px bg-amber-500/20 mx-0.5" />}</div>)}</div>; }
  if (type === 'copy') { const [cp, setCp] = useState(false); return <button onClick={() => { navigator.clipboard.writeText(config); setCp(true); setTimeout(() => setCp(false), 1500); }} className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white/[0.03] border border-white/[0.05] text-[10px] text-[var(--text-muted)] hover:text-[var(--text-body)] font-mono my-1 transition-colors">{cp ? <><Check size={10} className="text-emerald-400" />Copied</> : <><Copy size={10} />{config.slice(0, 50)}</>}</button>; }
  if (type === 'kbd') { return <kbd className="inline-flex items-center px-2 py-0.5 rounded-md bg-white/[0.05] border border-white/[0.08] text-[10px] text-[var(--text-body)] font-mono shadow-sm">{config}</kbd>; }
  if (type === 'divider') { return <div className="my-3 border-t border-[var(--border)]" />; }
  if (type === 'quote') { const [text, author] = config.split(':'); return <div className="my-2 border-l-2 border-amber-500/25 pl-3 py-1"><p className="text-[11px] text-[var(--text-body)] italic">"{text}"</p>{author && <p className="text-[9px] text-[var(--text-muted)] mt-1">— {author}</p>}</div>; }
  if (type === 'stat') { const [label, value, change] = config.split(':'); return <div className="inline-flex flex-col px-3 py-2 rounded-xl bg-white/[0.02] border border-white/[0.05] my-1"><span className="text-[9px] text-[var(--text-muted)] uppercase tracking-wider">{label}</span><span className="text-lg font-bold text-[var(--text-primary)]">{value}</span>{change && <span className={`text-[9px] font-semibold ${change.startsWith('+') ? 'text-emerald-400' : 'text-red-400'}`}>{change}</span>}</div>; }
  if (type === 'accordion') { const [title, ...rest] = config.split(':'); const open = state.open ?? false; return <div className="my-1.5 border border-white/[0.05] rounded-xl overflow-hidden"><button onClick={() => setState({ ...state, open: !open })} className="w-full flex items-center gap-2 px-3 py-2 bg-white/[0.02] hover:bg-white/[0.04] transition-colors">{open ? <ChevronDown size={12} className="text-[var(--text-muted)]" /> : <ChevronRight size={12} className="text-[var(--text-muted)]" />}<span className="text-[11px] text-[var(--text-body)] font-medium">{title}</span></button>{open && <div className="px-3 py-2 text-[11px] text-[var(--text-muted)] border-t border-white/[0.04]">{rest.join(':')}</div>}</div>; }
  if (type === 'table') { const rows = config.split('|').map(r => r.split(',').map(c => c.trim())); const hd = rows[0]; const bd = rows.slice(1); return <div className="my-2 overflow-x-auto rounded-xl border border-white/[0.05]"><table className="w-full text-[10px]"><thead><tr>{hd.map((h, i) => <th key={i} className="px-3 py-2 text-left text-[var(--text-muted)] font-semibold uppercase tracking-wider border-b border-white/[0.05] bg-white/[0.02]">{h}</th>)}</tr></thead><tbody>{bd.map((row, i) => <tr key={i}>{row.map((c, j) => <td key={j} className="px-3 py-2 text-[var(--text-body)] border-b border-white/[0.02]">{c}</td>)}</tr>)}</tbody></table></div>; }

  return null;
}

export function parseWidgets(text: string) {
  const segs: Array<{ type: 'text' | 'widget'; value: string; widgetType?: string; widgetConfig?: string }> = [];
  const rx = /\[WIDGET:([\w_]+):([^\]]+)\]/g;
  let last = 0, m;
  while ((m = rx.exec(text)) !== null) {
    if (m.index > last) { const t = text.slice(last, m.index); if (t.trim()) segs.push({ type: 'text', value: t }); }
    segs.push({ type: 'widget', value: m[0], widgetType: m[1], widgetConfig: m[2] });
    last = m.index + m[0].length;
  }
  if (last < text.length) { const t = text.slice(last); if (t.trim()) segs.push({ type: 'text', value: t }); }
  if (segs.length === 0 && text.trim()) segs.push({ type: 'text', value: text });
  return segs;
}
