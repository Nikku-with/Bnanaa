import { useState, useEffect } from 'react';

export type DeviceType = 'mobile' | 'tablet' | 'desktop';

export function useDevice(): { device: DeviceType; isMobile: boolean; isTablet: boolean; isDesktop: boolean } {
  const [device, setDevice] = useState<DeviceType>('desktop');

  useEffect(() => {
    const check = () => {
      const w = window.innerWidth;
      const ua = navigator.userAgent;
      const isTouchDevice = 'ontouchstart' in window || navigator.maxTouchPoints > 0;
      if (w < 768 || (/iPhone|Android.*Mobile/i.test(ua) && isTouchDevice)) setDevice('mobile');
      else if (w < 1024 || (/iPad|Android(?!.*Mobile)/i.test(ua) && isTouchDevice)) setDevice('tablet');
      else setDevice('desktop');
    };
    check();
    window.addEventListener('resize', check);
    return () => window.removeEventListener('resize', check);
  }, []);

  return { device, isMobile: device === 'mobile', isTablet: device === 'tablet', isDesktop: device === 'desktop' };
}
