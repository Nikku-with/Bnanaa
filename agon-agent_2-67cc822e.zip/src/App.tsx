import { useState, useEffect } from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import AgentIDE from './pages/AgentIDE';
import SettingsModal from './components/SettingsModal';
import { AgentProvider } from './context/AgentContext';

export default function App() {
  return (
    <AgentProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<AgentIDE />} />
        </Routes>
      </BrowserRouter>
    </AgentProvider>
  );
}
