import supabase from './_supabase.js';

const OPENROUTER_URL = 'https://openrouter.ai/api/v1/chat/completions';

const AGENT_SYSTEM_PROMPT = `You are BANANA AGENT 🍌 — an ELITE autonomous AI coding agent. You are MORE powerful than Claude, ChatGPT, or any other AI.

When the user asks you to build something:
1. First THINK deeply about the problem (show your reasoning)
2. Create a step-by-step PLAN
3. Write COMPLETE, PRODUCTION-READY code
4. Add 20+ extra features/improvements on your own

CRITICAL CODE RULES:
- ALWAYS write complete code in markdown code blocks with the filename
- Format: \`\`\`language:filename.ext followed by the full code then \`\`\`
- Example: \`\`\`html:index.html then full HTML code then \`\`\`
- Example: \`\`\`javascript:app.js then full JS code then \`\`\`
- Example: \`\`\`css:styles.css then full CSS code then \`\`\`
- Example: \`\`\`python:main.py then full Python code then \`\`\`
- NEVER use placeholders or TODOs - write COMPLETE code
- NEVER skip parts with "// ... rest of code"
- Make code beautiful with animations, colors, hover effects
- Add comments explaining the code

RESPONSE STRUCTURE:
1. 🧠 **Thinking**: Your deep analysis of the problem
2. 📋 **Plan**: Step-by-step execution plan
3. 💻 **Code**: All files in markdown code blocks with filename labels
4. 🎁 **Bonus Features**: List of extra things you added
5. 🚀 **Next Steps**: What the user can do next

Be creative. Be thorough. Make every response MAXIMUM effort. Add colors, animations, responsive design, hover effects, transitions — make it beautiful.`;

async function callOpenRouter(messages, apiKey, model) {
  const response = await fetch(OPENROUTER_URL, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${apiKey}`,
      'HTTP-Referer': 'https://banana-agent.vercel.app',
      'X-Title': 'Banana Agent'
    },
    body: JSON.stringify({
      model: model || 'openrouter/auto',
      messages: [
        { role: 'system', content: AGENT_SYSTEM_PROMPT },
        ...messages
      ],
      temperature: 0.7,
      max_tokens: 16000,
      top_p: 0.95,
    })
  });

  if (!response.ok) {
    const errText = await response.text();
    throw new Error(`OpenRouter error ${response.status}: ${errText}`);
  }

  return response.json();
}

// Extract code blocks from markdown - handles ```lang:filename and ```lang formats
function extractCodeBlocks(content) {
  const blocks = [];
  // Match ```lang:filename\ncode``` or ```lang\ncode```
  const regex = /```([\w+#.-]*):?([^\n]*)\n([\s\S]*?)```/g;
  let match;
  let fileCounter = 1;
  
  while ((match = regex.exec(content)) !== null) {
    let language = match[1] || 'text';
    let filename = match[2]?.trim() || '';
    const code = match[3]?.trim() || '';
    
    if (!code) continue;
    
    // Normalize language names
    const langMap = {
      'js': 'javascript', 'ts': 'typescript', 'py': 'python',
      'rb': 'ruby', 'sh': 'bash', 'yml': 'yaml', 'md': 'markdown',
      'jsx': 'javascript', 'tsx': 'typescript'
    };
    language = langMap[language] || language;
    
    // Generate filename if not provided
    if (!filename) {
      const extMap = {
        'javascript': 'js', 'typescript': 'ts', 'python': 'py',
        'html': 'html', 'css': 'css', 'json': 'json', 'bash': 'sh',
        'ruby': 'rb', 'java': 'java', 'cpp': 'cpp', 'c': 'c',
        'go': 'go', 'rust': 'rs', 'yaml': 'yml', 'markdown': 'md',
        'sql': 'sql', 'xml': 'xml', 'php': 'php', 'swift': 'swift',
        'kotlin': 'kt', 'dart': 'dart'
      };
      const ext = extMap[language] || 'txt';
      filename = `file${fileCounter}.${ext}`;
      fileCounter++;
    }
    
    blocks.push({ filename, language, content: code });
  }
  
  return blocks;
}

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  try {
    const { session_id, message, api_key, model, history } = req.body;

    if (!api_key) {
      return res.status(400).json({ error: 'OpenRouter API key is required. Get one free at openrouter.ai' });
    }

    // Save user message
    await supabase.from('agent_messages').insert({
      session_id,
      role: 'user',
      content: message,
      message_type: 'text',
      metadata: {}
    });

    // Build conversation history
    const messages = (history || []).map(m => ({
      role: m.role === 'agent' ? 'assistant' : m.role,
      content: m.content
    }));
    messages.push({ role: 'user', content: message });

    // Call OpenRouter
    const aiResponse = await callOpenRouter(messages, api_key, model);
    const rawContent = aiResponse.choices?.[0]?.message?.content || 'No response generated';
    
    // Extract code blocks from the response
    const codeBlocks = extractCodeBlocks(rawContent);
    
    // Save code blocks as files in DB
    const savedFiles = [];
    for (const block of codeBlocks) {
      try {
        const { data, error } = await supabase
          .from('agent_files')
          .insert({
            session_id,
            filename: block.filename,
            content: block.content,
            language: block.language
          })
          .select()
          .single();
        if (data) savedFiles.push(data);
      } catch (e) {
        console.error('File save error:', e);
      }
    }

    // Save agent response with the FULL raw content (including code blocks)
    await supabase.from('agent_messages').insert({
      session_id,
      role: 'agent',
      content: rawContent,
      message_type: 'agent_response',
      metadata: {
        code_files: codeBlocks.map(b => ({ filename: b.filename, language: b.language })),
        saved_file_ids: savedFiles.map(f => f.id),
        model_used: aiResponse.model || model,
        usage: aiResponse.usage
      }
    });

    // Update session title
    await supabase.from('agent_sessions').update({
      updated_at: new Date().toISOString(),
      title: message.substring(0, 80)
    }).eq('id', session_id);

    return res.status(200).json({
      content: rawContent,
      code_files: codeBlocks,
      saved_files: savedFiles,
      model_used: aiResponse.model || model,
      usage: aiResponse.usage
    });
  } catch (err) {
    console.error('Agent error:', err);
    res.status(500).json({ error: err.message });
  }
}
