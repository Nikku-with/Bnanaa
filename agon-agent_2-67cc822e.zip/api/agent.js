import supabase from './_supabase.js';

const NORMAL_PROMPT = `You are BANANA AGENT \ud83c\udf4c \u2014 the most powerful autonomous AI coding agent. 100+ tools. Memory. Web search. Live preview.

RULES:
1. CODE: \`\`\`language:filename.ext with COMPLETE code
2. WIDGETS: Use 5+ widgets EVERY response:
[WIDGET:buttons:A,B,C] [WIDGET:checklist:Step1,Step2] [WIDGET:choice:React,Vue,Svelte]
[WIDGET:progress:75:Building] [WIDGET:color_palette:#FF6B6B,#4ECDC4,#45B7D1,#96CEB4]
[WIDGET:alert:info:Important note] [WIDGET:chart:bar:JS=95,TS=88,React=92]
[WIDGET:timeline:Setup,Code,Test,Deploy] [WIDGET:copy:npm install]
[WIDGET:table:Feature,Status|Auth,Done|API,WIP] [WIDGET:stat:Users:1234:+12%]
[WIDGET:toggle:Feature:on] [WIDGET:rating:5] [WIDGET:note:Tip:Remember this]
[WIDGET:badge:NEW:#10b981] [WIDGET:link:Docs:https://example.com]
3. Format with ## headers, **bold**, lists
4. Add 20+ bonus features automatically
5. Be interactive, creative, thorough`;

const MODE_3D = `You are BANANA AGENT in 3D MAX MODE \u2014 NEXUS-3D. Build Awwwards-level 3D sites with Three.js, R3F, GSAP, shaders. Every project: 3D objects, particles, post-processing, scroll animations, custom cursor. Use widgets. Complete code only.`;
const MODE_ADV = `You are BANANA AGENT in ADVANCED MODE \u2014 FORGE. 6-layer deep reasoning: Decompose > Architecture > Info Check > Design > Quality > Deliver. Zero placeholders. Add WOW factor. Use widgets. Complete code only.`;

function getSysPrompt(mode, custom, mem, search) {
  let p = mode === '3d_max' ? MODE_3D : mode === 'advanced' ? MODE_ADV : mode === 'custom' && custom ? custom : NORMAL_PROMPT;
  if (mem) p += `\n\nMEMORY:\n${mem}`;
  if (search) p += `\n\nSEARCH RESULTS:\n${search}`;
  return p;
}

function extractCode(c) {
  const b = []; const rx = /```([\w+#.-]*):?([^\n]*)\n([\s\S]*?)```/g; let m, i = 1;
  while ((m = rx.exec(c)) !== null) {
    let l = m[1] || 'text', f = m[2]?.trim() || '', code = m[3]?.trim();
    if (!code) continue;
    const lm = {js:'javascript',ts:'typescript',py:'python',jsx:'javascript',tsx:'typescript'};
    l = lm[l] || l;
    if (!f) { const em = {javascript:'js',typescript:'ts',python:'py',html:'html',css:'css',json:'json'}; f = `file${i++}.${em[l]||'txt'}`; }
    b.push({ filename: f, language: l, content: code });
  }
  return b;
}

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') return res.status(204).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  try {
    const { session_id, message, api_key, groq_key, provider, model, history, mode, custom_prompt, memory_context, search_results } = req.body;
    const key = provider === 'groq' ? groq_key : api_key;
    if (!key) return res.status(400).json({ error: 'API key required' });

    await supabase.from('agent_messages').insert({ session_id, role: 'user', content: message, message_type: 'text', metadata: {} });

    const sysPrompt = getSysPrompt(mode, custom_prompt, memory_context, search_results);
    const msgs = [{ role: 'system', content: sysPrompt }];
    for (const m of (history || [])) msgs.push({ role: m.role === 'agent' ? 'assistant' : m.role, content: m.content });
    msgs.push({ role: 'user', content: message });

    // Set streaming headers
    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');

    const apiUrl = provider === 'groq' ? 'https://api.groq.com/openai/v1/chat/completions' : 'https://openrouter.ai/api/v1/chat/completions';
    const headers = { 'Content-Type': 'application/json', 'Authorization': `Bearer ${key}` };
    if (provider !== 'groq') { headers['HTTP-Referer'] = 'https://banana-agent.vercel.app'; headers['X-Title'] = 'Banana Agent'; }

    const apiRes = await fetch(apiUrl, {
      method: 'POST', headers,
      body: JSON.stringify({ model: model || 'openrouter/auto', messages: msgs, temperature: 0.7, max_tokens: 16000, stream: true })
    });

    if (!apiRes.ok) {
      const errText = await apiRes.text();
      res.write(`data: ${JSON.stringify({ error: `API ${apiRes.status}: ${errText.slice(0, 200)}` })}\n\n`);
      res.end();
      return;
    }

    let fullContent = '';
    let usage = null;
    const reader = apiRes.body.getReader();
    const decoder = new TextDecoder();

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      const chunk = decoder.decode(value, { stream: true });
      const lines = chunk.split('\n').filter(l => l.startsWith('data: '));

      for (const line of lines) {
        const data = line.slice(6).trim();
        if (data === '[DONE]') {
          res.write(`data: ${JSON.stringify({ done: true })}\n\n`);
          continue;
        }
        try {
          const parsed = JSON.parse(data);
          const delta = parsed.choices?.[0]?.delta?.content || '';
          if (delta) {
            fullContent += delta;
            res.write(`data: ${JSON.stringify({ token: delta })}\n\n`);
          }
          if (parsed.usage) usage = parsed.usage;
          if (parsed.choices?.[0]?.finish_reason === 'stop') {
            // Try to get usage from the final chunk
            if (parsed.usage) usage = parsed.usage;
          }
        } catch {}
      }
    }

    // Save to DB after streaming complete
    const codeBlocks = extractCode(fullContent);
    const savedFiles = [];
    for (const block of codeBlocks) {
      try {
        const { data } = await supabase.from('agent_files').insert({ session_id, filename: block.filename, content: block.content, language: block.language }).select().single();
        if (data) savedFiles.push(data);
      } catch {}
    }

    await supabase.from('agent_messages').insert({
      session_id, role: 'agent', content: fullContent, message_type: 'agent_response',
      metadata: { code_files: codeBlocks.map(b => ({ filename: b.filename, language: b.language })), model_used: model, usage, mode }
    });
    await supabase.from('agent_sessions').update({ updated_at: new Date().toISOString(), title: message.substring(0, 80) }).eq('id', session_id);

    // Send final metadata
    res.write(`data: ${JSON.stringify({ complete: true, code_files: codeBlocks.map(b => ({ filename: b.filename, language: b.language })), saved_files: savedFiles.length, usage, model_used: model })}\n\n`);
    res.end();
  } catch (err) {
    console.error('Agent error:', err);
    try { res.write(`data: ${JSON.stringify({ error: err.message })}\n\n`); res.end(); } catch { res.status(500).json({ error: err.message }); }
  }
}
