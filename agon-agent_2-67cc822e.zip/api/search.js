export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') return res.status(204).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  try {
    const { query, api_key, groq_key, provider } = req.body;
    if (!query) return res.status(400).json({ error: 'Query required' });

    // Use the AI model itself to search (it has training data)
    const key = provider === 'groq' ? groq_key : api_key;
    if (!key) return res.status(400).json({ error: 'API key required for search' });

    const apiUrl = provider === 'groq' ? 'https://api.groq.com/openai/v1/chat/completions' : 'https://openrouter.ai/api/v1/chat/completions';
    const headers = { 'Content-Type': 'application/json', 'Authorization': `Bearer ${key}` };
    if (provider !== 'groq') { headers['HTTP-Referer'] = 'https://banana-agent.vercel.app'; headers['X-Title'] = 'Banana Search'; }

    const searchPrompt = `You are a web search assistant. The user wants to find information about: "${query}"

Provide comprehensive, accurate, up-to-date information about this topic. Include:
- Key facts and explanations
- Relevant code examples if it's a programming topic
- Best practices and recommendations
- Links/references you know about

Be thorough and factual. Format with markdown.`;

    const r = await fetch(apiUrl, {
      method: 'POST', headers,
      body: JSON.stringify({
        model: provider === 'groq' ? 'llama-3.3-70b-versatile' : 'openrouter/auto',
        messages: [{ role: 'user', content: searchPrompt }],
        temperature: 0.3, max_tokens: 3000
      })
    });

    if (!r.ok) {
      // Fallback to DuckDuckGo instant answers
      const ddg = await fetch(`https://api.duckduckgo.com/?q=${encodeURIComponent(query)}&format=json&no_html=1`);
      const d = await ddg.json();
      let text = d.Abstract || '';
      if (d.RelatedTopics) text += '\n' + d.RelatedTopics.slice(0, 5).map(t => t.Text || '').filter(Boolean).join('\n');
      return res.status(200).json({ query, raw: text || 'No results found', source: 'duckduckgo' });
    }

    const data = await r.json();
    return res.status(200).json({ query, raw: data.choices?.[0]?.message?.content || '', source: 'ai' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}
