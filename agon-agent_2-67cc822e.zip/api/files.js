import supabase from './_supabase.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      const { session_id } = req.query;
      let query = supabase.from('agent_files').select('*').order('updated_at', { ascending: false });
      if (session_id) query = query.eq('session_id', session_id);
      const { data, error } = await query.limit(100);
      if (error) throw error;
      return res.status(200).json(data);
    }
    if (req.method === 'POST') {
      const { session_id, filename, content, language } = req.body;
      const { data, error } = await supabase
        .from('agent_files')
        .insert({ session_id, filename, content, language: language || 'text' })
        .select()
        .single();
      if (error) throw error;
      return res.status(201).json(data);
    }
    if (req.method === 'PUT') {
      const { id, content, filename } = req.body;
      const updates = { updated_at: new Date().toISOString() };
      if (content !== undefined) updates.content = content;
      if (filename) updates.filename = filename;
      const { data, error } = await supabase
        .from('agent_files')
        .update(updates)
        .eq('id', id)
        .select()
        .single();
      if (error) throw error;
      return res.status(200).json(data);
    }
    if (req.method === 'DELETE') {
      const { id } = req.body;
      const { error } = await supabase.from('agent_files').delete().eq('id', id);
      if (error) throw error;
      return res.status(200).json({ ok: true });
    }
    res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('API error:', err);
    res.status(500).json({ error: err.message });
  }
}
