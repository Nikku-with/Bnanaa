import supabase from './_supabase.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      const { session_id } = req.query;
      let query = supabase.from('agent_memory').select('*').order('updated_at', { ascending: false });
      if (session_id) query = query.eq('session_id', parseInt(session_id));
      const { data, error } = await query.limit(100);
      if (error) throw error;
      return res.status(200).json(data);
    }
    if (req.method === 'POST') {
      const { session_id, key, value, category } = req.body;
      const { data: existing } = await supabase.from('agent_memory').select('id').eq('session_id', session_id).eq('key', key).single();
      if (existing) {
        const { data, error } = await supabase.from('agent_memory').update({ value, category, updated_at: new Date().toISOString() }).eq('id', existing.id).select().single();
        if (error) throw error;
        return res.status(200).json(data);
      }
      const { data, error } = await supabase.from('agent_memory').insert({ session_id, key, value, category: category || 'general' }).select().single();
      if (error) throw error;
      return res.status(201).json(data);
    }
    if (req.method === 'DELETE') {
      const { id } = req.body;
      const { error } = await supabase.from('agent_memory').delete().eq('id', id);
      if (error) throw error;
      return res.status(200).json({ ok: true });
    }
    res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('Memory error:', err);
    res.status(500).json({ error: err.message });
  }
}
