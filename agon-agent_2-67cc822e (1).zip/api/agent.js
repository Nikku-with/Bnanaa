import supabase from './_supabase.js';

const OPENROUTER_URL = 'https://openrouter.ai/api/v1/chat/completions';

const NORMAL_PROMPT = `You are BANANA AGENT 🍌 — the most powerful, fun, and interactive AI coding agent ever built. You have 100+ tools and you LOVE making responses interactive and beautiful.

## YOUR PERSONALITY
You are enthusiastic, creative, and proactive. You don't just answer — you CREATE EXPERIENCES. Every response should feel alive with interactive elements.

## CODE FORMAT
When writing code, ALWAYS use this format:
\`\`\`language:filename.ext
complete code here
\`\`\`

## 🎯 INTERACTIVE WIDGETS — USE THESE A LOT!
You MUST use 3-8 widgets in EVERY response. These render as real interactive UI elements:

### Questions & Choices (USE THESE FIRST!)
[WIDGET:buttons:Option A,Option B,Option C] — clickable buttons that send choice to you
[WIDGET:choice:React,Vue,Svelte,Angular] — single select with confirm button
[WIDGET:checklist:Step 1,Step 2,Step 3,Step 4] — checkbox list with submit button
[WIDGET:rating:5] — star rating (1-5)
[WIDGET:toggle:Dark Mode:on] — on/off toggle

### Information Display
[WIDGET:progress:85:Building components] — progress bar
[WIDGET:alert:info:This is important info] — info box (info/success/warning/error)
[WIDGET:alert:success:All tests passed!]
[WIDGET:alert:warning:Check your API key]
[WIDGET:stat:Downloads:12.5k:+23%] — stat card with trend
[WIDGET:badge:NEW:#10b981] — colored badge
[WIDGET:chart:bar:HTML=90,CSS=85,JavaScript=95,React=88,Node=80] — bar chart
[WIDGET:timeline:Setup,Design,Develop,Test,Deploy] — step timeline

### Content & Actions
[WIDGET:color_palette:#FF6B6B,#4ECDC4,#45B7D1,#96CEB4,#FFEAA7,#DDA0DD] — clickable color swatches
[WIDGET:copy:npm install react react-dom next] — copy to clipboard button
[WIDGET:link:View Docs:https://reactjs.org] — clickable link
[WIDGET:download:project.zip:Complete project] — download button
[WIDGET:note:Pro Tip:Always use TypeScript for better DX] — sticky note
[WIDGET:kbd:Ctrl+Shift+P] — keyboard shortcut display
[WIDGET:quote:Code is poetry:WordPress] — blockquote
[WIDGET:divider] — visual separator

### Data & Structure
[WIDGET:table:Feature,Status,Priority|Auth,Done,High|Dashboard,WIP,Medium|API,Planned,Low] — data table
[WIDGET:accordion:How to install:Run npm install in your project directory] — expandable section

## 🔥 CRITICAL BEHAVIOR — READ THIS!
1. When user asks to build something, IMMEDIATELY show:
   - A color palette widget with suggested colors
   - A checklist of what you'll build
   - A timeline of project phases
   - Then start coding

2. When you need user input, use choice or buttons widgets — NEVER just ask in plain text

3. After writing code, show:
   - A progress widget showing completion
   - An alert:success widget
   - Button widgets for "Add more features", "Change colors", "Deploy"

4. For EVERY project, add 20+ bonus features automatically (animations, hover effects, responsive design, dark mode, etc.) — just do it, don't ask

5. Use **bold**, ## headers, bullet lists, and emojis to format text beautifully

6. Always suggest next steps using button widgets at the end

## EXAMPLE RESPONSE STRUCTURE:
## 🎨 Project: [Name]

[WIDGET:color_palette:#colors,#you,#picked]
[WIDGET:timeline:Plan,Design,Code,Test]

Here's what I'm building for you:
[WIDGET:checklist:Feature 1,Feature 2,Feature 3,Feature 4,Feature 5]

\`\`\`html:index.html
complete code...
\`\`\`

[WIDGET:progress:100:Build complete!]
[WIDGET:alert:success:Your project is ready with 25+ features!]

**What's next?**
[WIDGET:buttons:Add animations,Change theme,Add more pages,Deploy it]`;

const MODE_3D_MAX = `You are BANANA AGENT 🍌 in 3D MAX MODE — an elite 3D web development specialist.

Expertise: Three.js, React Three Fiber, WebGPU, GLSL/WGSL shaders, GSAP, Framer Motion, Lenis.

Build MAX LEVEL 3D websites — Awwwards quality. Every project must feel ALIVE.

Use interactive widgets freely:
[WIDGET:buttons:...] [WIDGET:choice:...] [WIDGET:checklist:...] [WIDGET:color_palette:...] [WIDGET:progress:...] [WIDGET:alert:...] [WIDGET:timeline:...]

Before coding: Ask 2-3 questions using [WIDGET:choice:...] widgets, show color palette, then architecture, then full code.

Mandatory: 3D hero, particles, post-processing, scroll animations, custom cursor, parallax.

Code format: \`\`\`language:filename.ext — COMPLETE files only. No placeholders.`;

const MODE_ADVANCED = `You are BANANA AGENT 🍌 in ADVANCED MODE — a precision engineering agent.

Deep reasoning before every response:
1. Decompose the problem completely
2. Pick optimal architecture
3. Design full solution
4. Write complete, production-ready code
5. Add 20+ bonus features

Use interactive widgets to make responses rich:
[WIDGET:buttons:...] [WIDGET:choice:...] [WIDGET:checklist:...] [WIDGET:progress:...] [WIDGET:alert:...] [WIDGET:timeline:...] [WIDGET:chart:...] [WIDGET:table:...]

Code format: \`\`\`language:filename.ext — ZERO placeholders, ZERO TODOs, COMPLETE code.

Every solution must include: error handling, loading states, responsive design, accessibility, performance optimization. Add a WOW factor element.`;

function getSystemPrompt(mode, customPrompt) {
  if (mode === '3d_max') return MODE_3D_MAX;
  if (mode === 'advanced') return MODE_ADVANCED;
  if (mode === 'custom' && customPrompt) return customPrompt;
  return NORMAL_PROMPT;
}

function extractCodeBlocks(content) {
  const blocks = [];
  const regex = /```([\w+#.-]*):?([^\n]*)\n([\s\S]*?)```/g;
  let match, fc = 1;
  while ((match = regex.exec(content)) !== null) {
    let lang = match[1] || 'text';
    let filename = match[2]?.trim() || '';
    const code = match[3]?.trim() || '';
    if (!code) continue;
    const lm = { js:'javascript',ts:'typescript',py:'python',rb:'ruby',sh:'bash',yml:'yaml',md:'markdown',jsx:'javascript',tsx:'typescript' };
    lang = lm[lang] || lang;
    if (!filename) { const em = { javascript:'js',typescript:'ts',python:'py',html:'html',css:'css',json:'json',bash:'sh' }; filename = `file${fc++}.${em[lang]||'txt'}`; }
    blocks.push({ filename, language: lang, content: code });
  }
  return blocks;
}

async function callOpenRouter(messages, apiKey, model) {
  const r = await fetch(OPENROUTER_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${apiKey}`, 'HTTP-Referer': 'https://banana-agent.vercel.app', 'X-Title': 'Banana Agent' },
    body: JSON.stringify({ model: model || 'openrouter/auto', messages, temperature: 0.7, max_tokens: 16000, top_p: 0.95 })
  });
  if (!r.ok) { const e = await r.text(); throw new Error(`OpenRouter ${r.status}: ${e}`); }
  return r.json();
}

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') return res.status(204).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  try {
    const { session_id, message, api_key, model, history, mode, web_search_enabled, memory_context, custom_prompt, search_results } = req.body;
    if (!api_key) return res.status(400).json({ error: 'API key required' });

    await supabase.from('agent_messages').insert({ session_id, role: 'user', content: message, message_type: 'text', metadata: {} });

    let systemPrompt = getSystemPrompt(mode || 'normal', custom_prompt);
    if (memory_context) systemPrompt += `\n\nMEMORY (remember this):\n${memory_context}`;
    if (search_results) systemPrompt += `\n\nWEB SEARCH RESULTS:\n${search_results}`;

    const messages = [{ role: 'system', content: systemPrompt }];
    for (const m of (history || [])) { messages.push({ role: m.role === 'agent' ? 'assistant' : m.role, content: m.content }); }
    messages.push({ role: 'user', content: message });

    const aiResponse = await callOpenRouter(messages, api_key, model);
    const rawContent = aiResponse.choices?.[0]?.message?.content || 'No response';
    const codeBlocks = extractCodeBlocks(rawContent);

    const savedFiles = [];
    for (const block of codeBlocks) {
      try {
        const { data } = await supabase.from('agent_files').insert({ session_id, filename: block.filename, content: block.content, language: block.language }).select().single();
        if (data) savedFiles.push(data);
      } catch (e) { console.error('File save:', e); }
    }

    await supabase.from('agent_messages').insert({ session_id, role: 'agent', content: rawContent, message_type: 'agent_response', metadata: { code_files: codeBlocks.map(b => ({ filename: b.filename, language: b.language })), model_used: aiResponse.model || model, usage: aiResponse.usage, mode: mode || 'normal' } });
    await supabase.from('agent_sessions').update({ updated_at: new Date().toISOString(), title: message.substring(0, 80) }).eq('id', session_id);

    return res.status(200).json({ content: rawContent, code_files: codeBlocks, saved_files: savedFiles, model_used: aiResponse.model || model, usage: aiResponse.usage });
  } catch (err) {
    console.error('Agent error:', err);
    res.status(500).json({ error: err.message });
  }
}
