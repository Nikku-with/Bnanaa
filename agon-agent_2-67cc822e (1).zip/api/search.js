export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') return res.status(204).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  try {
    const { query, api_key } = req.body;
    if (!query) return res.status(400).json({ error: 'Query required' });
    if (!api_key) return res.status(400).json({ error: 'API key required' });

    // Use the AI model itself to provide search-quality information
    const r = await fetch('https://openrouter.ai/api/v1/chat/completions', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${api_key}`, 'HTTP-Referer': 'https://banana-agent.vercel.app' },
      body: JSON.stringify({
        model: 'openrouter/auto',
        messages: [{
          role: 'user',
          content: `Web search query: "${query}"\n\nProvide comprehensive, current information about this topic. Include:\n- Key facts and details\n- Relevant URLs/documentation links\n- Latest versions/updates if about technology\n- Code examples if applicable\n\nBe thorough and factual.`
        }],
        temperature: 0.3,
        max_tokens: 3000,
      })
    });

    if (!r.ok) throw new Error('Search failed');
    const data = await r.json();
    const content = data.choices?.[0]?.message?.content || '';

    return res.status(200).json({ query, raw: content, source: 'ai_search' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}
