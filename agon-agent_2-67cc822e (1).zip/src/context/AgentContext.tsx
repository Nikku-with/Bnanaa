import { createContext, useContext, useState, useEffect, ReactNode } from 'react';

interface Settings { apiKey: string; model: string; theme: 'dark' | 'light'; customModes: Array<{ name: string; prompt: string }>; }
interface Session { id: number; title: string; model: string; status: string; created_at: string; updated_at: string; pinned?: boolean; }
interface Message { id: number; session_id: number; role: string; content: string; message_type: string; metadata: any; created_at: string; }
interface AgentFile { id: number; session_id: number; filename: string; content: string; language: string; created_at: string; updated_at: string; }

interface AgentContextType {
  settings: Settings; setSettings: (s: Settings) => void;
  sessions: Session[]; currentSession: Session | null; setCurrentSession: (s: Session | null) => void;
  messages: Message[]; files: AgentFile[];
  loading: boolean; agentStatus: string; recentActions: string[];
  fetchSessions: () => Promise<void>; createSession: () => Promise<void>; deleteSession: (id: number) => Promise<void>;
  sendMessage: (msg: string, mode?: string, webSearch?: boolean, customPrompt?: string, searchResults?: string) => Promise<any>;
  fetchFiles: () => Promise<void>; saveFile: (id: number, content: string) => Promise<void>;
  createFile: (fn: string, c: string, l: string) => Promise<void>;
  deleteFile: (id: number) => Promise<void>;
  showSettings: boolean; setShowSettings: (v: boolean) => void;
  memory: any[]; fetchMemory: () => Promise<void>;
  activeTab: string; setActiveTab: (t: string) => void;
}

const AgentContext = createContext<AgentContextType>(null as any);
export function useAgent() { return useContext(AgentContext); }

export function AgentProvider({ children }: { children: ReactNode }) {
  const [settings, setSettingsState] = useState<Settings>(() => { const s = localStorage.getItem('banana_settings'); return s ? JSON.parse(s) : { apiKey: '', model: 'openrouter/auto', theme: 'dark', customModes: [] }; });
  const [sessions, setSessions] = useState<Session[]>([]);
  const [currentSession, setCurrentSession] = useState<Session | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [files, setFiles] = useState<AgentFile[]>([]);
  const [loading, setLoading] = useState(false);
  const [agentStatus, setAgentStatus] = useState('idle');
  const [recentActions, setRecentActions] = useState<string[]>([]);
  const [showSettings, setShowSettings] = useState(false);
  const [memory, setMemory] = useState<any[]>([]);
  const [activeTab, setActiveTab] = useState('chat');

  const setSettings = (s: Settings) => { setSettingsState(s); localStorage.setItem('banana_settings', JSON.stringify(s)); };
  const addAction = (a: string) => setRecentActions(p => [a, ...p].slice(0, 50));

  const fetchSessions = async () => { try { const r = await fetch('/api/sessions'); const d = await r.json(); setSessions(Array.isArray(d) ? d : []); } catch (e) { console.error(e); } };
  const createSession = async () => { try { const r = await fetch('/api/sessions', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ title: 'New Session', model: settings.model }) }); const d = await r.json(); await fetchSessions(); setCurrentSession(d); setMessages([]); setFiles([]); addAction('\ud83c\udd95 New session'); } catch (e) { console.error(e); } };
  const deleteSession = async (id: number) => { try { await fetch('/api/sessions', { method: 'DELETE', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id }) }); if (currentSession?.id === id) { setCurrentSession(null); setMessages([]); setFiles([]); } await fetchSessions(); addAction('\ud83d\uddd1\ufe0f Session deleted'); } catch (e) { console.error(e); } };
  const fetchMessages = async (sid: number) => { try { const r = await fetch(`/api/chat?session_id=${sid}`); const d = await r.json(); setMessages(Array.isArray(d) ? d : []); } catch (e) { console.error(e); } };
  const fetchFiles = async () => { if (!currentSession) return; try { const r = await fetch(`/api/files?session_id=${currentSession.id}`); const d = await r.json(); setFiles(Array.isArray(d) ? d : []); } catch (e) { console.error(e); } };
  const fetchMemory = async () => { if (!currentSession) return; try { const r = await fetch(`/api/memory?session_id=${currentSession.id}`); const d = await r.json(); setMemory(Array.isArray(d) ? d : []); } catch (e) { console.error(e); } };

  const sendMessage = async (msg: string, mode = 'normal', webSearch = false, customPrompt?: string, searchResults?: string) => {
    if (!currentSession || !settings.apiKey) return null;
    setLoading(true); setAgentStatus('thinking'); addAction('\ud83e\udde0 Thinking...');
    try {
      const history = messages.map(m => ({ role: m.role, content: m.content }));
      const memCtx = memory.slice(0, 10).map(m => `${m.key}: ${m.value}`).join('\n');

      let srText = searchResults || '';
      if (webSearch && !srText) {
        try {
          addAction('\ud83c\udf10 Searching web...');
          const sr = await fetch('/api/search', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ query: msg, api_key: settings.apiKey }) });
          const sd = await sr.json();
          srText = sd.raw || sd.results?.map((r: any) => `${r.title}: ${r.snippet}`).join('\n') || '';
          addAction('\u2705 Search complete');
        } catch (e) { console.error('Search failed:', e); }
      }

      const phases = ['reasoning', 'planning', 'analyzing', 'coding', 'researching', 'optimizing'];
      let ci = 0;
      const si = setInterval(() => { setAgentStatus(phases[ci % phases.length]); addAction(`\u26a1 ${phases[ci % phases.length].toUpperCase()}...`); ci++; }, 2500);

      const r = await fetch('/api/agent', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ session_id: currentSession.id, message: msg, api_key: settings.apiKey, model: settings.model, history, mode, web_search_enabled: webSearch, memory_context: memCtx, custom_prompt: customPrompt, search_results: srText }) });
      clearInterval(si);
      if (!r.ok) { const e = await r.json(); throw new Error(e.error || 'Failed'); }
      const data = await r.json();
      setAgentStatus('complete'); addAction('\u2705 Complete');
      if (data.code_files?.length) { data.code_files.forEach((f: any) => addAction(`\ud83d\udcc4 ${f.filename}`)); addAction(`\ud83d\udcbe ${data.code_files.length} files saved`); }
      await fetchMessages(currentSession.id); await fetchFiles(); await fetchMemory();
      return data;
    } catch (err: any) { setAgentStatus('error'); addAction(`\u274c ${err.message}`); if (currentSession) await fetchMessages(currentSession.id); throw err; }
    finally { setLoading(false); setTimeout(() => setAgentStatus('idle'), 3000); }
  };

  const saveFile = async (id: number, c: string) => { try { await fetch('/api/files', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id, content: c }) }); await fetchFiles(); addAction('\ud83d\udcbe Saved'); } catch (e) { console.error(e); } };
  const createFile = async (fn: string, c: string, l: string) => { if (!currentSession) return; try { await fetch('/api/files', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ session_id: currentSession.id, filename: fn, content: c, language: l }) }); } catch (e) { console.error(e); } };
  const deleteFile = async (id: number) => { try { await fetch('/api/files', { method: 'DELETE', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id }) }); await fetchFiles(); addAction('\ud83d\uddd1\ufe0f File deleted'); } catch (e) { console.error(e); } };

  useEffect(() => { fetchSessions(); }, []);
  useEffect(() => { if (currentSession) { fetchMessages(currentSession.id); fetchFiles(); fetchMemory(); } }, [currentSession?.id]);

  // Apply theme to document
  useEffect(() => {
    document.documentElement.setAttribute('data-theme', settings.theme || 'dark');
  }, [settings.theme]);

  return <AgentContext.Provider value={{ settings, setSettings, sessions, currentSession, setCurrentSession, messages, files, loading, agentStatus, recentActions, fetchSessions, createSession, deleteSession, sendMessage, fetchFiles, saveFile, createFile, deleteFile, showSettings, setShowSettings, memory, fetchMemory, activeTab, setActiveTab }}>{children}</AgentContext.Provider>;
}
