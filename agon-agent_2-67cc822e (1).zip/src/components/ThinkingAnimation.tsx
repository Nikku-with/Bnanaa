import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Brain, Code, Search, Zap, Sparkles, Layers, GitBranch, Cpu } from 'lucide-react';

const PHASES = [
  { icon: Brain, label: 'Deep Analysis', gradient: 'from-violet-500 to-purple-600', msg: 'Breaking down your request into components...', code: 'analyzing(request, context, history)' },
  { icon: GitBranch, label: 'LangChain Reasoning', gradient: 'from-blue-500 to-indigo-600', msg: 'Running multi-step reasoning chains...', code: 'chain.invoke({ input, memory, tools })' },
  { icon: Layers, label: 'Architecture Design', gradient: 'from-cyan-500 to-teal-600', msg: 'Planning optimal file structure & patterns...', code: 'architect.plan(requirements, constraints)' },
  { icon: Search, label: 'Research & Verify', gradient: 'from-amber-500 to-orange-600', msg: 'Checking docs, APIs, and best practices...', code: 'search("latest best practices 2025")' },
  { icon: Code, label: 'Generating Code', gradient: 'from-emerald-500 to-green-600', msg: 'Writing production-ready code with 20+ features...', code: 'generate({ quality: "max", features: 20 })' },
  { icon: Zap, label: 'Optimizing Output', gradient: 'from-rose-500 to-pink-600', msg: 'Polishing, testing, and finalizing everything...', code: 'optimize(output, { perf: true, a11y: true })' },
  { icon: Sparkles, label: 'Almost Ready', gradient: 'from-amber-400 to-orange-500', msg: 'Your code is being prepared for delivery...', code: 'deliver(complete_solution)' },
];

export default function ThinkingAnimation({ status }: { status: string }) {
  const [phase, setPhase] = useState(0);
  const [typedCode, setTypedCode] = useState('');

  useEffect(() => {
    const t = setInterval(() => setPhase(p => (p + 1) % PHASES.length), 3500);
    return () => clearInterval(t);
  }, []);

  useEffect(() => {
    const code = PHASES[phase].code;
    setTypedCode('');
    let i = 0;
    const t = setInterval(() => { if (i <= code.length) { setTypedCode(code.slice(0, i)); i++; } else clearInterval(t); }, 40);
    return () => clearInterval(t);
  }, [phase]);

  const p = PHASES[phase];
  const Icon = p.icon;

  return (
    <motion.div initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} className="flex gap-3 max-w-3xl">
      <div className="relative shrink-0">
        <motion.div animate={{ rotate: [0, 360] }} transition={{ duration: 4, repeat: Infinity, ease: 'linear' }} className="w-8 h-8 rounded-xl bg-gradient-to-br from-amber-400 to-orange-500 flex items-center justify-center text-sm shadow-lg shadow-amber-500/25">{'🍌'}</motion.div>
        {[0, 1, 2].map(i => <motion.div key={i} animate={{ rotate: [i * 120, i * 120 + 360] }} transition={{ duration: 2 + i * 0.3, repeat: Infinity, ease: 'linear' }} className="absolute inset-0" style={{ transformOrigin: 'center' }}><motion.div animate={{ scale: [0.5, 1, 0.5], opacity: [0.2, 0.8, 0.2] }} transition={{ duration: 1.5, repeat: Infinity, delay: i * 0.3 }} className="absolute -top-1 left-1/2 w-1.5 h-1.5 rounded-full bg-amber-400" /></motion.div>)}
      </div>

      <div className="flex-1 min-w-0">
        <motion.div key={phase} initial={{ opacity: 0, y: 5 }} animate={{ opacity: 1, y: 0 }} className={`bg-gradient-to-r ${p.gradient} p-[1px] rounded-2xl`}>
          <div className="bg-themed-secondary rounded-2xl px-4 py-3">
            {/* Phase header */}
            <div className="flex items-center gap-2 mb-2">
              <motion.div animate={{ rotate: [0, 15, -15, 0] }} transition={{ duration: 1.5, repeat: Infinity }} className={`w-6 h-6 rounded-lg bg-gradient-to-br ${p.gradient} flex items-center justify-center shadow-lg`}><Icon size={12} className="text-white" /></motion.div>
              <span className="text-[11px] font-bold text-white/75 uppercase tracking-wider">{p.label}</span>
              <span className="text-[8px] text-white/20 font-mono ml-auto">{phase + 1}/{PHASES.length}</span>
            </div>

            {/* Message */}
            <motion.p animate={{ opacity: [0.4, 0.8, 0.4] }} transition={{ duration: 2.5, repeat: Infinity }} className="text-[11px] text-white/40 mb-2.5">{p.msg}</motion.p>

            {/* Typing code animation */}
            <div className="bg-black/30 rounded-lg px-3 py-2 mb-2.5 font-mono">
              <span className="text-[10px] text-emerald-400/70">{typedCode}</span>
              <motion.span animate={{ opacity: [1, 0, 1] }} transition={{ duration: 0.8, repeat: Infinity }} className="text-amber-400">|</motion.span>
            </div>

            {/* Pipeline steps */}
            <div className="flex items-center gap-0.5 mb-2">
              {PHASES.map((_, i) => <motion.div key={i} className={`h-1 flex-1 rounded-full ${i <= phase ? `bg-gradient-to-r ${PHASES[i].gradient}` : 'bg-white/[0.04]'}`} animate={i === phase ? { opacity: [0.5, 1, 0.5] } : {}} transition={{ duration: 1, repeat: Infinity }} />)}
            </div>

            {/* Dots */}
            <div className="flex items-center gap-1.5">
              {[0, 1, 2, 3, 4].map(i => <motion.div key={i} animate={{ y: [0, -5, 0], opacity: [0.2, 1, 0.2] }} transition={{ duration: 0.7, repeat: Infinity, delay: i * 0.08 }} className={`w-1.5 h-1.5 rounded-full bg-gradient-to-br ${p.gradient}`} />)}
              <motion.span animate={{ opacity: [0, 0.5, 0] }} transition={{ duration: 2, repeat: Infinity }} className="text-[8px] text-white/15 font-mono ml-1">processing</motion.span>
            </div>
          </div>
        </motion.div>
      </div>
    </motion.div>
  );
}
