import { useAgent } from '../context/AgentContext';
import { motion, AnimatePresence } from 'framer-motion';
import { Activity, Zap } from 'lucide-react';

const ICONS: Record<string, string> = { thinking: '🧠', REASONING: '🔗', PLANNING: '📐', CODING: '💻', ANALYZING: '🔍', RESEARCHING: '🌐', OPTIMIZING: '⚡', 'File:': '📄', saved: '💾', complete: '✅', Error: '❌', Created: '🆕', Deleted: '🗑️', Search: '🌐' };
function getIcon(a: string) { for (const [k, v] of Object.entries(ICONS)) { if (a.includes(k)) return v; } return '⚡'; }

export default function ActionsFeed() {
  const { recentActions, agentStatus } = useAgent();
  return (
    <div className="flex-1 flex flex-col overflow-hidden min-h-0 bg-[#070710]">
      <div className="px-3.5 py-2.5 border-b border-white/[0.04] flex items-center gap-2 shrink-0"><Activity size={12} className="text-amber-400/70" /><span className="text-[11px] font-semibold text-white/45 uppercase tracking-wider">Activity</span>{agentStatus !== 'idle' && <motion.div animate={{ scale: [1, 1.4, 1], opacity: [0.8, 0.2, 0.8] }} transition={{ duration: 1.2, repeat: Infinity }} className="w-1.5 h-1.5 rounded-full bg-emerald-400 ml-auto" />}</div>
      <div className="flex-1 overflow-y-auto min-h-0 px-2 py-2 space-y-0.5 scrollbar-thin">
        <AnimatePresence initial={false}>{recentActions.map((action, idx) => <motion.div key={`${action}-${idx}`} initial={{ opacity: 0, x: 20, height: 0 }} animate={{ opacity: 1, x: 0, height: 'auto' }} exit={{ opacity: 0, x: -20, height: 0 }} transition={{ type: 'spring', damping: 25, stiffness: 350 }} className="flex items-start gap-2 px-2.5 py-2 rounded-xl bg-white/[0.015] border border-white/[0.03] overflow-hidden"><span className="text-[10px] shrink-0 mt-px">{getIcon(action)}</span><span className="text-[10px] text-white/30 font-mono break-words min-w-0 leading-relaxed">{action}</span></motion.div>)}</AnimatePresence>
        {recentActions.length === 0 && <div className="flex flex-col items-center justify-center py-20 text-white/10 text-[11px]"><Zap size={14} className="mb-1.5 opacity-50" /><span>Waiting for activity...</span></div>}
      </div>
      <div className="px-3.5 py-2 border-t border-white/[0.04] shrink-0 flex items-center justify-between text-[8px] text-white/12 font-mono"><span>100 tools</span><span>{recentActions.length} events</span></div>
    </div>
  );
}
