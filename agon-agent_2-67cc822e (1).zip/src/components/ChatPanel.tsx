import { useState, useRef, useEffect } from 'react';
import { useAgent } from '../context/AgentContext';
import { motion, AnimatePresence } from 'framer-motion';
import { Copy, Check, FileCode, Plus, RefreshCw, Pencil } from 'lucide-react';
import ThinkingAnimation from './ThinkingAnimation';
import CodeBlock from './CodeBlock';
import ChatInput from './ChatInput';
import AgentWidget, { parseWidgets } from './AgentWidget';

export default function ChatPanel() {
  const { messages, sendMessage, loading, agentStatus, currentSession, settings, createSession, setActiveTab } = useAgent();
  const [error, setError] = useState('');
  const [editingId, setEditingId] = useState<number | null>(null);
  const [editText, setEditText] = useState('');
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [messages, loading]);

  const handleSend = async (msg: string, mode: string, webSearch: boolean, customPrompt?: string) => {
    if (!settings.apiKey) { setError('Add your OpenRouter API key in Settings!'); return; }
    setError('');
    try { await sendMessage(msg, mode, webSearch, customPrompt); } catch (err: any) { setError(err.message); }
  };

  const handleRegenerate = async (userContent: string) => {
    if (!settings.apiKey) return;
    try { await sendMessage(userContent); } catch (err: any) { setError(err.message); }
  };

  return (
    <div className="flex-1 flex flex-col overflow-hidden min-h-0" style={{ background: 'var(--bg-primary)' }}>
      {/* Header */}
      <div className="px-4 py-2.5 flex items-center gap-3 backdrop-blur-xl shrink-0"
        style={{ borderBottom: '1px solid var(--border)', background: 'var(--bg-secondary)' }}>
        <button onClick={createSession}
          className="w-8 h-8 rounded-xl bg-gradient-to-br from-amber-400 via-orange-500 to-red-500 flex items-center justify-center text-sm shadow-lg shadow-amber-500/20 shrink-0 hover:scale-105 active:scale-95 transition-transform"
          title="New Session">{'🍌'}</button>
        <div className="flex-1 min-w-0">
          <h2 className="text-[13px] font-semibold truncate" style={{ color: 'var(--text-primary)' }}>{currentSession?.title || 'New Chat'}</h2>
          <p className="text-[9px] font-mono truncate" style={{ color: 'var(--text-muted)' }}>Session #{currentSession?.id}</p>
        </div>
        <StatusPill status={agentStatus} />
        <button onClick={createSession} className="p-1.5 rounded-lg hover:bg-white/[0.04] transition-colors" style={{ color: 'var(--text-muted)' }} title="New Session"><Plus size={16} /></button>
      </div>

      {/* Messages */}
      <div ref={scrollRef} className="flex-1 overflow-y-auto min-h-0 px-3 md:px-5 py-4 space-y-4 scrollbar-thin">
        {messages.length === 0 && !loading && <EmptyState onSuggest={(s: string) => handleSend(s, 'normal', false)} />}
        {messages.map((msg, idx) => (
          <MessageBubble
            key={msg.id || idx}
            message={msg}
            allMessages={messages}
            onRegenerate={handleRegenerate}
            onEdit={(id: number, text: string) => { setEditingId(id); setEditText(text); }}
            editingId={editingId}
            editText={editText}
            setEditText={setEditText}
            onSaveEdit={(text: string) => { handleSend(text, 'normal', false); setEditingId(null); }}
            onCancelEdit={() => setEditingId(null)}
          />
        ))}
        {loading && <ThinkingAnimation status={agentStatus} />}
        {error && (
          <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}
            className="bg-red-500/8 border border-red-500/15 rounded-2xl p-3 text-red-400 text-xs">
            ⚠ {error}
          </motion.div>
        )}
      </div>

      <ChatInput onSend={handleSend} loading={loading} />
    </div>
  );
}

function StatusPill({ status }: { status: string }) {
  const map: Record<string, { bg: string; text: string; label: string }> = {
    idle: { bg: 'bg-white/[0.04]', text: 'text-[var(--text-muted)]', label: 'Ready' },
    thinking: { bg: 'bg-violet-500/10', text: 'text-violet-400', label: 'Thinking' },
    reasoning: { bg: 'bg-blue-500/10', text: 'text-blue-400', label: 'Reasoning' },
    planning: { bg: 'bg-cyan-500/10', text: 'text-cyan-400', label: 'Planning' },
    analyzing: { bg: 'bg-indigo-500/10', text: 'text-indigo-400', label: 'Analyzing' },
    coding: { bg: 'bg-emerald-500/10', text: 'text-emerald-400', label: 'Coding' },
    researching: { bg: 'bg-amber-500/10', text: 'text-amber-400', label: 'Research' },
    optimizing: { bg: 'bg-rose-500/10', text: 'text-rose-400', label: 'Optimizing' },
    complete: { bg: 'bg-emerald-500/10', text: 'text-emerald-400', label: 'Done' },
    error: { bg: 'bg-red-500/10', text: 'text-red-400', label: 'Error' },
  };
  const c = map[status] || map.idle;
  const active = !['idle', 'error', 'complete'].includes(status);
  return (
    <motion.div key={status} initial={{ scale: 0.85, opacity: 0 }} animate={{ scale: 1, opacity: 1 }}
      className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[9px] font-semibold uppercase tracking-wider shrink-0 ${c.bg} ${c.text}`}>
      {active && <motion.div animate={{ opacity: [1, 0.3, 1] }} transition={{ duration: 1, repeat: Infinity }} className="w-1.5 h-1.5 rounded-full bg-current" />}
      {c.label}
    </motion.div>
  );
}

function EmptyState({ onSuggest }: { onSuggest: (v: string) => void }) {
  const s = [
    { e: '🐍', t: 'Snake game with neon glow' }, { e: '🌐', t: 'Modern portfolio' },
    { e: '📊', t: 'Analytics dashboard' }, { e: '🎮', t: 'Platformer game' },
    { e: '⚡', t: 'Todo app' }, { e: '🤖', t: 'AI chatbot' },
  ];
  return (
    <div className="flex flex-col items-center justify-center py-16 text-center px-4">
      <motion.div animate={{ y: [0, -10, 0] }} transition={{ duration: 3, repeat: Infinity, ease: 'easeInOut' }} className="relative mb-5">
        <span className="text-6xl">{'🍌'}</span>
      </motion.div>
      <h3 className="text-lg font-semibold mb-1" style={{ color: 'var(--text-primary)' }}>What should we build?</h3>
      <p className="text-xs max-w-xs mb-6" style={{ color: 'var(--text-muted)' }}>100+ tools · 3 modes · Web search · Memory</p>
      <div className="flex flex-wrap gap-2 justify-center max-w-md">
        {s.map((x, i) => (
          <motion.button key={i} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.06 + 0.2 }}
            onClick={() => onSuggest(`${x.e} ${x.t}`)}
            className="px-3 py-1.5 rounded-xl text-[11px] hover:text-amber-400 hover:border-amber-500/20 transition-all"
            style={{ background: 'var(--bg-input)', border: '1px solid var(--border)', color: 'var(--text-muted)' }}>
            {x.e} {x.t}
          </motion.button>
        ))}
      </div>
    </div>
  );
}

function parseContent(content: string) {
  const segments: Array<{ type: 'text' | 'code'; value: string; lang?: string; filename?: string }> = [];
  const rx = /```([\w+#.-]*):?([^\n]*)\n([\s\S]*?)```/g;
  let last = 0, m;
  while ((m = rx.exec(content)) !== null) {
    if (m.index > last) { const t = content.slice(last, m.index).trim(); if (t) segments.push({ type: 'text', value: t }); }
    segments.push({ type: 'code', value: m[3]?.trim() || '', lang: m[1] || 'text', filename: m[2]?.trim() || '' });
    last = m.index + m[0].length;
  }
  if (last < content.length) { const t = content.slice(last).trim(); if (t) segments.push({ type: 'text', value: t }); }
  if (segments.length === 0 && content.trim()) segments.push({ type: 'text', value: content.trim() });
  return segments;
}

function RichTextWithWidgets({ text }: { text: string }) {
  const segs = parseWidgets(text);
  return (
    <div className="space-y-1">
      {segs.map((seg, i) => seg.type === 'widget'
        ? <AgentWidget key={i} type={seg.widgetType!} config={seg.widgetConfig!} />
        : <RichLines key={i} text={seg.value} />
      )}
    </div>
  );
}

function RichLines({ text }: { text: string }) {
  return (
    <>
      {text.split('\n').map((line, i) => {
        if (line.startsWith('### ')) return <h4 key={i} className="text-[12px] font-semibold mt-2" style={{ color: 'var(--text-secondary)' }}>{line.slice(4)}</h4>;
        if (line.startsWith('## ')) return <h3 key={i} className="text-[13px] font-bold text-amber-400/80 mt-2.5">{line.slice(3)}</h3>;
        if (line.startsWith('# ')) return <h2 key={i} className="text-sm font-bold text-amber-400 mt-2.5">{line.slice(2)}</h2>;
        if (line.startsWith('- ') || line.startsWith('* ')) return <div key={i} className="flex items-start gap-2 text-[12px]" style={{ color: 'var(--text-body)' }}><span className="text-amber-400/40 mt-1 shrink-0 text-[6px]">●</span><span>{inl(line.slice(2))}</span></div>;
        const nm = line.match(/^(\d+)\.\s/);
        if (nm) return <div key={i} className="flex items-start gap-2 text-[12px]" style={{ color: 'var(--text-body)' }}><span className="text-amber-400/50 font-mono text-[10px] mt-0.5 shrink-0 w-4 text-right">{nm[1]}.</span><span>{inl(line.slice(nm[0].length))}</span></div>;
        if (!line.trim()) return <div key={i} className="h-1.5" />;
        return <p key={i} className="text-[12px] leading-relaxed" style={{ color: 'var(--text-body)' }}>{inl(line)}</p>;
      })}
    </>
  );
}

function inl(text: string) {
  const parts: Array<string | { t: string; v: string }> = [];
  const rx = /(\*\*(.+?)\*\*|`(.+?)`|\*(.+?)\*)/g;
  let li = 0, m;
  while ((m = rx.exec(text)) !== null) {
    if (m.index > li) parts.push(text.slice(li, m.index));
    if (m[2]) parts.push({ t: 'b', v: m[2] });
    else if (m[3]) parts.push({ t: 'c', v: m[3] });
    else if (m[4]) parts.push({ t: 'i', v: m[4] });
    li = m.index + m[0].length;
  }
  if (li < text.length) parts.push(text.slice(li));
  return (
    <>
      {parts.map((p, i) =>
        typeof p === 'string' ? <span key={i}>{p}</span> :
        p.t === 'b' ? <strong key={i} className="font-semibold" style={{ color: 'var(--text-secondary)' }}>{p.v}</strong> :
        p.t === 'c' ? <code key={i} className="px-1.5 py-0.5 rounded-md text-amber-400/70 text-[10px] font-mono" style={{ background: 'var(--bg-input)' }}>{p.v}</code> :
        <em key={i} className="italic" style={{ color: 'var(--text-muted)' }}>{p.v}</em>
      )}
    </>
  );
}

function MessageBubble({ message, allMessages, onRegenerate, onEdit, editingId, editText, setEditText, onSaveEdit, onCancelEdit }: any) {
  const [copied, setCopied] = useState(false);
  const { setActiveTab } = useAgent();
  const isUser = message.role === 'user';
  const meta = message.metadata || {};
  const segments = !isUser ? parseContent(message.content) : [];
  const isEditing = editingId === message.id;

  // Find the user message right before this agent message for regenerate
  const findPrevUserMsg = () => {
    const idx = allMessages.findIndex((m: any) => m.id === message.id);
    for (let i = idx - 1; i >= 0; i--) {
      if (allMessages[i].role === 'user') return allMessages[i].content;
    }
    return '';
  };

  return (
    <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3 }}
      className={`flex gap-3 ${isUser ? 'flex-row-reverse' : ''} max-w-3xl ${isUser ? 'ml-auto' : ''}`}>
      <div className={`w-7 h-7 rounded-xl flex items-center justify-center text-[11px] shrink-0 mt-0.5 shadow-md ${
        isUser ? 'bg-gradient-to-br from-blue-500 to-indigo-600 shadow-blue-500/15' : 'bg-gradient-to-br from-amber-400 to-orange-500 shadow-amber-500/15'
      }`}>{isUser ? '👤' : '🍌'}</div>

      <div className={`flex-1 min-w-0 ${isUser ? 'flex flex-col items-end' : ''}`}>
        {isUser ? (
          <div className="group relative">
            {isEditing ? (
              <div className="bg-blue-600/12 border border-blue-500/20 rounded-2xl rounded-tr-md p-2">
                <textarea value={editText} onChange={(e) => setEditText(e.target.value)}
                  className="w-full bg-transparent text-[13px] text-blue-100/90 resize-none focus:outline-none min-h-[40px]" autoFocus />
                <div className="flex gap-1.5 mt-1">
                  <button onClick={() => onSaveEdit(editText)} className="px-2.5 py-1 rounded-lg bg-blue-500/20 text-blue-400 text-[10px] font-semibold">Save & Send</button>
                  <button onClick={onCancelEdit} className="px-2.5 py-1 rounded-lg text-[10px]" style={{ background: 'var(--bg-input)', color: 'var(--text-muted)' }}>Cancel</button>
                </div>
              </div>
            ) : (
              <>
                <div className="inline-block rounded-2xl rounded-tr-md px-4 py-2.5 text-[13px] leading-relaxed max-w-full bg-blue-600/12 border border-blue-500/15 text-blue-100/90">
                  <div className="whitespace-pre-wrap break-words">{message.content}</div>
                </div>
                <button onClick={() => onEdit(message.id, message.content)}
                  className="absolute -bottom-5 right-0 opacity-0 group-hover:opacity-100 text-[9px] flex items-center gap-1 transition-opacity"
                  style={{ color: 'var(--text-muted)' }}>
                  <Pencil size={9} />Edit
                </button>
              </>
            )}
          </div>
        ) : (
          <div className="space-y-2.5 max-w-full">
            {segments.map((seg, i) => seg.type === 'text' ? (
              <div key={i} className="rounded-2xl rounded-tl-md px-4 py-3"
                style={{ background: 'var(--bg-input)', border: '1px solid var(--border)' }}>
                <RichTextWithWidgets text={seg.value} />
              </div>
            ) : (
              <CodeBlock key={i} code={seg.value} language={seg.lang || 'text'} filename={seg.filename} />
            ))}

            {/* Files saved → click to open editor */}
            {meta.code_files?.length > 0 && (
              <button onClick={() => setActiveTab('code')}
                className="flex items-center gap-2 px-3 py-2 rounded-xl bg-emerald-500/[0.05] border border-emerald-500/10 hover:bg-emerald-500/[0.08] transition-colors cursor-pointer w-full text-left">
                <FileCode size={12} className="text-emerald-400 shrink-0" />
                <span className="text-[10px] text-emerald-400/60 font-medium">
                  {meta.code_files.length} file{meta.code_files.length > 1 ? 's' : ''} → Open in Editor
                </span>
              </button>
            )}

            {/* Agent message actions */}
            <div className="flex items-center gap-3 pt-0.5">
              <button onClick={() => { navigator.clipboard.writeText(message.content); setCopied(true); setTimeout(() => setCopied(false), 2000); }}
                className="transition-colors" style={{ color: 'var(--text-muted)' }} title="Copy">
                {copied ? <Check size={11} /> : <Copy size={11} />}
              </button>
              <button onClick={() => onRegenerate(findPrevUserMsg())}
                className="flex items-center gap-1 text-[9px] transition-colors" style={{ color: 'var(--text-muted)' }} title="Regenerate">
                <RefreshCw size={10} />
              </button>
              {meta.model_used && (
                <p className="text-[8px] font-mono" style={{ color: 'var(--text-muted)', opacity: 0.5 }}>
                  {meta.model_used}
                </p>
              )}
            </div>
          </div>
        )}
      </div>
    </motion.div>
  );
}
