import { useState } from 'react';
import { useAgent } from '../context/AgentContext';
import { motion } from 'framer-motion';
import { X, Key, Cpu, ExternalLink, Shield, Zap, Check, Sun, Moon, Plus, Trash2, Wand2 } from 'lucide-react';

const MODELS = [
  { id: 'openrouter/auto', label: 'Auto (Best Free)', desc: 'Smart routing', icon: '🤖' },
  { id: 'meta-llama/llama-4-maverick:free', label: 'Llama 4 Maverick', desc: 'Meta', icon: '🦙' },
  { id: 'google/gemini-2.5-flash-preview:free', label: 'Gemini 2.5 Flash', desc: 'Google', icon: '💎' },
  { id: 'deepseek/deepseek-chat-v3-0324:free', label: 'DeepSeek V3', desc: 'DeepSeek', icon: '🧠' },
  { id: 'qwen/qwen3-235b-a22b:free', label: 'Qwen3 235B', desc: 'Alibaba', icon: '⚡' },
  { id: 'microsoft/mai-ds-r1:free', label: 'MAI-DS-R1', desc: 'Microsoft', icon: '🔬' },
  { id: 'google/gemma-3-27b-it:free', label: 'Gemma 3', desc: 'Google', icon: '💠' },
  { id: 'mistralai/mistral-small-3.2-24b-instruct:free', label: 'Mistral Small', desc: 'Mistral', icon: '🌊' },
];

export default function SettingsModal() {
  const { settings, setSettings, setShowSettings } = useAgent();
  const [apiKey, setApiKey] = useState(settings.apiKey);
  const [model, setModel] = useState(settings.model);
  const [theme, setTheme] = useState<'dark' | 'light'>(settings.theme || 'dark');
  const [customModes, setCustomModes] = useState(settings.customModes || []);
  const [newModeName, setNewModeName] = useState('');
  const [newModePrompt, setNewModePrompt] = useState('');
  const [tab, setTab] = useState<'general' | 'modes'>('general');

  const handleSave = () => {
    setSettings({ ...settings, apiKey, model, theme, customModes });
    setShowSettings(false);
  };

  const addCustomMode = () => {
    if (!newModeName.trim() || !newModePrompt.trim() || newModeName.length > 20 || newModePrompt.length > 5000) return;
    setCustomModes([...customModes, { name: newModeName.trim(), prompt: newModePrompt.trim() }]);
    setNewModeName('');
    setNewModePrompt('');
  };

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 flex items-end md:items-center justify-center bg-black/50 backdrop-blur-md"
      onClick={() => setShowSettings(false)}>
      <motion.div initial={{ y: 80, opacity: 0 }} animate={{ y: 0, opacity: 1 }} exit={{ y: 80, opacity: 0 }}
        transition={{ type: 'spring', damping: 28, stiffness: 300 }}
        className="w-full max-w-md border rounded-t-3xl md:rounded-3xl shadow-2xl max-h-[88vh] flex flex-col overflow-hidden"
        style={{ background: 'var(--bg-secondary)', borderColor: 'var(--border)' }}
        onClick={(e) => e.stopPropagation()}>

        <div className="md:hidden flex justify-center pt-2.5 pb-1 shrink-0"><div className="w-9 h-1 rounded-full" style={{ background: 'var(--border)' }} /></div>

        <div className="flex items-center justify-between px-5 py-3.5 border-b shrink-0" style={{ borderColor: 'var(--border)' }}>
          <h2 className="text-[15px] font-semibold" style={{ color: 'var(--text-primary)' }}>Settings</h2>
          <button onClick={() => setShowSettings(false)} className="p-1.5 rounded-lg" style={{ color: 'var(--text-muted)' }}><X size={16} /></button>
        </div>

        {/* Tabs */}
        <div className="flex border-b shrink-0" style={{ borderColor: 'var(--border)' }}>
          {(['general', 'modes'] as const).map(t => (
            <button key={t} onClick={() => setTab(t)}
              className={`flex-1 py-2.5 text-[11px] font-semibold uppercase tracking-wider transition-colors ${tab === t ? 'text-amber-400 border-b-2 border-amber-400' : ''}`}
              style={tab !== t ? { color: 'var(--text-muted)' } : {}}>
              {t === 'general' ? 'General' : 'Custom Modes'}
            </button>
          ))}
        </div>

        <div className="flex-1 overflow-y-auto min-h-0 p-5 space-y-5 scrollbar-thin">
          {tab === 'general' ? (
            <>
              {/* Theme Toggle */}
              <div>
                <label className="text-[12px] font-semibold mb-2 block" style={{ color: 'var(--text-muted)' }}>Theme</label>
                <div className="flex gap-2">
                  <button onClick={() => setTheme('dark')}
                    className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl border text-[12px] font-medium transition-colors ${theme === 'dark' ? 'bg-amber-500/10 border-amber-500/20 text-amber-400' : ''}`}
                    style={theme !== 'dark' ? { background: 'var(--bg-input)', borderColor: 'var(--border)', color: 'var(--text-muted)' } : {}}>
                    <Moon size={14} />Dark
                  </button>
                  <button onClick={() => setTheme('light')}
                    className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl border text-[12px] font-medium transition-colors ${theme === 'light' ? 'bg-amber-500/10 border-amber-500/20 text-amber-400' : ''}`}
                    style={theme !== 'light' ? { background: 'var(--bg-input)', borderColor: 'var(--border)', color: 'var(--text-muted)' } : {}}>
                    <Sun size={14} />Light
                  </button>
                </div>
              </div>

              {/* API Key */}
              <div>
                <label className="flex items-center gap-1.5 text-[12px] font-semibold mb-2" style={{ color: 'var(--text-muted)' }}>
                  <Key size={12} className="text-amber-400" />API Key
                </label>
                <input type="password" value={apiKey} onChange={(e) => setApiKey(e.target.value)} placeholder="sk-or-v1-..."
                  className="w-full rounded-xl px-4 py-3 text-[13px] focus:outline-none focus:border-amber-500/25 font-mono"
                  style={{ background: 'var(--bg-input)', border: '1px solid var(--border)', color: 'var(--text-primary)' }} />
                <div className="flex items-center justify-between mt-2">
                  <div className="flex items-center gap-1.5"><Shield size={9} className="text-emerald-400/40" /><p className="text-[9px]" style={{ color: 'var(--text-muted)' }}>Stored locally</p></div>
                  <a href="https://openrouter.ai/keys" target="_blank" rel="noopener noreferrer" className="flex items-center gap-1 text-[9px] text-amber-400/40 hover:text-amber-400"><ExternalLink size={8} />Get key</a>
                </div>
              </div>

              {/* Models */}
              <div>
                <label className="flex items-center gap-1.5 text-[12px] font-semibold mb-2" style={{ color: 'var(--text-muted)' }}>
                  <Cpu size={12} className="text-blue-400" />Model
                </label>
                <div className="grid grid-cols-2 gap-1.5">
                  {MODELS.map(m => (
                    <button key={m.id} onClick={() => setModel(m.id)}
                      className={`text-left px-3 py-2.5 rounded-xl border transition-all relative ${model === m.id ? 'bg-amber-500/8 border-amber-500/20 text-amber-400' : ''}`}
                      style={model !== m.id ? { background: 'var(--bg-input)', borderColor: 'var(--border)', color: 'var(--text-muted)' } : {}}>
                      {model === m.id && <div className="absolute top-2 right-2"><Check size={10} className="text-amber-400" /></div>}
                      <div className="text-[11px] font-semibold flex items-center gap-1.5"><span className="text-[12px]">{m.icon}</span>{m.label}</div>
                      <div className="text-[9px] opacity-50 mt-0.5">{m.desc}</div>
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="text-[9px] mb-1 block font-mono" style={{ color: 'var(--text-muted)' }}>Custom model ID</label>
                <input value={model} onChange={(e) => setModel(e.target.value)}
                  className="w-full rounded-xl px-3 py-2 text-[11px] font-mono focus:outline-none focus:border-amber-500/20"
                  style={{ background: 'var(--bg-input)', border: '1px solid var(--border)', color: 'var(--text-muted)' }} />
              </div>

              <div className="bg-amber-500/[0.04] border border-amber-500/8 rounded-xl p-3 flex items-start gap-2">
                <Zap size={12} className="text-amber-400/60 mt-0.5 shrink-0" />
                <p className="text-[10px] text-amber-400/40"><strong className="text-amber-400/60">Free:</strong> 50 req/day · <strong className="text-amber-400/60">$10+:</strong> 1000 req/day</p>
              </div>
            </>
          ) : (
            /* Custom Modes Tab */
            <div>
              <p className="text-[11px] mb-3" style={{ color: 'var(--text-muted)' }}>
                Create custom agent modes with your own system prompts. They appear in the mode dropdown in chat.
              </p>

              {customModes.map((cm, i) => (
                <div key={i} className="flex items-center gap-2 mb-2 rounded-xl px-3 py-2.5"
                  style={{ background: 'var(--bg-input)', border: '1px solid var(--border)' }}>
                  <Wand2 size={12} className="text-pink-400 shrink-0" />
                  <div className="flex-1 min-w-0">
                    <div className="text-[11px] font-semibold text-pink-400">{cm.name}</div>
                    <div className="text-[9px] truncate" style={{ color: 'var(--text-muted)' }}>{cm.prompt.slice(0, 60)}...</div>
                  </div>
                  <button onClick={() => setCustomModes(customModes.filter((_, j) => j !== i))} className="text-red-400/40 hover:text-red-400 shrink-0"><Trash2 size={12} /></button>
                </div>
              ))}

              <div className="space-y-2 mt-3">
                <input value={newModeName} onChange={(e) => setNewModeName(e.target.value.slice(0, 20))} placeholder="Mode name (max 20 chars)"
                  className="w-full rounded-xl px-3 py-2 text-[12px] focus:outline-none focus:border-pink-500/25"
                  style={{ background: 'var(--bg-input)', border: '1px solid var(--border)', color: 'var(--text-primary)' }} />
                <textarea value={newModePrompt} onChange={(e) => setNewModePrompt(e.target.value.slice(0, 5000))} placeholder="System prompt (max 5000 chars)" rows={4}
                  className="w-full rounded-xl px-3 py-2 text-[11px] focus:outline-none focus:border-pink-500/25 resize-none font-mono"
                  style={{ background: 'var(--bg-input)', border: '1px solid var(--border)', color: 'var(--text-primary)' }} />
                <div className="flex justify-between items-center">
                  <span className="text-[9px]" style={{ color: 'var(--text-muted)' }}>{newModePrompt.length}/5000</span>
                  <button onClick={addCustomMode} disabled={!newModeName.trim() || !newModePrompt.trim()}
                    className="px-3 py-1.5 rounded-lg bg-pink-500/15 text-pink-400 text-[10px] font-bold disabled:opacity-30">
                    <Plus size={10} className="inline mr-1" />Add Mode
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>

        <div className="px-5 py-4 border-t flex gap-2.5 shrink-0 safe-bottom" style={{ borderColor: 'var(--border)' }}>
          <button onClick={() => setShowSettings(false)} className="flex-1 py-2.5 rounded-xl text-[13px] font-medium"
            style={{ background: 'var(--bg-input)', color: 'var(--text-muted)' }}>Cancel</button>
          <button onClick={handleSave}
            className="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 text-black text-[13px] font-bold shadow-lg shadow-amber-500/15 active:scale-[0.98] transition-transform">Save</button>
        </div>
      </motion.div>
    </motion.div>
  );
}
