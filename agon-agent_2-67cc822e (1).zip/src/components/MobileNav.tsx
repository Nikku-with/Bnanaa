import { MessageSquare, Code, Activity, Menu } from 'lucide-react';
import { useAgent } from '../context/AgentContext';
import { motion } from 'framer-motion';

export default function MobileNav({ onOpenSidebar }: { onOpenSidebar: () => void }) {
  const { agentStatus, files, activeTab, setActiveTab } = useAgent();
  const tabs = [
    { id: 'sessions' as const, icon: Menu, label: 'Menu' },
    { id: 'chat' as const, icon: MessageSquare, label: 'Chat' },
    { id: 'code' as const, icon: Code, label: 'Editor' },
    { id: 'actions' as const, icon: Activity, label: 'Actions' },
  ];
  return (
    <div className="flex items-center safe-bottom" style={{ background: 'var(--bg-sidebar)', borderTop: '1px solid var(--border)' }}>
      {tabs.map(tab => {
        const isActive = activeTab === tab.id;
        const Icon = tab.icon;
        const showDot = (tab.id === 'chat' && agentStatus !== 'idle') || (tab.id === 'code' && files.length > 0);
        return (
          <button key={tab.id} onClick={() => tab.id === 'sessions' ? onOpenSidebar() : setActiveTab(tab.id)}
            className={`flex-1 flex flex-col items-center gap-0.5 py-2.5 relative transition-colors duration-200 ${isActive ? 'text-amber-400' : ''}`}
            style={!isActive ? { color: 'var(--text-muted)' } : {}}>
            {isActive && <motion.div layoutId="mob-nav" className="absolute -top-px left-1/2 -translate-x-1/2 w-8 h-[2px] rounded-full bg-amber-400" transition={{ type: 'spring', damping: 30, stiffness: 400 }} />}
            <div className="relative">
              <Icon size={18} strokeWidth={isActive ? 2.2 : 1.5} />
              {showDot && <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} className="absolute -top-0.5 -right-0.5 w-1.5 h-1.5 rounded-full bg-amber-400" />}
            </div>
            <span className="text-[8px] font-semibold uppercase tracking-wider">{tab.label}</span>
          </button>
        );
      })}
    </div>
  );
}
