import { useAgent } from '../context/AgentContext';
import { motion } from 'framer-motion';
import { Zap, Brain, Code, Search, FileCode, Wrench, Sparkles, Rocket, Menu, ArrowRight, ExternalLink } from 'lucide-react';

interface WelcomeScreenProps {
  onOpenSidebar?: () => void;
}

export default function WelcomeScreen({ onOpenSidebar }: WelcomeScreenProps) {
  const { createSession, setShowSettings, settings } = useAgent();

  const features = [
    { icon: Brain, label: 'Deep Reasoning', desc: 'LangChain multi-step analysis', color: 'from-violet-500 to-purple-600', glow: 'shadow-violet-500/20' },
    { icon: Zap, label: 'LangGraph Engine', desc: 'Autonomous workflow loops', color: 'from-amber-400 to-orange-500', glow: 'shadow-amber-500/20' },
    { icon: Code, label: '50+ Dev Tools', desc: 'Create, edit, refactor, deploy', color: 'from-emerald-400 to-green-600', glow: 'shadow-emerald-500/20' },
    { icon: Search, label: 'Web Research', desc: 'Real-time docs & APIs', color: 'from-sky-400 to-blue-600', glow: 'shadow-sky-500/20' },
    { icon: FileCode, label: 'Monaco IDE', desc: 'VS Code-grade editor', color: 'from-rose-400 to-pink-600', glow: 'shadow-rose-500/20' },
    { icon: Wrench, label: 'Auto-Fix', desc: 'Bug detection & repair', color: 'from-yellow-400 to-amber-600', glow: 'shadow-yellow-500/20' },
    { icon: Sparkles, label: 'Live Preview', desc: 'Run HTML/JS/CSS instantly', color: 'from-fuchsia-400 to-violet-600', glow: 'shadow-fuchsia-500/20' },
    { icon: Rocket, label: 'Max Output', desc: '20+ auto-added features', color: 'from-red-400 to-orange-600', glow: 'shadow-red-500/20' },
  ];

  return (
    <div className="flex-1 flex flex-col items-center overflow-y-auto min-h-0 relative px-5 py-8 md:py-14 md:justify-center">
      {/* Background gradient blobs */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-40 -left-40 w-96 h-96 bg-amber-500/[0.04] rounded-full blur-3xl" />
        <div className="absolute -bottom-40 -right-40 w-96 h-96 bg-violet-500/[0.04] rounded-full blur-3xl" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-orange-500/[0.02] rounded-full blur-3xl" />
      </div>

      {/* Mobile menu */}
      {onOpenSidebar && (
        <motion.button
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          onClick={onOpenSidebar}
          className="md:hidden self-start mb-6 flex items-center gap-2 px-3.5 py-2 rounded-xl bg-white/[0.04] border border-white/[0.06] text-xs text-white/50 backdrop-blur-sm"
        >
          <Menu size={14} /> Sessions
        </motion.button>
      )}

      <div className="max-w-xl w-full relative z-10">
        {/* Hero */}
        <motion.div
          initial={{ opacity: 0, y: 25 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
          className="text-center mb-10"
        >
          <motion.div
            animate={{ y: [0, -8, 0] }}
            transition={{ duration: 3, repeat: Infinity, ease: 'easeInOut' }}
            className="inline-block mb-5 relative"
          >
            <span className="text-6xl md:text-7xl">{'🍌'}</span>
            <motion.div
              animate={{ scale: [1, 1.4, 1], opacity: [0.3, 0, 0.3] }}
              transition={{ duration: 3, repeat: Infinity }}
              className="absolute inset-0 bg-amber-400/20 rounded-full blur-2xl -z-10"
            />
          </motion.div>
          <h1 className="text-3xl md:text-4xl font-extrabold tracking-tight mb-3">
            <span className="bg-gradient-to-r from-amber-300 via-orange-400 to-red-500 bg-clip-text text-transparent">
              BANANA AGENT
            </span>
          </h1>
          <p className="text-white/35 text-sm md:text-base max-w-md mx-auto leading-relaxed font-light">
            Elite autonomous AI coding engine.
            <span className="text-white/50 font-medium"> LangChain + LangGraph + OpenRouter.</span>
          </p>
        </motion.div>

        {/* Features Grid */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.25 }}
          className="grid grid-cols-2 md:grid-cols-4 gap-2 mb-8"
        >
          {features.map((feat, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.05 * i + 0.3, duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
              whileHover={{ y: -2, scale: 1.02 }}
              className="bg-white/[0.025] border border-white/[0.05] rounded-2xl p-3 hover:bg-white/[0.04] hover:border-white/[0.08] group cursor-default"
            >
              <div className={`w-8 h-8 rounded-xl bg-gradient-to-br ${feat.color} flex items-center justify-center mb-2 shadow-lg ${feat.glow} group-hover:scale-110 transition-transform duration-300`}>
                <feat.icon size={14} className="text-white" />
              </div>
              <h3 className="text-[11px] font-semibold text-white/75 mb-0.5">{feat.label}</h3>
              <p className="text-[9px] text-white/30 leading-snug">{feat.desc}</p>
            </motion.div>
          ))}
        </motion.div>

        {/* CTA */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
          className="flex flex-col items-center gap-3"
        >
          <motion.button
            whileHover={{ scale: 1.03 }}
            whileTap={{ scale: 0.97 }}
            onClick={createSession}
            className="group px-8 py-3 rounded-2xl bg-gradient-to-r from-amber-500 to-orange-500 text-black font-bold text-sm shadow-xl shadow-amber-500/20 glow-amber flex items-center gap-2"
          >
            <Rocket size={15} />
            Start Building
            <ArrowRight size={14} className="group-hover:translate-x-0.5 transition-transform" />
          </motion.button>

          {!settings.apiKey && (
            <button
              onClick={() => setShowSettings(true)}
              className="text-[11px] text-amber-400/40 hover:text-amber-400 transition-colors flex items-center gap-1"
            >
              <ExternalLink size={10} /> Set up free OpenRouter API key
            </button>
          )}
        </motion.div>

        {/* Setup Guide */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.8 }}
          className="mt-10 bg-white/[0.02] border border-white/[0.05] rounded-2xl p-5 backdrop-blur-sm"
        >
          <h3 className="text-[10px] font-bold text-white/40 uppercase tracking-widest mb-3 flex items-center gap-1.5">
            <Zap size={10} className="text-amber-400/60" /> Quick Setup
          </h3>
          <div className="space-y-2.5">
            {[
              'Create free account at openrouter.ai',
              'Generate API key from dashboard',
              'Paste key in Settings (gear icon)',
              'Pick a model — Auto works great',
              'Start a session and build anything!',
            ].map((text, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.9 + i * 0.08 }}
                className="flex items-center gap-3"
              >
                <div className="w-5 h-5 rounded-full bg-gradient-to-br from-amber-500/20 to-orange-500/20 border border-amber-500/10 flex items-center justify-center text-[9px] text-amber-400 font-bold shrink-0">
                  {i + 1}
                </div>
                <span className="text-[11px] text-white/35">{text}</span>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </div>
  );
}
