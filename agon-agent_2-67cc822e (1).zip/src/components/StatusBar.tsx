import { useAgent } from '../context/AgentContext';
import { useDevice } from '../hooks/useDevice';
import { motion } from 'framer-motion';
import { Wifi, WifiOff, Cpu, Zap, Clock, Circle, Monitor, Tablet, Smartphone } from 'lucide-react';
import { useState, useEffect } from 'react';

export default function StatusBar() {
  const { agentStatus, settings } = useAgent();
  const { device } = useDevice();
  const [time, setTime] = useState(new Date());
  useEffect(() => { const t = setInterval(() => setTime(new Date()), 1000); return () => clearInterval(t); }, []);
  const isConn = !!settings.apiKey;
  const DevIcon = device === 'mobile' ? Smartphone : device === 'tablet' ? Tablet : Monitor;

  return (
    <div className="h-7 bg-themed-sidebar border-b border-themed flex items-center px-3.5 gap-3 text-[9px] font-mono text-white/25">
      <div className="flex items-center gap-1.5"><span className="text-amber-400 text-[10px]">{'🍌'}</span><span className="font-bold text-white/40 tracking-wide">BANANA</span><span className="text-white/10 text-[8px]">v3.0</span></div>
      <div className="h-3 w-px bg-white/[0.06]" />
      <div className="flex items-center gap-1.5">{isConn ? <><Circle size={5} className="text-emerald-400 fill-emerald-400" /><span className="text-emerald-400/60">Connected</span></> : <><Circle size={5} className="text-red-400 fill-red-400" /><span className="text-red-400/60">No Key</span></>}</div>
      <div className="h-3 w-px bg-white/[0.06]" />
      <div className="flex items-center gap-1 truncate"><Cpu size={8} className="text-white/15" /><span className="truncate max-w-[120px] text-white/20">{settings.model}</span></div>
      {agentStatus !== 'idle' && <><div className="h-3 w-px bg-white/[0.06]" /><motion.div animate={{ opacity: [1, 0.3, 1] }} transition={{ duration: 1.2, repeat: Infinity }} className="flex items-center gap-1 text-amber-400/60"><Zap size={8} /><span className="uppercase font-semibold">{agentStatus}</span></motion.div></>}
      <div className="flex-1" />
      <div className="flex items-center gap-1 text-white/15"><DevIcon size={9} /><span className="capitalize">{device}</span></div>
      <div className="h-3 w-px bg-white/[0.06] hidden lg:block" />
      <span className="text-white/10 hidden lg:inline">100 Tools</span>
      <div className="h-3 w-px bg-white/[0.06]" />
      <div className="flex items-center gap-1 text-white/20"><Clock size={8} /><span>{time.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span></div>
    </div>
  );
}
