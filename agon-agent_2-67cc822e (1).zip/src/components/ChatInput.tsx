import { useState, useRef } from 'react';
import { useAgent } from '../context/AgentContext';
import { motion, AnimatePresence } from 'framer-motion';
import { ArrowUp, Loader2, Globe, ChevronUp, Sparkles, Zap, Box, Wand2 } from 'lucide-react';

interface ChatInputProps {
  onSend: (msg: string, mode: string, webSearch: boolean, customPrompt?: string) => void;
  loading: boolean;
}

export default function ChatInput({ onSend, loading }: ChatInputProps) {
  const { settings } = useAgent();
  const [input, setInput] = useState('');
  const [showDropdown, setShowDropdown] = useState(false);
  const [webSearch, setWebSearch] = useState(false);
  const [mode, setMode] = useState<string>('normal');
  const ref = useRef<HTMLTextAreaElement>(null);

  const builtinModes: Record<string, { label: string; icon: any; color: string; bg: string }> = {
    normal: { label: 'Normal', icon: Sparkles, color: 'text-white/40', bg: 'bg-white/[0.03]' },
    '3d_max': { label: '3D Max', icon: Box, color: 'text-violet-400', bg: 'bg-violet-500/10' },
    advanced: { label: 'Advanced', icon: Zap, color: 'text-amber-400', bg: 'bg-amber-500/10' },
  };

  const allModes: Record<string, { label: string; icon: any; color: string; bg: string }> = { ...builtinModes };
  (settings.customModes || []).forEach(cm => {
    allModes[`custom_${cm.name}`] = { label: cm.name, icon: Wand2, color: 'text-pink-400', bg: 'bg-pink-500/10' };
  });

  const mc = allModes[mode] || builtinModes.normal;
  const McIcon = mc.icon;

  const handleSend = () => {
    if (!input.trim() || loading) return;
    const isCustom = mode.startsWith('custom_');
    const customPrompt = isCustom ? settings.customModes?.find(cm => `custom_${cm.name}` === mode)?.prompt : undefined;
    const actualMode = isCustom ? 'custom' : mode;
    onSend(input, actualMode, webSearch, customPrompt);
    setInput('');
    if (ref.current) ref.current.style.height = '46px';
  };

  return (
    <div className="shrink-0 backdrop-blur-xl" style={{ borderTop: '1px solid var(--border)', background: 'var(--bg-secondary)' }}>
      {/* Mode & Search Bar */}
      <div className="px-3 pt-2 pb-1 flex items-center gap-1.5 flex-wrap">
        <div className="relative">
          <button onClick={() => setShowDropdown(!showDropdown)}
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg border text-[10px] font-semibold ${mc.bg} ${mc.color}`}
            style={{ borderColor: 'var(--border)' }}>
            <McIcon size={10} />{mc.label}<ChevronUp size={8} className={`transition-transform ${showDropdown ? '' : 'rotate-180'}`} />
          </button>
          <AnimatePresence>
            {showDropdown && (
              <motion.div initial={{ opacity: 0, y: 5 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 5 }}
                className="absolute bottom-full left-0 mb-1 rounded-xl shadow-2xl overflow-hidden z-20 min-w-[170px] max-h-[250px] overflow-y-auto scrollbar-thin"
                style={{ background: 'var(--bg-secondary)', border: '1px solid var(--border)' }}>
                {Object.entries(allModes).map(([key, cfg]) => {
                  const I = cfg.icon;
                  return (
                    <button key={key} onClick={() => { setMode(key); setShowDropdown(false); }}
                      className={`w-full flex items-center gap-2 px-3 py-2 text-[11px] font-medium transition-colors ${mode === key ? `${cfg.bg} ${cfg.color}` : ''}`}
                      style={mode !== key ? { color: 'var(--text-muted)' } : {}}>
                      <I size={12} />{cfg.label}{mode === key && <span className="ml-auto text-[8px]">●</span>}
                    </button>
                  );
                })}
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        <button onClick={() => setWebSearch(!webSearch)}
          className={`flex items-center gap-1 px-2 py-1 rounded-lg border text-[10px] font-semibold transition-colors ${webSearch ? 'bg-blue-500/10 border-blue-500/20 text-blue-400' : ''}`}
          style={!webSearch ? { background: 'var(--bg-input)', borderColor: 'var(--border)', color: 'var(--text-muted)' } : {}}>
          <Globe size={10} />{webSearch ? 'Search ON' : 'Search'}
        </button>
      </div>

      {/* Input */}
      <div className="px-3 pb-3 pt-1">
        <div className="flex gap-2 items-end max-w-3xl mx-auto">
          <textarea ref={ref} value={input} onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSend(); } }}
            placeholder={mode === '3d_max' ? 'Describe your 3D vision...' : mode === 'advanced' ? 'What problem needs solving?' : 'What do you want to build?'}
            rows={1}
            className="flex-1 rounded-2xl px-4 py-3 text-[13px] resize-none focus:outline-none focus:border-amber-500/30 transition-all"
            style={{ background: 'var(--bg-input)', border: '1px solid var(--border)', color: 'var(--text-primary)', minHeight: '46px', maxHeight: '130px' }}
            onInput={(e) => { const t = e.currentTarget; t.style.height = 'auto'; t.style.height = Math.min(t.scrollHeight, 130) + 'px'; }}
          />
          <motion.button whileTap={{ scale: 0.9 }} onClick={handleSend} disabled={loading || !input.trim()}
            className="h-[46px] w-[46px] rounded-2xl bg-gradient-to-br from-amber-500 to-orange-500 flex items-center justify-center text-black disabled:opacity-20 shadow-lg shadow-amber-500/15 shrink-0">
            {loading ? <Loader2 size={16} className="animate-spin" /> : <ArrowUp size={17} strokeWidth={2.5} />}
          </motion.button>
        </div>
      </div>
    </div>
  );
}
