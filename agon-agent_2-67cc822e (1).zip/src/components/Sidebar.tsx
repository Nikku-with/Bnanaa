import { useState } from 'react';
import { useAgent } from '../context/AgentContext';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, Trash2, MessageSquare, Settings, Zap, X, MoreVertical, Download } from 'lucide-react';

export default function Sidebar({ onClose }: { onClose?: () => void }) {
  const { sessions, currentSession, setCurrentSession, createSession, deleteSession, setShowSettings } = useAgent();
  const [menuId, setMenuId] = useState<number | null>(null);

  const handleExport = (session: any) => {
    const blob = new Blob([JSON.stringify(session, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url; a.download = `session-${session.id}.json`; a.click();
    URL.revokeObjectURL(url); setMenuId(null);
  };

  return (
    <div className="w-full md:w-[250px] h-full flex flex-col" style={{ background: 'var(--bg-sidebar)', borderRight: '1px solid var(--border)' }}>
      <div className="p-4 shrink-0" style={{ borderBottom: '1px solid var(--border)' }}>
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-amber-400 to-orange-500 flex items-center justify-center shadow-lg shadow-amber-500/15 shrink-0">
            <span className="text-base">{'🍌'}</span>
          </div>
          <div className="flex-1 min-w-0">
            <h1 className="text-[13px] font-bold" style={{ color: 'var(--text-primary)' }}>Banana Agent</h1>
            <p className="text-[9px] text-amber-400/40 font-mono">v3.0 · 100 Tools</p>
          </div>
          {onClose && <button onClick={onClose} className="md:hidden p-1.5 rounded-lg" style={{ color: 'var(--text-muted)' }}><X size={16} /></button>}
        </div>
      </div>

      <div className="p-3 shrink-0">
        <motion.button whileTap={{ scale: 0.97 }} onClick={() => { createSession(); onClose?.(); }}
          className="w-full flex items-center justify-center gap-2 px-3 py-2.5 rounded-xl bg-gradient-to-r from-amber-500/8 to-orange-500/8 border border-amber-500/12 text-amber-400/80 hover:from-amber-500/12 hover:to-orange-500/12 text-[12px] font-semibold transition-colors">
          <Plus size={14} />New Session
        </motion.button>
      </div>

      <div className="flex-1 overflow-y-auto min-h-0 px-2 space-y-0.5 scrollbar-thin">
        <AnimatePresence>
          {sessions.map(session => (
            <motion.div key={session.id} initial={{ opacity: 0, x: -15 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, height: 0 }} layout>
              <div className={`group flex items-center gap-2 px-3 py-2.5 rounded-xl cursor-pointer text-[12px] transition-all duration-150 relative ${
                currentSession?.id === session.id ? 'bg-amber-500/8 text-amber-400/90 border border-amber-500/12' : 'border border-transparent'
              }`}
                style={currentSession?.id !== session.id ? { color: 'var(--text-muted)' } : {}}
                onClick={() => { setCurrentSession(session); setMenuId(null); onClose?.(); }}>
                <MessageSquare size={13} className="shrink-0 opacity-50" />
                <span className="truncate flex-1 font-medium">{session.title}</span>

                {/* 3-dot menu */}
                <div className="relative">
                  <button onClick={(e) => { e.stopPropagation(); setMenuId(menuId === session.id ? null : session.id); }}
                    className="opacity-0 group-hover:opacity-100 p-0.5 transition-opacity"
                    style={{ color: 'var(--text-muted)' }}>
                    <MoreVertical size={12} />
                  </button>
                  <AnimatePresence>
                    {menuId === session.id && (
                      <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.95 }}
                        className="absolute right-0 top-full mt-1 rounded-xl shadow-2xl overflow-hidden z-30 min-w-[130px]"
                        style={{ background: 'var(--bg-secondary)', border: '1px solid var(--border)' }}
                        onClick={(e) => e.stopPropagation()}>
                        <button onClick={() => handleExport(session)}
                          className="w-full flex items-center gap-2 px-3 py-2 text-[10px] hover:bg-white/[0.04] transition-colors"
                          style={{ color: 'var(--text-muted)' }}>
                          <Download size={10} />Export
                        </button>
                        <div style={{ borderTop: '1px solid var(--border)' }} />
                        <button onClick={() => { deleteSession(session.id); setMenuId(null); }}
                          className="w-full flex items-center gap-2 px-3 py-2 text-[10px] text-red-400/70 hover:bg-red-500/[0.06] transition-colors">
                          <Trash2 size={10} />Delete
                        </button>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
        {sessions.length === 0 && <div className="text-center py-12 text-[11px]" style={{ color: 'var(--text-muted)' }}>No sessions yet</div>}
      </div>

      <div className="p-3 shrink-0" style={{ borderTop: '1px solid var(--border)' }}>
        <button onClick={() => { setShowSettings(true); onClose?.(); }}
          className="w-full flex items-center gap-2 px-3 py-2 rounded-xl text-[12px] transition-colors hover:bg-white/[0.03]"
          style={{ color: 'var(--text-muted)' }}>
          <Settings size={13} />Settings
        </button>
        <div className="flex items-center gap-1.5 px-3 py-1.5 text-[9px] font-mono" style={{ color: 'var(--text-muted)', opacity: 0.4 }}>
          <Zap size={8} className="text-amber-500/30" />OpenRouter
        </div>
      </div>
    </div>
  );
}
