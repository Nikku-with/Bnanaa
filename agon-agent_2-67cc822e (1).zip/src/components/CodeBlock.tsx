import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Copy, Check, FileCode, ChevronDown, ChevronUp } from 'lucide-react';
import { useAgent } from '../context/AgentContext';

interface CodeBlockProps { code: string; language: string; filename?: string; }

export default function CodeBlock({ code, language, filename }: CodeBlockProps) {
  const [copied, setCopied] = useState(false);
  const [collapsed, setCollapsed] = useState(false);
  const { createFile, currentSession, fetchFiles, setActiveTab } = useAgent();
  const lines = code.split('\n');
  const isLong = lines.length > 30;

  const handleCopy = () => { navigator.clipboard.writeText(code); setCopied(true); setTimeout(() => setCopied(false), 2000); };

  const handleOpenInEditor = async () => {
    if (!currentSession) return;
    const fname = filename || `code.${language === 'javascript' ? 'js' : language === 'typescript' ? 'ts' : language === 'python' ? 'py' : language}`;
    await createFile(fname, code, language);
    await fetchFiles();
    setActiveTab('code');
  };

  const displayLines = collapsed ? lines.slice(0, 8) : lines;

  return (
    <motion.div initial={{ opacity: 0, y: 5 }} animate={{ opacity: 1, y: 0 }}
      className="rounded-xl overflow-hidden" style={{ border: '1px solid var(--border)', background: 'var(--bg-secondary)' }}>
      <div className="flex items-center justify-between px-3 py-1.5" style={{ background: 'var(--bg-input)', borderBottom: '1px solid var(--border)' }}>
        <div className="flex items-center gap-2 min-w-0">
          <FileCode size={11} className="text-amber-400 shrink-0" />
          <span className="text-[10px] font-mono truncate" style={{ color: 'var(--text-muted)' }}>{filename || language}</span>
          <span className="text-[9px]" style={{ color: 'var(--text-muted)', opacity: 0.5 }}>{lines.length}L</span>
        </div>
        <div className="flex items-center gap-1 shrink-0">
          {isLong && <button onClick={() => setCollapsed(!collapsed)} className="p-1" style={{ color: 'var(--text-muted)' }}>{collapsed ? <ChevronDown size={12} /> : <ChevronUp size={12} />}</button>}
          <button onClick={handleCopy} className="p-1" style={{ color: 'var(--text-muted)' }}>{copied ? <Check size={12} className="text-emerald-400" /> : <Copy size={12} />}</button>
          <button onClick={handleOpenInEditor} className="flex items-center gap-1 px-2 py-0.5 rounded-md text-[9px] font-bold text-amber-400/60 hover:text-amber-400 hover:bg-amber-400/8 transition-colors">
            <FileCode size={10} />Open in Editor
          </button>
        </div>
      </div>
      <div className="overflow-x-auto overflow-y-auto max-h-[400px] scrollbar-thin">
        <div className="flex min-w-0">
          <div className="shrink-0 py-2 select-none" style={{ background: 'var(--bg-input)', borderRight: '1px solid var(--border)' }}>
            {displayLines.map((_, i) => <div key={i} className="text-[9px] text-right pr-2 pl-2 leading-[18px] font-mono" style={{ color: 'var(--text-muted)', opacity: 0.4 }}>{i + 1}</div>)}
          </div>
          <pre className="flex-1 py-2 px-3 overflow-x-auto">
            <code className="text-[11px] leading-[18px] font-mono text-emerald-300/80">
              {displayLines.map((line, i) => <div key={i} className="whitespace-pre">{line || ' '}</div>)}
            </code>
          </pre>
        </div>
      </div>
      {collapsed && isLong && <button onClick={() => setCollapsed(false)} className="w-full py-1.5 text-[9px] font-mono" style={{ color: 'var(--text-muted)', background: 'var(--bg-input)', borderTop: '1px solid var(--border)' }}>... {lines.length - 8} more lines</button>}
    </motion.div>
  );
}
