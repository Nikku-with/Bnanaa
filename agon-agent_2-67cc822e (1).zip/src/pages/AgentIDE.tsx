import { useAgent } from '../context/AgentContext';
import Sidebar from '../components/Sidebar';
import ChatPanel from '../components/ChatPanel';
import CodeEditor from '../components/CodeEditor';
import ActionsFeed from '../components/ActionsFeed';
import StatusBar from '../components/StatusBar';
import SettingsModal from '../components/SettingsModal';
import WelcomeScreen from '../components/WelcomeScreen';
import MobileNav from '../components/MobileNav';
import { AnimatePresence, motion } from 'framer-motion';
import { useState } from 'react';

export default function AgentIDE() {
  const { currentSession, showSettings, setShowSettings, settings, activeTab, setActiveTab } = useAgent();
  const [sidebarOpen, setSidebarOpen] = useState(false);

  return (
    <div className="fixed inset-0 flex flex-col overflow-hidden" style={{ background: 'var(--bg-primary)', color: 'var(--text-primary)' }}>
      <div className="hidden md:block shrink-0"><StatusBar /></div>
      <div className="flex-1 flex overflow-hidden min-h-0">
        <div className="hidden md:flex shrink-0"><Sidebar /></div>
        <AnimatePresence>
          {sidebarOpen && <>
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="md:hidden fixed inset-0 bg-black/50 backdrop-blur-sm z-40" onClick={() => setSidebarOpen(false)} />
            <motion.div initial={{ x: -280 }} animate={{ x: 0 }} exit={{ x: -280 }} transition={{ type: 'spring', damping: 28, stiffness: 300 }} className="md:hidden fixed left-0 top-0 bottom-0 z-50 w-[280px] shadow-2xl shadow-black/50">
              <Sidebar onClose={() => setSidebarOpen(false)} />
            </motion.div>
          </>}
        </AnimatePresence>
        <div className="flex-1 flex flex-col overflow-hidden min-h-0 min-w-0">
          {!currentSession ? <WelcomeScreen onOpenSidebar={() => setSidebarOpen(true)} /> : (
            <div className="flex-1 flex overflow-hidden min-h-0">
              <div className="md:hidden flex-1 flex flex-col overflow-hidden min-h-0">
                {activeTab === 'chat' && <ChatPanel />}
                {activeTab === 'code' && <CodeEditor />}
                {activeTab === 'actions' && <ActionsFeed />}
              </div>
              <div className="hidden md:flex flex-1 overflow-hidden min-h-0">
                <div className="flex-1 flex flex-col overflow-hidden min-h-0 min-w-0"><ChatPanel /></div>
                <div className="w-[42%] max-w-[560px] min-w-[300px] flex flex-col overflow-hidden min-h-0" style={{ borderLeft: '1px solid var(--border)' }}><CodeEditor /></div>
                <div className="hidden lg:flex w-[230px] flex-col overflow-hidden min-h-0" style={{ borderLeft: '1px solid var(--border)' }}><ActionsFeed /></div>
              </div>
            </div>
          )}
          {currentSession && <div className="md:hidden shrink-0"><MobileNav onOpenSidebar={() => setSidebarOpen(true)} /></div>}
        </div>
      </div>
      <AnimatePresence>{showSettings && <SettingsModal />}</AnimatePresence>
      <AnimatePresence>
        {!settings.apiKey && currentSession && (
          <motion.div initial={{ y: 80, opacity: 0 }} animate={{ y: 0, opacity: 1 }} exit={{ y: 80, opacity: 0 }}
            className="fixed bottom-20 md:bottom-5 left-1/2 -translate-x-1/2 bg-red-500/80 backdrop-blur-xl text-white px-5 py-2.5 rounded-2xl shadow-2xl flex items-center gap-3 z-30 border border-red-400/20 max-w-[90vw]">
            <span>⚠️</span><span className="text-[11px] font-medium">API key needed</span>
            <button onClick={() => setShowSettings(true)} className="bg-white/15 hover:bg-white/25 px-3 py-1 rounded-lg text-[10px] font-bold">Settings</button>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
