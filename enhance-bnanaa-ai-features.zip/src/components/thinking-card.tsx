"use client";

import { useEffect, useRef, useState } from "react";
import { useAgent } from "./agent-context";

const PHASES: Record<string, { icon: string; label: string; color: string }> = {
  thinking: { icon: "🧠", label: "THINKING", color: "#facc15" },
  analyzing: { icon: "🔬", label: "ANALYZING REQUEST", color: "#22d3ee" },
  searching: { icon: "🌐", label: "WEB SEARCHING", color: "#34d399" },
  reasoning: { icon: "💭", label: "DEEP REASONING", color: "#a78bfa" },
  writing: { icon: "✍️", label: "WRITING", color: "#60a5fa" },
  coding: { icon: "👨‍💻", label: "CODING", color: "#fb923c" },
  optimizing: { icon: "⚡", label: "OPTIMIZING", color: "#f472b6" },
  complete: { icon: "✅", label: "COMPLETE", color: "#34d399" },
  error: { icon: "❌", label: "ERROR", color: "#f87171" },
};

const PHASE_ORDER = ["thinking", "analyzing", "searching", "reasoning", "writing", "coding", "optimizing"];

function useElapsed(active: boolean) {
  const [el, setEl] = useState(0);
  const start = useRef(Date.now());
  useEffect(() => {
    if (!active) return;
    start.current = Date.now();
    const t = setInterval(() => setEl(Date.now() - start.current), 100);
    return () => clearInterval(t);
  }, [active]);
  return el;
}

export function SearchFeed() {
  const { search } = useAgent();
  const listRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    listRef.current?.scrollTo({
      top: listRef.current.scrollHeight,
      behavior: "smooth",
    });
  }, [search.results.length]);

  if (!search.active && search.results.length === 0) return null;

  return (
    <div className="mt-3 rounded-xl border border-emerald-500/30 bg-emerald-950/30 overflow-hidden">
      {/* Analysis report strip */}
      {search.queries && search.queries.length > 0 && (
        <div className="flex items-center gap-1.5 px-3 py-1.5 border-b border-cyan-500/20 bg-cyan-950/30 flex-wrap">
          <span className="text-[10px] font-black tracking-widest text-cyan-300 uppercase">
            🔬 Analysis
          </span>
          {search.analysisReason && (
            <span className="text-[10px] text-cyan-400/80 truncate">
              {search.analysisReason} →
            </span>
          )}
          {search.queries.map((q, i) => (
            <span
              key={i}
              className="text-[10px] px-1.5 py-0.5 rounded-full bg-cyan-500/15 text-cyan-200 border border-cyan-500/25 font-mono truncate max-w-[180px]"
            >
              🔍 {q}
            </span>
          ))}
        </div>
      )}
      <div className="flex items-center gap-2 px-3 py-2 border-b border-emerald-500/20 bg-emerald-900/20">
        <span className={search.done ? "" : "animate-spin-slow"}>🌐</span>
        <span className="text-[11px] font-bold tracking-widest text-emerald-300 uppercase">
          Live Web Search
        </span>
        <span className="text-[11px] text-emerald-400/80 truncate flex-1">
          {search.status}
        </span>
        {!search.done && (
          <span className="flex gap-1">
            {[0, 1, 2].map((i) => (
              <span
                key={i}
                className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-bounce"
                style={{ animationDelay: `${i * 0.15}s` }}
              />
            ))}
          </span>
        )}
      </div>
      <div
        ref={listRef}
        className="max-h-44 overflow-y-auto scroll-thin px-2 py-1.5 space-y-1"
      >
        {search.results.map((r, i) => {
          // highlight query terms in title
          const terms = (search.queries || [])
            .join(" ")
            .toLowerCase()
            .split(/\s+/)
            .filter((t) => t.length > 3);
          const parts = r.title.split(
            new RegExp(
              `(${terms.map((t) => t.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")).join("|") || "\u0000"})`,
              "gi"
            )
          );
          const relevance = Math.max(25, 100 - i * 7);
          return (
            <a
              key={i}
              href={r.url}
              target="_blank"
              rel="noopener noreferrer"
              className="block rounded-lg px-2 py-1.5 hover:bg-emerald-500/10 transition-colors animate-slide-in group"
            >
              <div className="flex items-center gap-2">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src={`https://www.google.com/s2/favicons?domain=${r.domain}&sz=32`}
                  alt=""
                  className="w-4 h-4 rounded-sm shrink-0"
                />
                <span className="text-[12px] text-emerald-100 truncate group-hover:text-white">
                  {parts.map((p, j) =>
                    terms.some((t) => p.toLowerCase() === t) ? (
                      <mark
                        key={j}
                        className="bg-yellow-400/30 text-yellow-200 rounded px-0.5"
                      >
                        {p}
                      </mark>
                    ) : (
                      p
                    )
                  )}
                </span>
                <span className="text-[10px] text-emerald-500 truncate ml-auto shrink-0 max-w-[120px]">
                  {r.domain}
                </span>
                <span className="text-[10px] text-emerald-600 group-hover:text-emerald-300">
                  ↗
                </span>
              </div>
              <div className="flex items-center gap-1.5 mt-1 pl-6">
                <div className="h-1 flex-1 max-w-[140px] rounded-full bg-emerald-900/60 overflow-hidden">
                  <div
                    className="h-full rounded-full bg-gradient-to-r from-emerald-400 to-teal-300 animate-grow-bar"
                    style={{ width: `${relevance}%` }}
                  />
                </div>
                <span className="text-[9px] font-mono text-emerald-600">
                  {relevance}%
                </span>
              </div>
            </a>
          );
        })}
        {!search.done && search.results.length === 0 && (
          <div className="px-2 py-3 space-y-2">
            {[0, 1, 2].map((i) => (
              <div
                key={i}
                className="h-3 rounded bg-emerald-500/10 animate-shimmer-bg"
                style={{ width: `${85 - i * 18}%`, animationDelay: `${i * 0.2}s` }}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

export default function ThinkingCard() {
  const { loading, phase, activities, streamingText, search } = useAgent();
  const elapsed = useElapsed(loading);
  const [cps, setCps] = useState(0);
  const lastLen = useRef(0);

  useEffect(() => {
    const t = setInterval(() => {
      setCps(Math.max(0, streamingText.length - lastLen.current) * 2);
      lastLen.current = streamingText.length;
    }, 500);
    return () => clearInterval(t);
  }, [streamingText]);

  if (!loading) return null;

  const p = PHASES[phase] || PHASES.thinking;
  const phaseIdx = PHASE_ORDER.indexOf(phase);
  const lastLine =
    streamingText.split("\n").filter(Boolean).slice(-1)[0]?.slice(-70) || "";
  const fileCount = (streamingText.match(/```[\w+#.-]*:/g) || []).length;
  const recent = activities.slice(0, 4);

  return (
    <div className="relative rounded-2xl overflow-hidden border border-yellow-500/30 bg-zinc-900/90 animate-glow-border">
      {/* scanning beam */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        <div className="absolute top-0 bottom-0 w-32 bg-gradient-to-r from-transparent via-yellow-400/8 to-transparent animate-scan" />
      </div>

      <div className="relative p-4">
        {/* Header row */}
        <div className="flex items-center gap-3">
          {/* orbiting core */}
          <div className="relative w-12 h-12 shrink-0">
            <div
              className="absolute inset-0 rounded-full border-2 border-dashed animate-spin-slow"
              style={{ borderColor: `${p.color}55` }}
            />
            <div
              className="absolute inset-1.5 rounded-full animate-pulse-core flex items-center justify-center text-xl"
              style={{ background: `${p.color}1a`, boxShadow: `0 0 18px ${p.color}40` }}
            >
              {p.icon}
            </div>
            <div
              className="absolute w-2 h-2 rounded-full animate-orbit"
              style={{ background: p.color, top: "50%", left: "50%" }}
            />
          </div>

          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-2 flex-wrap">
              <span
                className="text-sm font-black tracking-[0.2em]"
                style={{ color: p.color }}
              >
                {p.label}
              </span>
              <span className="text-[10px] px-1.5 py-0.5 rounded bg-zinc-800 text-zinc-400 font-mono">
                {(elapsed / 1000).toFixed(1)}s
              </span>
              {streamingText.length > 0 && (
                <span className="text-[10px] px-1.5 py-0.5 rounded bg-zinc-800 text-zinc-400 font-mono">
                  {streamingText.length.toLocaleString()} chars · ~{cps}/s
                </span>
              )}
              {fileCount > 0 && (
                <span className="text-[10px] px-1.5 py-0.5 rounded bg-orange-500/15 text-orange-300 font-mono">
                  📄 {fileCount} file{fileCount > 1 ? "s" : ""}
                </span>
              )}
            </div>
            {/* phase progress dots */}
            <div className="flex items-center gap-1 mt-1.5">
              {PHASE_ORDER.map((ph, i) => {
                const info = PHASES[ph];
                const isActive = ph === phase;
                const isDone = phaseIdx > i || phase === "complete";
                return (
                  <div key={ph} className="flex items-center gap-1">
                    <div
                      className={`h-1.5 rounded-full transition-all duration-500 ${
                        isActive ? "w-8 animate-pulse" : "w-3"
                      }`}
                      style={{
                        background: isActive
                          ? info.color
                          : isDone
                            ? `${info.color}80`
                            : "#3f3f46",
                      }}
                    />
                  </div>
                );
              })}
            </div>
          </div>

          {/* equalizer */}
          <div className="hidden sm:flex items-end gap-[3px] h-8">
            {[0, 1, 2, 3, 4].map((i) => (
              <span
                key={i}
                className="w-1 rounded-full animate-equalize"
                style={{
                  background: p.color,
                  animationDelay: `${i * 0.12}s`,
                  height: "100%",
                }}
              />
            ))}
          </div>
        </div>

        {/* live terminal line */}
        {lastLine && (
          <div className="mt-3 rounded-lg bg-black/50 border border-zinc-800 px-3 py-2 font-mono text-[11px] text-emerald-300/90 truncate">
            <span className="text-zinc-600 mr-2">❯</span>
            {lastLine}
            <span className="inline-block w-1.5 h-3 bg-emerald-300 ml-0.5 animate-blink align-middle" />
          </div>
        )}

        {/* live activity ticker */}
        {recent.length > 0 && (
          <div className="mt-3 space-y-1">
            {recent.map((a, i) => (
              <div
                key={a.id}
                className="flex items-center gap-2 text-[11px] animate-slide-in"
                style={{ opacity: 1 - i * 0.22 }}
              >
                <span className="text-zinc-600 font-mono">{a.time}</span>
                <span className="text-zinc-300 truncate">{a.text}</span>
                {i === 0 && (
                  <span className="ml-auto flex gap-0.5">
                    {[0, 1, 2].map((j) => (
                      <span
                        key={j}
                        className="w-1 h-1 rounded-full animate-bounce"
                        style={{ background: p.color, animationDelay: `${j * 0.15}s` }}
                      />
                    ))}
                  </span>
                )}
              </div>
            ))}
          </div>
        )}

        {/* live search feed inside the card */}
        {(search.active || search.results.length > 0) && <SearchFeed />}
      </div>
    </div>
  );
}
