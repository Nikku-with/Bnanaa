"use client";

import {
  createContext,
  useContext,
  useState,
  useEffect,
  useRef,
  useCallback,
  type ReactNode,
} from "react";

export interface Settings {
  apiKey: string;
  groqKey: string;
  provider: "openrouter" | "groq";
  model: string;
}
export interface Session {
  id: number;
  title: string;
  model: string;
  status: string;
  createdAt: string;
  updatedAt: string;
}
export interface MessageMeta {
  code_files?: { filename: string; language: string }[];
  model_used?: string;
  usage?: { prompt_tokens?: number; completion_tokens?: number };
  demo?: boolean;
  sources?: { title: string; url: string; snippet: string; domain: string }[];
}
export interface Message {
  id: number;
  sessionId: number;
  role: string;
  content: string;
  messageType: string;
  metadata: MessageMeta;
  createdAt: string;
}
export interface AgentFile {
  id: number;
  sessionId: number;
  filename: string;
  content: string;
  language: string;
}
export interface SearchResult {
  title: string;
  url: string;
  snippet: string;
  domain: string;
}
export interface SearchState {
  active: boolean;
  status: string;
  results: SearchResult[];
  done: boolean;
  queries?: string[];
  analysisReason?: string;
}
export interface Activity {
  id: number;
  text: string;
  time: string;
}

interface Ctx {
  settings: Settings;
  setSettings: (s: Settings) => void;
  sessions: Session[];
  currentSession: Session | null;
  selectSession: (s: Session | null) => void;
  messages: Message[];
  files: AgentFile[];
  loading: boolean;
  phase: string;
  activities: Activity[];
  streamingText: string;
  totalTokens: number;
  search: SearchState;
  fetchSessions: () => Promise<void>;
  createSession: () => Promise<Session | null>;
  deleteSession: (id: number) => Promise<void>;
  sendMessage: (msg: string, mode?: string, webSearch?: boolean) => Promise<void>;
  stopGeneration: () => void;
  fetchFiles: () => Promise<void>;
  saveFile: (id: number, c: string) => Promise<void>;
  deleteFile: (id: number) => Promise<void>;
  showSettings: boolean;
  setShowSettings: (v: boolean) => void;
  activeTab: string;
  setActiveTab: (t: string) => void;
  hasKey: boolean;
}

const AgentContext = createContext<Ctx>(null as unknown as Ctx);
export const useAgent = () => useContext(AgentContext);

const DEF: Settings = {
  apiKey: "",
  groqKey: "",
  provider: "groq",
  model: "llama-3.3-70b-versatile",
};

let aid = 0;

export function AgentProvider({ children }: { children: ReactNode }) {
  const [settings, setSettingsRaw] = useState<Settings>(DEF);
  const [sessions, setSessions] = useState<Session[]>([]);
  const [cur, setCur] = useState<Session | null>(null);
  const [msgs, setMsgs] = useState<Message[]>([]);
  const [files, setFiles] = useState<AgentFile[]>([]);
  const [loading, setLoading] = useState(false);
  const [phase, setPhase] = useState("idle");
  const [activities, setActivities] = useState<Activity[]>([]);
  const [streamingText, setStreamingText] = useState("");
  const [totalTokens, setTotalTokens] = useState(0);
  const [search, setSearch] = useState<SearchState>({
    active: false,
    status: "",
    results: [],
    done: false,
  });
  const [showSettings, setShowSettings] = useState(false);
  const [activeTab, setActiveTab] = useState("chat");
  const abortRef = useRef<AbortController | null>(null);
  const curRef = useRef<Session | null>(null);
  curRef.current = cur;

  useEffect(() => {
    try {
      const s = localStorage.getItem("banana_s3");
      if (s) setSettingsRaw({ ...DEF, ...JSON.parse(s) });
    } catch {}
  }, []);

  const setSettings = (s: Settings) => {
    setSettingsRaw(s);
    try {
      localStorage.setItem("banana_s3", JSON.stringify(s));
    } catch {}
  };

  const addActivity = useCallback((text: string) => {
    const time = new Date().toLocaleTimeString("en-IN", {
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
      hour12: false,
    });
    setActivities((p) => [{ id: ++aid, text, time }, ...p].slice(0, 40));
  }, []);

  const fetchSessions = useCallback(async () => {
    try {
      const r = await fetch("/api/sessions", { cache: "no-store" });
      const d = await r.json();
      setSessions(Array.isArray(d) ? d : []);
    } catch {
      setSessions([]);
    }
  }, []);

  const fetchMsgs = useCallback(async (sid: number) => {
    try {
      const r = await fetch(`/api/messages?session_id=${sid}`);
      const d = await r.json();
      setMsgs(Array.isArray(d) ? d : []);
    } catch {}
  }, []);

  const fetchFiles = useCallback(async () => {
    const c = curRef.current;
    if (!c) return;
    try {
      const r = await fetch(`/api/files?session_id=${c.id}`);
      const d = await r.json();
      setFiles(Array.isArray(d) ? d : []);
    } catch {}
  }, []);

  const createSession = useCallback(async (): Promise<Session | null> => {
    try {
      const r = await fetch("/api/sessions", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ title: "New Session", model: settings.model }),
      });
      if (!r.ok) return null;
      const d = await r.json();
      await fetchSessions();
      setCur(d);
      curRef.current = d;
      setMsgs([]);
      setFiles([]);
      addActivity("🆕 New session created");
      return d;
    } catch {
      return null;
    }
  }, [settings.model, fetchSessions, addActivity]);

  const deleteSession = useCallback(
    async (id: number) => {
      try {
        await fetch("/api/sessions", {
          method: "DELETE",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ id }),
        });
        if (curRef.current?.id === id) {
          setCur(null);
          setMsgs([]);
          setFiles([]);
        }
        await fetchSessions();
      } catch {}
    },
    [fetchSessions]
  );

  const selectSession = useCallback(
    (s: Session | null) => {
      setCur(s);
      curRef.current = s;
      if (s) {
        fetchMsgs(s.id);
      } else {
        setMsgs([]);
        setFiles([]);
      }
    },
    [fetchMsgs]
  );

  useEffect(() => {
    if (cur) {
      fetchMsgs(cur.id);
      fetchFiles();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [cur?.id]);

  const stopGeneration = () => {
    abortRef.current?.abort();
    abortRef.current = null;
  };

  const analyzeMessage = useCallback(
    async (
      msg: string,
      signal: AbortSignal
    ): Promise<{ need_search: boolean; queries: string[]; reason: string }> => {
      try {
        const r = await fetch("/api/analyze", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            message: msg,
            api_key: settings.apiKey,
            groq_key: settings.groqKey,
            provider: settings.provider,
            model: settings.model,
          }),
          signal,
        });
        if (!r.ok) throw new Error("analyze failed");
        const d = await r.json();
        return {
          need_search: Boolean(d.need_search),
          queries: Array.isArray(d.queries) ? d.queries : [],
          reason: d.reason || "",
        };
      } catch {
        return { need_search: true, queries: [msg.slice(0, 90)], reason: "fallback" };
      }
    },
    [settings]
  );

  const runSearch = useCallback(
    async (
      queries: string[],
      signal: AbortSignal,
      reason?: string,
      append = false
    ): Promise<{ context: string; sources: SearchResult[] }> => {
      setSearch((p) => ({
        active: true,
        status: `🧭 ${queries.join(" · ")}`,
        results: append ? p.results : [],
        done: false,
        queries: append ? [...(p.queries || []), ...queries] : queries,
        analysisReason: reason,
      }));
      addActivity("🌐 Live web search started");
      let context = "";
      let sources: SearchResult[] = [];
      try {
        const r = await fetch("/api/search", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ queries }),
          signal,
        });
        if (!r.ok || !r.body) throw new Error("search failed");
        const reader = r.body.getReader();
        const decoder = new TextDecoder();
        let buf = "";
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          buf += decoder.decode(value, { stream: true });
          const lines = buf.split("\n");
          buf = lines.pop() || "";
          for (const line of lines) {
            if (!line.startsWith("data: ")) continue;
            try {
              const d = JSON.parse(line.slice(6));
              if (d.status)
                setSearch((p) => ({ ...p, status: d.detail || d.status }));
              if (d.result) {
                setSearch((p) => ({
                  ...p,
                  results: [...p.results, d.result],
                }));
                addActivity(`🔗 ${d.result.domain}`);
              }
              if (d.done) {
                context = d.context || "";
                if (Array.isArray(d.sources)) sources = d.sources;
                setSearch((p) => ({
                  ...p,
                  done: true,
                  status: `✅ ${d.count} sources · ${d.fetched || 0} pages read`,
                }));
                addActivity(
                  `✅ Search done — ${d.count} sources, ${d.fetched || 0} pages read`
                );
              }
            } catch {}
          }
        }
      } catch {
        setSearch((p) => ({ ...p, done: true, status: "⚠️ Search unavailable" }));
        addActivity("⚠️ Web search failed — continuing without it");
      }
      return { context, sources };
    },
    [addActivity]
  );

  const sendMessage = useCallback(
    async (msg: string, mode = "normal", webSearch = false) => {
      let session = curRef.current;
      if (!session) {
        session = await createSession();
        if (!session) return;
      }
      setLoading(true);
      setPhase("thinking");
      setStreamingText("");
      setActivities([]);
      addActivity("🧠 Thinking…");
      if (!webSearch)
        setSearch({ active: false, status: "", results: [], done: false });

      // optimistic user bubble
      const optimistic: Message = {
        id: -Date.now(),
        sessionId: session.id,
        role: "user",
        content: msg,
        messageType: "text",
        metadata: {},
        createdAt: new Date().toISOString(),
      };
      setMsgs((p) => [...p, optimistic]);

      const controller = new AbortController();
      abortRef.current = controller;

      try {
        let searchCtx = "";
        let searchSources: SearchResult[] = [];
        // Quick client-side guard for obvious small-talk
        const isSmallTalk =
          /^(hi+|hii+|hello+|hey+|yo+|sup|namaste|thanks?|thank you|ok+|okay|hmm+|good (morning|night|evening)|kaise ho|kya haal|wassup|how are you)[\s!.?]*$/i.test(
            msg.trim()
          ) || msg.trim().split(/\s+/).length < 2;

        if (webSearch && isSmallTalk) {
          addActivity("💬 Small-talk detected — search skipped");
        } else if (webSearch) {
          // STEP 1: AI analyzes the message and plans search queries
          setPhase("analyzing");
          addActivity("🔬 Analyzing your message…");
          setSearch({
            active: true,
            status: "🔬 Analyzing what to search…",
            results: [],
            done: false,
          });
          const plan = await analyzeMessage(msg, controller.signal);

          if (!plan.need_search) {
            addActivity(`🧠 No search needed — ${plan.reason || "answering directly"}`);
            setSearch({
              active: false,
              status: "",
              results: [],
              done: false,
            });
          } else {
            addActivity(
              `🧭 Search plan: ${plan.queries.map((q) => `"${q}"`).join(", ")}`
            );
            // STEP 2+: AGENTIC LOOP — search → evaluate → refine → search again
            setPhase("searching");
            let queries = plan.queries;
            const allSources: SearchResult[] = [];
            const seenUrls = new Set<string>();
            const ctxParts: string[] = [];
            const allQueries: string[] = [];
            const MAX_ROUNDS = 3;

            for (let round = 1; round <= MAX_ROUNDS; round++) {
              if (round > 1)
                addActivity(
                  `🔁 Round ${round}: ${queries.map((q) => `"${q}"`).join(", ")}`
                );
              allQueries.push(...queries);
              const sr = await runSearch(
                queries,
                controller.signal,
                round === 1 ? plan.reason : `Round ${round} — refining`,
                round > 1
              );
              for (const s of sr.sources) {
                if (!seenUrls.has(s.url)) {
                  seenUrls.add(s.url);
                  allSources.push(s);
                }
              }
              if (sr.context) ctxParts.push(`--- ROUND ${round} ---\n${sr.context}`);

              if (round === MAX_ROUNDS) break;

              // Evaluate: are results sufficient or search again?
              setPhase("analyzing");
              addActivity(`🔬 Evaluating ${allSources.length} sources…`);
              try {
                const rr = await fetch("/api/analyze", {
                  method: "POST",
                  headers: { "Content-Type": "application/json" },
                  body: JSON.stringify({
                    message: msg,
                    api_key: settings.apiKey,
                    groq_key: settings.groqKey,
                    provider: settings.provider,
                    model: settings.model,
                    prior: {
                      queries: allQueries,
                      results: allSources.slice(0, 15).map((s) => ({
                        title: s.title,
                        snippet: s.snippet,
                        domain: s.domain,
                      })),
                    },
                  }),
                  signal: controller.signal,
                });
                const refine = await rr.json();
                if (refine.sufficient || !refine.queries?.length) {
                  addActivity(`✅ Coverage complete — ${refine.reason || "enough sources"}`);
                  break;
                }
                addActivity(`🧭 Gap found: ${refine.reason || "refining queries"}`);
                queries = refine.queries;
                setPhase("searching");
              } catch {
                break;
              }
            }

            searchSources = allSources;
            searchCtx = ctxParts.join("\n\n");
            if (searchCtx) {
              searchCtx = `SEARCH PLAN (agentic, ${allQueries.length} queries across rounds): ${allQueries.join("; ")}\nReason: ${plan.reason}\n\n${searchCtx}`;
            }
            setSearch((p) => ({
              ...p,
              done: true,
              status: `✅ ${allSources.length} sources · ${allQueries.length} queries`,
            }));
          }
        }

        const history = msgs
          .filter((m) => m.id > 0)
          .slice(-12)
          .map((m) => ({ role: m.role, content: m.content }));

        const r = await fetch("/api/agent", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            session_id: session.id,
            message: msg,
            api_key: settings.apiKey,
            groq_key: settings.groqKey,
            provider: settings.provider,
            model: settings.model,
            history,
            mode,
            search_results: searchCtx,
            search_sources: searchSources,
          }),
          signal: controller.signal,
        });
        if (!r.ok || !r.body) {
          const e = await r.json().catch(() => ({ error: "Request failed" }));
          throw new Error(e.error || "Request failed");
        }

        const reader = r.body.getReader();
        const decoder = new TextDecoder();
        let accumulated = "";
        let buf = "";

        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          buf += decoder.decode(value, { stream: true });
          const lines = buf.split("\n");
          buf = lines.pop() || "";
          for (const line of lines) {
            if (!line.startsWith("data: ")) continue;
            let d: Record<string, unknown>;
            try {
              d = JSON.parse(line.slice(6));
            } catch {
              continue;
            }
            if (typeof d.token === "string") {
              accumulated += d.token;
              setStreamingText(accumulated);
            }
            if (typeof d.phase === "string") {
              setPhase(d.phase);
              if (typeof d.detail === "string") addActivity(d.detail);
            }
            if (typeof d.activity === "string") addActivity(d.activity);
            if (typeof d.error === "string") throw new Error(d.error);
            if (d.complete) {
              const usage = d.usage as
                | { prompt_tokens?: number; completion_tokens?: number }
                | undefined;
              if (usage) {
                const t =
                  (usage.prompt_tokens || 0) + (usage.completion_tokens || 0);
                setTotalTokens((p) => p + t);
                addActivity(`📊 ${t} tokens used`);
              }
              const cf = d.code_files as { filename: string }[] | undefined;
              cf?.forEach((f) => addActivity(`📄 ${f.filename} ready`));
            }
          }
        }

        setStreamingText("");
        setPhase("complete");
        addActivity("✅ Response complete");
        let dbFetched = false;
        try {
          await fetchMsgs(session.id);
          dbFetched = true;
        } catch {
          // If DB fetch fails, keep the streamed content in local state
        }
        if (!dbFetched && accumulated) {
          // Fallback: add streamed content as a local agent message
          const agentBubble: Message = {
            id: -2,
            sessionId: session.id,
            role: "agent",
            content: accumulated,
            messageType: "agent_response",
            metadata: {},
            createdAt: new Date().toISOString(),
          };
          setMsgs((p) => [...p.filter((m) => m.id > 0), agentBubble]);
        }
        try {
          await fetchFiles();
        } catch {
          /* ignore */
        }
      } catch (err) {
        const e = err as Error;
        if (e.name === "AbortError") {
          addActivity("⏹ Stopped by user");
          setPhase("idle");
        } else {
          setPhase("error");
          addActivity(`❌ ${e.message}`);
          // Show error in chat as a system message — do NOT overwrite with fetchMsgs
          const errBubble: Message = {
            id: -Date.now(),
            sessionId: session!.id,
            role: "system",
            content: `❌ Error: ${e.message}\n\nPlease try again. Check your API key in ⚙️ Settings if the problem persists.`,
            messageType: "error",
            metadata: {},
            createdAt: new Date().toISOString(),
          };
          setMsgs((p) => [
            ...p.filter((m) => m.id > 0),
            errBubble,
          ]);
        }
        setStreamingText("");
      } finally {
        setLoading(false);
        abortRef.current = null;
        setTimeout(() => setPhase("idle"), 3000);
      }
    },
    [msgs, settings, createSession, fetchMsgs, fetchFiles, runSearch, analyzeMessage, addActivity]
  );

  const saveFile = useCallback(
    async (id: number, c: string) => {
      try {
        await fetch("/api/files", {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ id, content: c }),
        });
        await fetchFiles();
      } catch {}
    },
    [fetchFiles]
  );

  const deleteFile = useCallback(
    async (id: number) => {
      try {
        await fetch("/api/files", {
          method: "DELETE",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ id }),
        });
        await fetchFiles();
      } catch {}
    },
    [fetchFiles]
  );

  useEffect(() => {
    fetchSessions();
  }, [fetchSessions]);

  const hasKey = Boolean(
    settings.provider === "groq" ? settings.groqKey : settings.apiKey
  );

  return (
    <AgentContext.Provider
      value={{
        settings,
        setSettings,
        sessions,
        currentSession: cur,
        selectSession,
        messages: msgs,
        files,
        loading,
        phase,
        activities,
        streamingText,
        totalTokens,
        search,
        fetchSessions,
        createSession,
        deleteSession,
        sendMessage,
        stopGeneration,
        fetchFiles,
        saveFile,
        deleteFile,
        showSettings,
        setShowSettings,
        activeTab,
        setActiveTab,
        hasKey,
      }}
    >
      {children}
    </AgentContext.Provider>
  );
}
