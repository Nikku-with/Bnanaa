import { db } from "@/db";
import { files } from "@/db/schema";
import { desc, eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  try {
    const url = new URL(req.url);
    const sid = Number(url.searchParams.get("session_id"));
    if (!sid) return Response.json([]);
    const data = await db
      .select()
      .from(files)
      .where(eq(files.sessionId, sid))
      .orderBy(desc(files.updatedAt))
      .limit(200);
    return Response.json(data);
  } catch (e) {
    return Response.json({ error: (e as Error).message }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const [row] = await db
      .insert(files)
      .values({
        sessionId: body.session_id,
        filename: body.filename,
        content: body.content || "",
        language: body.language || "text",
      })
      .returning();
    return Response.json(row, { status: 201 });
  } catch (e) {
    return Response.json({ error: (e as Error).message }, { status: 500 });
  }
}

export async function PUT(req: Request) {
  try {
    const body = await req.json();
    const [row] = await db
      .update(files)
      .set({ content: body.content, updatedAt: new Date() })
      .where(eq(files.id, body.id))
      .returning();
    return Response.json(row);
  } catch (e) {
    return Response.json({ error: (e as Error).message }, { status: 500 });
  }
}

export async function DELETE(req: Request) {
  try {
    const { id } = await req.json();
    await db.delete(files).where(eq(files.id, id));
    return Response.json({ ok: true });
  } catch (e) {
    return Response.json({ error: (e as Error).message }, { status: 500 });
  }
}
