export const dynamic = "force-dynamic";
export const maxDuration = 90;

// Wandbox — free public code execution engine (Piston went whitelist-only Feb 2026)
const WANDBOX_URL = "https://wandbox.org/api/compile.json";

const LANG_MAP: Record<string, string> = {
  javascript: "nodejs-20.17.0",
  js: "nodejs-20.17.0",
  typescript: "nodejs-20.17.0",
  ts: "nodejs-20.17.0",
  python: "cpython-3.12.7",
  py: "cpython-3.12.7",
  bash: "bash",
  sh: "bash",
  c: "gcc-12.3.0-c",
  cpp: "gcc-12.3.0",
  "c++": "gcc-12.3.0",
  java: "openjdk-jdk-22+36",
  go: "go-1.23.2",
  rust: "rust-1.82.0",
  ruby: "ruby-3.4.9",
  php: "php-8.3.12",
};

export const RUNNABLE = Object.keys(LANG_MAP);

interface RunResult {
  ok: boolean;
  stdout: string;
  stderr: string;
  output: string;
  exitCode: number | null;
}

async function pistonRun(language: string, code: string): Promise<RunResult> {
  const compiler = LANG_MAP[language.toLowerCase()];
  if (!compiler)
    return {
      ok: false,
      stdout: "",
      stderr: `Language "${language}" not supported for execution`,
      output: "",
      exitCode: null,
    };
  const r = await fetch(WANDBOX_URL, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ code, compiler }),
    signal: AbortSignal.timeout(30000),
  });
  if (!r.ok) {
    const t = await r.text().catch(() => "");
    return {
      ok: false,
      stdout: "",
      stderr: `Sandbox API ${r.status}: ${t.slice(0, 150)}`,
      output: "",
      exitCode: null,
    };
  }
  const data = await r.json();
  const stdout = data.program_output || "";
  const stderr = [data.compiler_error, data.program_error]
    .filter(Boolean)
    .join("\n");
  const exitCode = data.status !== undefined ? Number(data.status) : null;
  return {
    ok: exitCode === 0 && !stderr,
    stdout,
    stderr,
    output: stdout || stderr,
    exitCode: Number.isNaN(exitCode) ? null : exitCode,
  };
}

async function aiFix(
  code: string,
  language: string,
  error: string,
  key: string,
  provider: string,
  model: string
): Promise<string | null> {
  try {
    const apiUrl =
      provider === "groq"
        ? "https://api.groq.com/openai/v1/chat/completions"
        : "https://openrouter.ai/api/v1/chat/completions";
    const headers: Record<string, string> = {
      "Content-Type": "application/json",
      Authorization: `Bearer ${key}`,
    };
    if (provider !== "groq") {
      headers["HTTP-Referer"] = "https://banana-agent.app";
      headers["X-Title"] = "Banana Agent";
    }
    const r = await fetch(apiUrl, {
      method: "POST",
      headers,
      body: JSON.stringify({
        // Multi-model routing: fast model for fix loops
        model:
          provider === "groq" ? "llama-3.1-8b-instant" : model || "openrouter/auto",
        messages: [
          {
            role: "system",
            content: `You are a code-fixing machine in a self-correction loop. The user gives you ${language} code and the runtime error it produced. Return ONLY the complete fixed code. No explanations, no markdown fences, no comments about what you changed — just raw runnable code.`,
          },
          {
            role: "user",
            content: `CODE:\n${code.slice(0, 6000)}\n\nERROR:\n${error.slice(0, 1500)}`,
          },
        ],
        temperature: 0.1,
        max_tokens: 4000,
        stream: false,
      }),
      signal: AbortSignal.timeout(30000),
    });
    if (!r.ok) return null;
    const data = await r.json();
    let fixed: string = data.choices?.[0]?.message?.content || "";
    // strip accidental fences
    fixed = fixed.replace(/^```[\w:+#.-]*\n?/, "").replace(/\n?```\s*$/, "").trim();
    return fixed || null;
  } catch {
    return null;
  }
}

export async function POST(req: Request) {
  const body = await req.json().catch(() => null);
  if (!body?.code || !body?.language)
    return Response.json({ error: "code and language required" }, { status: 400 });

  const { code, language, auto_fix, api_key, groq_key, provider, model } =
    body as Record<string, string> & { auto_fix?: boolean };

  const envGroq = process.env.GROQ_API_KEY || "";
  const envOr = process.env.OPENROUTER_API_KEY || "";
  const key = provider === "groq" ? groq_key || envGroq : api_key || envOr;
  const canFix = Boolean(auto_fix && key && key.trim().length > 5);

  const encoder = new TextEncoder();
  const stream = new ReadableStream({
    async start(controller) {
      const send = (obj: unknown) =>
        controller.enqueue(encoder.encode(`data: ${JSON.stringify(obj)}\n\n`));
      try {
        let currentCode = code;
        const MAX_ATTEMPTS = canFix ? 3 : 1;

        for (let attempt = 1; attempt <= MAX_ATTEMPTS; attempt++) {
          send({
            status: "running",
            attempt,
            detail:
              attempt === 1
                ? `▶ Executing ${language} via Piston…`
                : `▶ Re-running fixed code (attempt ${attempt})…`,
          });
          const result = await pistonRun(language, currentCode);
          send({
            result: {
              ok: result.ok,
              stdout: result.stdout.slice(0, 6000),
              stderr: result.stderr.slice(0, 3000),
              exitCode: result.exitCode,
              attempt,
            },
          });

          if (result.ok || attempt === MAX_ATTEMPTS) {
            send({
              done: true,
              ok: result.ok,
              attempts: attempt,
              final_code: currentCode !== code ? currentCode : undefined,
            });
            break;
          }

          // SELF-CORRECTION LOOP: error → AI fix → re-run
          send({
            status: "fixing",
            attempt,
            detail: `🔧 Error detected — AI is fixing the code…`,
          });
          const fixed = await aiFix(
            currentCode,
            language,
            result.stderr || result.output,
            key,
            provider,
            model
          );
          if (!fixed || fixed === currentCode) {
            send({
              done: true,
              ok: false,
              attempts: attempt,
              detail: "Could not auto-fix",
            });
            break;
          }
          currentCode = fixed;
          send({ status: "fixed", attempt, fixed_code: fixed.slice(0, 6000) });
        }
      } catch (e) {
        send({ error: (e as Error).message });
      } finally {
        controller.close();
      }
    },
  });

  return new Response(stream, {
    headers: {
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-cache, no-transform",
      Connection: "keep-alive",
    },
  });
}
