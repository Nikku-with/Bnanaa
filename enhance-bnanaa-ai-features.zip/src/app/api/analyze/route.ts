export const dynamic = "force-dynamic";
export const maxDuration = 30;

interface AnalyzePlan {
  need_search: boolean;
  queries: string[];
  reason: string;
}

function heuristicPlan(message: string): AnalyzePlan {
  const m = message.trim();
  const smallTalk =
    /^(hi+|hii+|hello+|hey+|yo+|sup|namaste|thanks?|thank you|ok+|okay|hmm+|good (morning|night|evening)|kaise ho|kya haal|wassup|how are you)[\s!.?]*$/i.test(
      m
    ) || m.split(/\s+/).length < 2;
  if (smallTalk)
    return {
      need_search: false,
      queries: [],
      reason: "Greeting / small-talk — search not needed",
    };
  // strip filler words to make a decent query
  const q = m
    .replace(
      /\b(please|pls|bro|bhai|yaar|can you|could you|tell me|search( the)?( web)?( for)?|about|i want to know|batao|karo|kya hai)\b/gi,
      " "
    )
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, 90);
  return {
    need_search: true,
    queries: [q || m.slice(0, 90)],
    reason: "Keyword extraction (no AI key for deep analysis)",
  };
}

interface PriorRound {
  queries: string[];
  results: { title: string; snippet: string; domain: string }[];
}

export async function POST(req: Request) {
  const body = await req.json().catch(() => null);
  if (!body?.message)
    return Response.json({ error: "message required" }, { status: 400 });

  const { message, api_key, groq_key, provider, model } = body as Record<
    string,
    string
  >;
  const prior = body.prior as PriorRound | undefined;
  const isRefine = Boolean(prior && Array.isArray(prior.queries));

  const envGroq = process.env.GROQ_API_KEY || "";
  const envOr = process.env.OPENROUTER_API_KEY || "";
  const key = provider === "groq" ? groq_key || envGroq : api_key || envOr;

  if (!key || key.trim().length < 6) {
    if (isRefine) {
      // heuristic refine: enough if 6+ results
      const enough = (prior?.results?.length || 0) >= 6;
      return Response.json({
        need_search: !enough,
        sufficient: enough,
        queries: enough ? [] : [message.slice(0, 80) + " guide"],
        reason: enough ? "Enough sources collected" : "Few results — one more try",
      });
    }
    return Response.json(heuristicPlan(message));
  }

  try {
    const apiUrl =
      provider === "groq"
        ? "https://api.groq.com/openai/v1/chat/completions"
        : "https://openrouter.ai/api/v1/chat/completions";
    const headers: Record<string, string> = {
      "Content-Type": "application/json",
      Authorization: `Bearer ${key}`,
    };
    if (provider !== "groq") {
      headers["HTTP-Referer"] = "https://banana-agent.app";
      headers["X-Title"] = "Banana Agent";
    }

    const sysPrompt = isRefine
      ? `You are a search result evaluator in an agentic loop. The user asked a question, searches ran, and you see what was found. Decide: are these results SUFFICIENT to answer well, or do we need ANOTHER round with refined/different queries?

Reply with ONLY a JSON object:
{"sufficient": boolean, "queries": ["refined query 1", "refined query 2"], "reason": "one short line"}

Rules:
- sufficient=true if the found titles/snippets clearly cover the user's question (or all sub-topics if multi-part)
- If user asked about MULTIPLE things, check EACH is covered; if one topic missing → sufficient=false, queries target ONLY the missing topic
- Refined queries must take a DIFFERENT angle than previous ones (synonyms, more specific terms, site-style keywords) — never repeat old queries
- Max 2 queries, max 8 words each, English keywords
- reason: max 12 words`
      : `You are a search query planner. Analyze the user's message and decide if a live web search would genuinely help answer it.

Reply with ONLY a JSON object, no other text:
{"need_search": boolean, "queries": ["query 1", "query 2"], "reason": "one short line"}

Rules:
- Greetings, small-talk, thanks, opinions, pure coding tasks ("build me a website", "fix this code") → need_search = false, queries = []
- Questions about current events, prices, versions, news, facts, comparisons, "latest X", real products/people → need_search = true
- If the user asks about MULTIPLE different things, make one query per topic (max 3)
- Write SHORT keyword-style search queries in English (max 8 words each), NOT the user's sentence verbatim
- If the message is Hinglish, still write English queries
- reason: max 10 words`;

    const userContent = isRefine
      ? `USER QUESTION: ${message.slice(0, 400)}

PREVIOUS QUERIES: ${prior!.queries.join(" | ")}

RESULTS FOUND SO FAR (${prior!.results.length}):
${prior!.results
  .slice(0, 15)
  .map((r, i) => `${i + 1}. [${r.domain}] ${r.title}${r.snippet ? ` — ${r.snippet.slice(0, 80)}` : ""}`)
  .join("\n")}`
      : message.slice(0, 500);

    const r = await fetch(apiUrl, {
      method: "POST",
      headers,
      body: JSON.stringify({
        // Multi-model routing: fast small model for planning/eval, main model stays for answers
        model:
          provider === "groq"
            ? "llama-3.1-8b-instant"
            : model || "openrouter/auto",
        messages: [
          { role: "system", content: sysPrompt },
          { role: "user", content: userContent },
        ],
        temperature: 0.1,
        max_tokens: 200,
        stream: false,
      }),
      signal: AbortSignal.timeout(12000),
    });

    if (!r.ok) return Response.json(heuristicPlan(message));
    const data = await r.json();
    const text: string = data.choices?.[0]?.message?.content || "";
    const jsonMatch = text.match(/\{[\s\S]*\}/);
    if (!jsonMatch) return Response.json(heuristicPlan(message));
    const parsed = JSON.parse(jsonMatch[0]) as Partial<AnalyzePlan> & {
      sufficient?: boolean;
    };
    const queries = Array.isArray(parsed.queries)
      ? parsed.queries
          .filter((q): q is string => typeof q === "string" && q.trim().length > 0)
          .map((q) => q.trim().slice(0, 100))
          .slice(0, 3)
      : [];
    const reason =
      typeof parsed.reason === "string" ? parsed.reason.slice(0, 120) : "";

    if (isRefine) {
      const sufficient = Boolean(parsed.sufficient) || queries.length === 0;
      return Response.json({
        sufficient,
        need_search: !sufficient,
        queries: sufficient ? [] : queries,
        reason,
      });
    }

    const plan: AnalyzePlan = {
      need_search: Boolean(parsed.need_search),
      queries,
      reason,
    };
    if (plan.need_search && plan.queries.length === 0) {
      plan.queries = heuristicPlan(message).queries;
    }
    return Response.json(plan);
  } catch {
    return Response.json(heuristicPlan(message));
  }
}
