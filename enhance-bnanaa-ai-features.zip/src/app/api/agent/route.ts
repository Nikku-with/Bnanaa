import { db } from "@/db";
import { sessions, messages, files, memory } from "@/db/schema";
import { eq } from "drizzle-orm";
import { buildSystemPrompt, extractCodeBlocks } from "@/lib/prompt";

export const dynamic = "force-dynamic";
export const maxDuration = 120;

const DEMO_RESPONSE = `## 🍌 Banana Agent — Connected & Ready!

Everything is working! I have your API key and I'm ready to help.

**What I can do:**
- Build full-stack apps with complete code  
- 🌐 **Real live web search** with scrolling source links
- 🕐 I always know the **current date & time**
- 100 verified tools across 9 categories

Try asking me to build something, search the web, or explain a concept!

[WIDGET:choice:Build a website,Fix my code,Search the web,3D animations,Explain a concept]

[WIDGET:copy:npm create vite@latest my-app]

\`\`\`javascript:demo.js
console.log("Banana Agent is ready! 🍌");
console.log("Time:", new Date().toLocaleString());
\`\`\`

[WIDGET:file:demo.js]`;

interface HistoryMsg {
  role: string;
  content: string;
}

function sse(obj: unknown): string {
  return `data: ${JSON.stringify(obj)}\n\n`;
}

function sleep(ms: number): Promise<void> {
  return new Promise((r) => setTimeout(r, ms));
}

async function* generateStream(
  content: string,
  error: string | null,
  codeBlocks: ReturnType<typeof extractCodeBlocks>,
  model: string,
  usage: unknown,
  hasKey: boolean
): AsyncIterable<string> {
  yield sse({ phase: "thinking", detail: "🧠 Reading your request…" });
  yield sse({
    phase: "reasoning",
    detail: hasKey ? `⚡ Generating with ${model}` : "🔌 Demo mode active",
  });

  let text = content;
  if (error) {
    text = `## ❌ Request Failed\n\n**Error:** ${error}\n\n**Please try again.** If the issue persists, check your API key in ⚙️ Settings.\n\nYou can also try switching providers (Groq ↔ OpenRouter) or choosing a different model.`;
  }

  yield sse({ phase: "writing", detail: "✍️ Writing response…" });
  let accum = "";
  for (let i = 0; i < text.length; i++) {
    accum += text[i];
    if (accum.length >= 12 || i === text.length - 1) {
      yield sse({ token: accum });
      accum = "";
      const pause = text[i] === "`" ? 5 : text[i] === "\n" ? 15 : 2;
      await sleep(pause);
    }
  }

  yield sse({ phase: "complete", detail: "✅ Done" });
  yield sse({
    complete: true,
    code_files: codeBlocks.map((b) => ({
      filename: b.filename,
      language: b.language,
    })),
    saved_files: codeBlocks.length,
    usage,
    model_used: model,
    demo: !hasKey,
  });
}

export async function POST(req: Request) {
  const body = await req.json().catch(() => null);
  if (!body)
    return Response.json({ error: "Invalid body" }, { status: 400 });

  const {
    session_id,
    message,
    api_key,
    groq_key,
    provider,
    model,
    history,
    mode,
    custom_prompt,
    memory_context,
    search_results,
    search_sources,
  } = body as Record<string, string> & {
    history: HistoryMsg[];
    search_sources?: {
      title: string;
      url: string;
      snippet: string;
      domain: string;
    }[];
  };

  const sid = Number(session_id);
  if (!sid || !message) {
    return Response.json(
      { error: "session_id and message required" },
      { status: 400 }
    );
  }
  const envGroq = process.env.GROQ_API_KEY || "";
  const envOr = process.env.OPENROUTER_API_KEY || "";
  const key = provider === "groq" ? groq_key || envGroq : api_key || envOr;
  const hasKey = Boolean(key && key.trim().length > 5);

  console.log(
    `[AGENT] session=${sid} msg="${message.slice(0, 40)}" key=${hasKey ? "YES" : "NO"} provider=${provider} model=${model}`
  );

  try {
    await db.insert(messages).values({
      sessionId: sid,
      role: "user",
      content: message,
      messageType: "text",
      metadata: {},
    });
  } catch (e) {
    console.error("[AGENT] Failed to save user message:", (e as Error).message);
  }

  let fullContent = "";
  let usage: unknown = null;
  let serverError: string | null = null;

  try {
    if (!hasKey) {
      fullContent = DEMO_RESPONSE;
    } else {
      const sysPrompt = buildSystemPrompt({
        mode,
        customPrompt: custom_prompt,
        memoryContext: memory_context,
        searchResults: search_results,
      });
      const msgs: { role: string; content: string }[] = [
        { role: "system", content: sysPrompt },
      ];
      for (const m of history || []) {
        msgs.push({
          role: m.role === "agent" ? "assistant" : m.role,
          content: m.content,
        });
      }
      msgs.push({ role: "user", content: message });

      const apiUrl =
        provider === "groq"
          ? "https://api.groq.com/openai/v1/chat/completions"
          : "https://openrouter.ai/api/v1/chat/completions";
      const headers: Record<string, string> = {
        "Content-Type": "application/json",
        Authorization: `Bearer ${key}`,
      };
      if (provider !== "groq") {
        headers["HTTP-Referer"] = "https://banana-agent.app";
        headers["X-Title"] = "Banana Agent";
      }

      const apiRes = await fetch(apiUrl, {
        method: "POST",
        headers,
        body: JSON.stringify({
          model: model || "openrouter/auto",
          messages: msgs,
          temperature: 0.7,
          max_tokens: provider === "groq" ? 16000 : 8000,
          stream: true,
        }),
        signal: AbortSignal.timeout(90000),
      });

      if (!apiRes.ok) {
        let errBody = "";
        try {
          errBody = (await apiRes.text()).slice(0, 300);
        } catch {}
        serverError = `API returned ${apiRes.status}: ${errBody.slice(0, 200)}`;
        throw new Error(serverError);
      }
      if (!apiRes.body) {
        serverError = "API returned no response body";
        throw new Error(serverError);
      }

      const reader = apiRes.body.getReader();
      const decoder = new TextDecoder();
      let buf = "";
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buf += decoder.decode(value, { stream: true });
        const lines = buf.split("\n");
        buf = lines.pop() || "";
        for (const line of lines) {
          if (!line.startsWith("data: ")) continue;
          const data = line.slice(6).trim();
          if (data === "[DONE]") continue;
          try {
            const parsed = JSON.parse(data);
            const delta = parsed.choices?.[0]?.delta?.content || "";
            if (delta) fullContent += delta;
            if (parsed.usage) usage = parsed.usage;
          } catch {}
        }
      }
    }
  } catch (e) {
    console.error("[AGENT] Generation error:", e);
    if (!serverError) serverError = (e as Error).message;
  }

  const finalContent = serverError
    ? `## ❌ Request Failed\n\n**Error:** ${serverError}\n\n**Please try again.** If the issue persists, check your API key in ⚙️ Settings.`
    : fullContent;

  const codeBlocks = extractCodeBlocks(finalContent);
  try {
    for (const block of codeBlocks) {
      await db
        .insert(files)
        .values({
          sessionId: sid,
          filename: block.filename,
          content: block.content,
          language: block.language,
        })
        .catch(() => {});
    }
    await db.insert(messages).values({
      sessionId: sid,
      role: "agent",
      content: finalContent,
      messageType: "agent_response",
      metadata: {
        code_files: codeBlocks.map((b) => ({
          filename: b.filename,
          language: b.language,
        })),
        model_used: model,
        usage,
        mode,
        demo: !hasKey,
        sources: Array.isArray(search_sources) ? search_sources.slice(0, 50) : [],
      },
    });
    if (/my name is|i am |i'm |call me/i.test(message) && message.length < 200) {
      await db
        .insert(memory)
        .values({
          sessionId: sid,
          key: "user_note",
          value: message.slice(0, 180),
        })
        .catch(() => {});
    }
    await db
      .update(sessions)
      .set({ updatedAt: new Date(), title: message.substring(0, 80) })
      .where(eq(sessions.id, sid))
      .catch(() => {});
  } catch (e) {
    console.error("[AGENT] DB save error:", (e as Error).message);
  }

  const encoder = new TextEncoder();
  const stream = new ReadableStream({
    async start(controller) {
      try {
        for await (const line of generateStream(
          finalContent,
          null,
          codeBlocks,
          model || "openrouter/auto",
          usage,
          hasKey
        )) {
          controller.enqueue(encoder.encode(line));
        }
      } catch (e) {
        controller.enqueue(encoder.encode(sse({ error: (e as Error).message })));
      } finally {
        controller.close();
      }
    },
  });

  return new Response(stream, {
    headers: {
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-cache, no-transform",
      Connection: "keep-alive",
      "X-Accel-Buffering": "no",
    },
  });
}
